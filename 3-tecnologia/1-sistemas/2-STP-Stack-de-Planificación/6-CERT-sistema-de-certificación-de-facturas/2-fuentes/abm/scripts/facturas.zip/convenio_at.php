<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                   ATTENTION!
 * If you see this message in your browser (Internet Explorer, Mozilla Firefox, Google Chrome, etc.)
 * this means that PHP is not properly installed on your web server. Please refer to the PHP manual
 * for more details: http://php.net/manual/install.php 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */


    include_once dirname(__FILE__) . '/' . 'components/utils/check_utils.php';
    CheckPHPVersion();
    CheckTemplatesCacheFolderIsExistsAndWritable();


    include_once dirname(__FILE__) . '/' . 'phpgen_settings.php';
    include_once dirname(__FILE__) . '/' . 'database_engine/pgsql_engine.php';
    include_once dirname(__FILE__) . '/' . 'components/page.php';
    include_once dirname(__FILE__) . '/' . 'authorization.php';

    function GetConnectionOptions()
    {
        $result = GetGlobalConnectionOptions();
        $result['client_encoding'] = 'utf8';
        GetApplication()->GetUserAuthorizationStrategy()->ApplyIdentityToConnectionOptions($result);
        return $result;
    }

    
    // OnGlobalBeforePageExecute event handler
    
    
    // OnBeforePageExecute event handler
    
    
    
    class public_convenio_atPage extends Page
    {
        protected function DoBeforeCreate()
        {
            $this->dataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."convenio_at"');
            $field = new IntegerField('id_convenio_at', null, null, true);
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, true);
            $field = new StringField('no_convenio_at');
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_universidad');
            $this->dataset->AddField($field, false);
        }
    
        protected function DoPrepare() {
    
        }
    
        protected function CreatePageNavigator()
        {
            $result = new CompositePageNavigator($this);
            
            $partitionNavigator = new PageNavigator('pnav', $this, $this->dataset);
            $partitionNavigator->SetRowsPerPage(100);
            $result->AddPageNavigator($partitionNavigator);
            
            return $result;
        }
    
        public function GetPageList()
        {
            $currentPageCaption = $this->GetShortCaption();
            $result = new PageList($this);
            $result->AddGroup($this->RenderText('Facturas'));
            $result->AddGroup($this->RenderText('Agentes'));
            $result->AddGroup($this->RenderText('Contratos'));
            if (GetCurrentUserGrantForDataSource('public.factura')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Factura'), 'factura.php', $this->RenderText('Factura'), $currentPageCaption == $this->RenderText('Factura'), false, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.certificacion')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Lote Certificaci�n'), 'certificacion.php', $this->RenderText('Lote Certificaci�n'), $currentPageCaption == $this->RenderText('Lote Certificaci�n'), true, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.agente')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Agente'), 'agente.php', $this->RenderText('Agente'), $currentPageCaption == $this->RenderText('Agente'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.dependencia')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Dependencia'), 'dependencia.php', $this->RenderText('Dependencia'), $currentPageCaption == $this->RenderText('Dependencia'), true, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.ubicacion_fisica')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ubicacion Fisica'), 'ubicacion_fisica.php', $this->RenderText('Ubicacion Fisica'), $currentPageCaption == $this->RenderText('Ubicacion Fisica'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.puesto')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Puesto'), 'puesto.php', $this->RenderText('Puesto'), $currentPageCaption == $this->RenderText('Puesto'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.salario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Honorario'), 'honorario.php', $this->RenderText('Honorario'), $currentPageCaption == $this->RenderText('Honorario'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Contrato'), 'contrato.php', $this->RenderText('Contrato'), $currentPageCaption == $this->RenderText('Contrato'), false, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.tipo_contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Tipo Contrato'), 'tipo_contrato.php', $this->RenderText('Tipo Contrato'), $currentPageCaption == $this->RenderText('Tipo Contrato'), true, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.categoria_lm')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Categoria LM'), 'categoria_lm.php', $this->RenderText('Categoria Ley Marco'), $currentPageCaption == $this->RenderText('Categoria LM'), false, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.convenio_at')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Convenio AT'), 'convenio_at.php', $this->RenderText('Convenio Asistencia Tecnica'), $currentPageCaption == $this->RenderText('Convenio AT'), false, $this->RenderText('Contratos')));
            
            if ( HasAdminPage() && GetApplication()->HasAdminGrantForCurrentUser() ) {
              $result->AddGroup('Admin area');
              $result->AddPage(new PageLink($this->GetLocalizerCaptions()->GetMessageString('AdminPage'), 'phpgen_admin.php', $this->GetLocalizerCaptions()->GetMessageString('AdminPage'), false, false, 'Admin area'));
            }
            return $result;
        }
    
        protected function CreateRssGenerator()
        {
            return null;
        }
    
        protected function CreateGridSearchControl(Grid $grid)
        {
            $grid->UseFilter = true;
            $grid->SearchControl = new SimpleSearch('public_convenio_atssearch', $this->dataset,
                array('id_convenio_at', 'no_convenio_at', 'ds_universidad'),
                array($this->RenderText('Convenio AT'), $this->RenderText('Nombre Convenio AT'), $this->RenderText('Universidad Convenio')),
                array(
                    '=' => $this->GetLocalizerCaptions()->GetMessageString('equals'),
                    '<>' => $this->GetLocalizerCaptions()->GetMessageString('doesNotEquals'),
                    '<' => $this->GetLocalizerCaptions()->GetMessageString('isLessThan'),
                    '<=' => $this->GetLocalizerCaptions()->GetMessageString('isLessThanOrEqualsTo'),
                    '>' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThan'),
                    '>=' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThanOrEqualsTo'),
                    'ILIKE' => $this->GetLocalizerCaptions()->GetMessageString('Like'),
                    'STARTS' => $this->GetLocalizerCaptions()->GetMessageString('StartsWith'),
                    'ENDS' => $this->GetLocalizerCaptions()->GetMessageString('EndsWith'),
                    'CONTAINS' => $this->GetLocalizerCaptions()->GetMessageString('Contains')
                    ), $this->GetLocalizerCaptions(), $this, 'CONTAINS'
                );
        }
    
        protected function CreateGridAdvancedSearchControl(Grid $grid)
        {
            $this->AdvancedSearchControl = new AdvancedSearchControl('public_convenio_atasearch', $this->dataset, $this->GetLocalizerCaptions(), $this->GetColumnVariableContainer(), $this->CreateLinkBuilder());
            $this->AdvancedSearchControl->setTimerInterval(1000);
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('id_convenio_at', $this->RenderText('Convenio AT')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('no_convenio_at', $this->RenderText('Nombre Convenio AT')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('ds_universidad', $this->RenderText('Universidad Convenio')));
        }
    
        protected function AddOperationsColumns(Grid $grid)
        {
            $actionsBandName = 'actions';
            $grid->AddBandToBegin($actionsBandName, $this->GetLocalizerCaptions()->GetMessageString('Actions'), true);
            if ($this->GetSecurityInfo()->HasViewGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('View'), OPERATION_VIEW, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
            if ($this->GetSecurityInfo()->HasEditGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Edit'), OPERATION_EDIT, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowEditButtonHandler', $this);
            }
            if ($this->GetSecurityInfo()->HasDeleteGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Delete'), OPERATION_DELETE, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowDeleteButtonHandler', $this);
                $column->SetAdditionalAttribute('data-modal-delete', 'true');
                $column->SetAdditionalAttribute('data-delete-handler-name', $this->GetModalGridDeleteHandler());
            }
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Copy'), OPERATION_COPY, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
        }
    
        protected function AddFieldColumns(Grid $grid)
        {
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('no_convenio_at', 'Nombre Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_convenio_atGrid_no_convenio_at_handler_list');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $column->SetDescription($this->RenderText('Nombre del convenio de Asistencia T�cnica.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for ds_universidad field
            //
            $column = new TextViewColumn('ds_universidad', 'Universidad Convenio', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_convenio_atGrid_ds_universidad_handler_list');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $column->SetDescription($this->RenderText('Universidad con la que se encuentra firmado el convenio.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
        }
    
        protected function AddSingleRecordViewColumns(Grid $grid)
        {
            //
            // View column for id_convenio_at field
            //
            $column = new TextViewColumn('id_convenio_at', 'Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('no_convenio_at', 'Nombre Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_convenio_atGrid_no_convenio_at_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_universidad field
            //
            $column = new TextViewColumn('ds_universidad', 'Universidad Convenio', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_convenio_atGrid_ds_universidad_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
        }
    
        protected function AddEditColumns(Grid $grid)
        {
            //
            // Edit column for no_convenio_at field
            //
            $editor = new TextEdit('no_convenio_at_edit');
            $editor->SetSize(100);
            $editor->SetMaxLength(100);
            $editColumn = new CustomEditColumn('Nombre Convenio AT', 'no_convenio_at', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ds_universidad field
            //
            $editor = new TextAreaEdit('ds_universidad_edit', 50, 8);
            $editColumn = new CustomEditColumn('Universidad Convenio', 'ds_universidad', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
        }
    
        protected function AddInsertColumns(Grid $grid)
        {
            //
            // Edit column for no_convenio_at field
            //
            $editor = new TextEdit('no_convenio_at_edit');
            $editor->SetSize(100);
            $editor->SetMaxLength(100);
            $editColumn = new CustomEditColumn('Nombre Convenio AT', 'no_convenio_at', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ds_universidad field
            //
            $editor = new TextAreaEdit('ds_universidad_edit', 50, 8);
            $editColumn = new CustomEditColumn('Universidad Convenio', 'ds_universidad', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $grid->SetShowAddButton(true);
                $grid->SetShowInlineAddButton(false);
            }
            else
            {
                $grid->SetShowInlineAddButton(false);
                $grid->SetShowAddButton(false);
            }
        }
    
        protected function AddPrintColumns(Grid $grid)
        {
            //
            // View column for id_convenio_at field
            //
            $column = new TextViewColumn('id_convenio_at', 'Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('no_convenio_at', 'No Convenio At', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_universidad field
            //
            $column = new TextViewColumn('ds_universidad', 'Ds Universidad', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
        }
    
        protected function AddExportColumns(Grid $grid)
        {
            //
            // View column for id_convenio_at field
            //
            $column = new TextViewColumn('id_convenio_at', 'Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('no_convenio_at', 'No Convenio At', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_universidad field
            //
            $column = new TextViewColumn('ds_universidad', 'Ds Universidad', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
        }
    
        public function GetPageDirection()
        {
            return null;
        }
    
        protected function ApplyCommonColumnEditProperties(CustomEditColumn $column)
        {
            $column->SetDisplaySetToNullCheckBox(false);
            $column->SetDisplaySetToDefaultCheckBox(false);
    		$column->SetVariableContainer($this->GetColumnVariableContainer());
        }
    
        function GetCustomClientScript()
        {
            return ;
        }
        
        function GetOnPageLoadedClientScript()
        {
            return ;
        }
        public function ShowEditButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasEditGrant($this->GetDataset());
        }
        public function ShowDeleteButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasDeleteGrant($this->GetDataset());
        }
        
        public function GetModalGridDeleteHandler() { return 'public_convenio_at_modal_delete'; }
        protected function GetEnableModalGridDelete() { return true; }
    
        protected function CreateGrid()
        {
            $result = new Grid($this, $this->dataset, 'public_convenio_atGrid');
            if ($this->GetSecurityInfo()->HasDeleteGrant())
               $result->SetAllowDeleteSelected(false);
            else
               $result->SetAllowDeleteSelected(false);   
            
            ApplyCommonPageSettings($this, $result);
            
            $result->SetUseImagesForActions(true);
            $result->SetUseFixedHeader(false);
            $result->SetShowLineNumbers(false);
            $result->SetShowKeyColumnsImagesInHeader(false);
            
            $result->SetHighlightRowAtHover(true);
            $result->SetWidth('');
            $this->CreateGridSearchControl($result);
            $this->CreateGridAdvancedSearchControl($result);
            $this->AddOperationsColumns($result);
            $this->AddFieldColumns($result);
            $this->AddSingleRecordViewColumns($result);
            $this->AddEditColumns($result);
            $this->AddInsertColumns($result);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
    
            $this->SetShowPageList(true);
            $this->SetHidePageListByDefault(false);
            $this->SetExportToExcelAvailable(true);
            $this->SetExportToWordAvailable(true);
            $this->SetExportToXmlAvailable(true);
            $this->SetExportToCsvAvailable(true);
            $this->SetExportToPdfAvailable(true);
            $this->SetPrinterFriendlyAvailable(true);
            $this->SetSimpleSearchAvailable(true);
            $this->SetAdvancedSearchAvailable(true);
            $this->SetFilterRowAvailable(true);
            $this->SetVisualEffectsEnabled(true);
            $this->SetShowTopPageNavigator(true);
            $this->SetShowBottomPageNavigator(true);
    
            //
            // Http Handlers
            //
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('no_convenio_at', 'Nombre Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_convenio_atGrid_no_convenio_at_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_universidad field
            //
            $column = new TextViewColumn('ds_universidad', 'Universidad Convenio', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_convenio_atGrid_ds_universidad_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);//
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('no_convenio_at', 'Nombre Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_convenio_atGrid_no_convenio_at_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_universidad field
            //
            $column = new TextViewColumn('ds_universidad', 'Universidad Convenio', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_convenio_atGrid_ds_universidad_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            return $result;
        }
        
        public function OpenAdvancedSearchByDefault()
        {
            return false;
        }
    
        protected function DoGetGridHeader()
        {
            return '';
        }
    }

    SetUpUserAuthorization(GetApplication());

    try
    {
        $Page = new public_convenio_atPage("convenio_at.php", "public_convenio_at", GetCurrentUserGrantForDataSource("public.convenio_at"), 'UTF-8');
        $Page->SetShortCaption('Convenio AT');
        $Page->SetHeader(GetPagesHeader());
        $Page->SetFooter(GetPagesFooter());
        $Page->SetCaption('Convenio Asistencia Tecnica');
        $Page->SetRecordPermission(GetCurrentUserRecordPermissionsForDataSource("public.convenio_at"));
        GetApplication()->SetEnableLessRunTimeCompile(GetEnableLessFilesRunTimeCompilation());
        GetApplication()->SetCanUserChangeOwnPassword(
            !function_exists('CanUserChangeOwnPassword') || CanUserChangeOwnPassword());
        GetApplication()->SetMainPage($Page);
        GetApplication()->Run();
    }
    catch(Exception $e)
    {
        ShowErrorPage($e->getMessage());
    }
	
