<?php

require_once 'components/page.php';
require_once 'components/security/datasource_security_info.php';
require_once 'components/security/security_info.php';
require_once 'components/security/hardcoded_auth.php';
require_once 'components/security/user_grants_manager.php';

include_once 'components/security/user_identity_storage/user_identity_session_storage.php';

$users = array('facturas' => 'facturas');

$usersIds = array('facturas' => -1);

$dataSourceRecordPermissions = array();

$grants = array('guest' => 
        array()
    ,
    'defaultUser' => 
        array('public.factura' => new DataSourceSecurityInfo(false, false, false, false),
        'public.certificacion' => new DataSourceSecurityInfo(false, false, false, false),
        'public.agente' => new DataSourceSecurityInfo(false, false, false, false),
        'public.dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'public.ubicacion_fisica' => new DataSourceSecurityInfo(false, false, false, false),
        'public.puesto' => new DataSourceSecurityInfo(false, false, false, false),
        'public.salario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.categoria_lm' => new DataSourceSecurityInfo(false, false, false, false),
        'public.convenio_at' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_mes' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_salario' => new DataSourceSecurityInfo(false, false, false, false),
        'estado_lote' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_lote_cert' => new DataSourceSecurityInfo(false, false, false, false))
    ,
    'guest' => 
        array('public.factura' => new DataSourceSecurityInfo(false, false, false, false),
        'public.certificacion' => new DataSourceSecurityInfo(false, false, false, false),
        'public.agente' => new DataSourceSecurityInfo(false, false, false, false),
        'public.dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'public.ubicacion_fisica' => new DataSourceSecurityInfo(false, false, false, false),
        'public.puesto' => new DataSourceSecurityInfo(false, false, false, false),
        'public.salario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.categoria_lm' => new DataSourceSecurityInfo(false, false, false, false),
        'public.convenio_at' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_mes' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_salario' => new DataSourceSecurityInfo(false, false, false, false),
        'estado_lote' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_lote_cert' => new DataSourceSecurityInfo(false, false, false, false))
    ,
    'facturas' => 
        array('public.factura' => new DataSourceSecurityInfo(false, false, false, false),
        'public.certificacion' => new DataSourceSecurityInfo(false, false, false, false),
        'public.agente' => new DataSourceSecurityInfo(false, false, false, false),
        'public.dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'public.ubicacion_fisica' => new DataSourceSecurityInfo(false, false, false, false),
        'public.puesto' => new DataSourceSecurityInfo(false, false, false, false),
        'public.salario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.categoria_lm' => new DataSourceSecurityInfo(false, false, false, false),
        'public.convenio_at' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_mes' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_salario' => new DataSourceSecurityInfo(false, false, false, false),
        'estado_lote' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_lote_cert' => new DataSourceSecurityInfo(false, false, false, false))
    );

$appGrants = array('guest' => new DataSourceSecurityInfo(false, false, false, false),
    'defaultUser' => new DataSourceSecurityInfo(true, false, false, false),
    'guest' => new DataSourceSecurityInfo(false, false, false, false),
    'facturas' => new AdminDataSourceSecurityInfo());

$tableCaptions = array('public.factura' => 'Factura',
'public.certificacion' => 'Lote Certificaci�n',
'public.agente' => 'Agente',
'public.dependencia' => 'Dependencia',
'public.ubicacion_fisica' => 'Ubicacion Fisica',
'public.puesto' => 'Puesto',
'public.salario' => 'Honorario',
'public.contrato' => 'Contrato',
'public.tipo_contrato' => 'Tipo Contrato',
'public.categoria_lm' => 'Categoria LM',
'public.convenio_at' => 'Convenio AT',
'ver_mes' => 'Ver Mes',
'ver_contrato' => 'Ver Contrato',
'ver_dependencia' => 'Ver Dependencia',
'ver_salario' => 'Ver Salario',
'estado_lote' => 'Estado Lote',
'ver_lote_cert' => 'Ver Lote Cert');

function SetUpUserAuthorization()
{
    global $usersIds;
    global $grants;
    global $appGrants;
    global $dataSourceRecordPermissions;
    $userAuthorizationStrategy = new HardCodedUserAuthorization(new UserIdentitySessionStorage(GetIdentityCheckStrategy()), new HardCodedUserGrantsManager($grants, $appGrants), $usersIds);
    GetApplication()->SetUserAuthorizationStrategy($userAuthorizationStrategy);

GetApplication()->SetDataSourceRecordPermissionRetrieveStrategy(
    new HardCodedDataSourceRecordPermissionRetrieveStrategy($dataSourceRecordPermissions));
}

function GetIdentityCheckStrategy()
{
    global $users;
    return new SimpleIdentityCheckStrategy($users, '');
}

?>