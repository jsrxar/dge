<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                   ATTENTION!
 * If you see this message in your browser (Internet Explorer, Mozilla Firefox, Google Chrome, etc.)
 * this means that PHP is not properly installed on your web server. Please refer to the PHP manual
 * for more details: http://php.net/manual/install.php 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */


    include_once dirname(__FILE__) . '/' . 'components/utils/check_utils.php';
    CheckPHPVersion();
    CheckTemplatesCacheFolderIsExistsAndWritable();


    include_once dirname(__FILE__) . '/' . 'phpgen_settings.php';
    include_once dirname(__FILE__) . '/' . 'database_engine/pgsql_engine.php';
    include_once dirname(__FILE__) . '/' . 'components/page.php';
    include_once dirname(__FILE__) . '/' . 'authorization.php';

    function GetConnectionOptions()
    {
        $result = GetGlobalConnectionOptions();
        $result['client_encoding'] = 'utf8';
        GetApplication()->GetUserAuthorizationStrategy()->ApplyIdentityToConnectionOptions($result);
        return $result;
    }

    
    // OnGlobalBeforePageExecute event handler
    
    
    // OnBeforePageExecute event handler
    
    
    
    class public_facturaPage extends Page
    {
        protected function DoBeforeCreate()
        {
            $this->dataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."factura"');
            $field = new IntegerField('id_factura', null, null, true);
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, true);
            $field = new IntegerField('id_salario');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new IntegerField('nu_pto_venta');
            $this->dataset->AddField($field, false);
            $field = new IntegerField('nu_factura');
            $this->dataset->AddField($field, false);
            $field = new DateField('fe_factura');
            $this->dataset->AddField($field, false);
            $field = new DateTimeField('fe_carga');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new IntegerField('va_factura');
            $this->dataset->AddField($field, false);
            $field = new BlobField('ar_factura');
            $this->dataset->AddField($field, false);
            $field = new BooleanField('fl_rechazo');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_comentario');
            $this->dataset->AddField($field, false);
            $field = new IntegerField('id_certificacion');
            $this->dataset->AddField($field, false);
            $field = new IntegerField('id_convenio_at');
            $this->dataset->AddField($field, false);
            $this->dataset->AddLookupField('id_salario', '(SELECT
                  id_salario,
                  id_contrato,
                  (SELECT ag.no_agente
                   FROM agente ag, contrato co
                   WHERE co.id_contrato = sa.id_contrato
                     AND ag.id_agente = co.id_agente) || \' - \' ||
                  TO_CHAR(TO_DATE(CAST(sa.id_mes AS TEXT), \'YYYYMM\'), \'MM/YYYY\')  ||
                  \' (\' || CAST(CAST(sa.va_salario AS NUMERIC) AS MONEY) ||\')\' AS ds_salario
            FROM salario sa
            ORDER BY id_mes)', new IntegerField('id_salario'), new StringField('ds_salario', 'id_salario_ds_salario', 'id_salario_ds_salario_ver_salario'), 'id_salario_ds_salario_ver_salario');
            $this->dataset->AddLookupField('id_certificacion', '(SELECT
            id_certificacion AS id,
            (SELECT no_convenio_at FROM convenio_at WHERE id_convenio_at = ce.id_convenio_at ) ||
            \' - Lote \' || id_certificacion ||
            CASE co_estado WHEN \'P\' THEN \' (PreCertificado) \'
            WHEN \'C\' THEN \' (Certificado) \' ELSE \' (Anulado) \' END ||
            TO_CHAR(COALESCE(fe_certificacion, fe_creacion), \'DD/MM/YYYY\') AS nombre
            FROM certificacion ce)', new IntegerField('id'), new StringField('nombre', 'id_certificacion_nombre', 'id_certificacion_nombre_ver_lote_cert'), 'id_certificacion_nombre_ver_lote_cert');
            $this->dataset->AddLookupField('id_convenio_at', 'public.convenio_at', new IntegerField('id_convenio_at', null, null, true), new StringField('no_convenio_at', 'id_convenio_at_no_convenio_at', 'id_convenio_at_no_convenio_at_public_convenio_at'), 'id_convenio_at_no_convenio_at_public_convenio_at');
            $this->dataset->AddCustomCondition(EnvVariablesUtils::EvaluateVariableTemplate($this->GetColumnVariableContainer(), 'fl_rechazo IS FALSE'));
        }
    
        protected function DoPrepare() {
    
        }
    
        protected function CreatePageNavigator()
        {
            $result = new CompositePageNavigator($this);
            
            $partitionNavigator = new PageNavigator('pnav', $this, $this->dataset);
            $partitionNavigator->SetRowsPerPage(100);
            $result->AddPageNavigator($partitionNavigator);
            
            return $result;
        }
    
        public function GetPageList()
        {
            $currentPageCaption = $this->GetShortCaption();
            $result = new PageList($this);
            $result->AddGroup($this->RenderText('Facturas'));
            $result->AddGroup($this->RenderText('Agentes'));
            $result->AddGroup($this->RenderText('Contratos'));
            if (GetCurrentUserGrantForDataSource('public.factura')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Factura'), 'factura.php', $this->RenderText('Factura'), $currentPageCaption == $this->RenderText('Factura'), false, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.certificacion')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Lote Certificaci�n'), 'certificacion.php', $this->RenderText('Lote Certificaci�n'), $currentPageCaption == $this->RenderText('Lote Certificaci�n'), true, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.agente')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Agente'), 'agente.php', $this->RenderText('Agente'), $currentPageCaption == $this->RenderText('Agente'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.dependencia')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Dependencia'), 'dependencia.php', $this->RenderText('Dependencia'), $currentPageCaption == $this->RenderText('Dependencia'), true, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.ubicacion_fisica')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ubicacion Fisica'), 'ubicacion_fisica.php', $this->RenderText('Ubicacion Fisica'), $currentPageCaption == $this->RenderText('Ubicacion Fisica'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.puesto')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Puesto'), 'puesto.php', $this->RenderText('Puesto'), $currentPageCaption == $this->RenderText('Puesto'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.salario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Honorario'), 'honorario.php', $this->RenderText('Honorario'), $currentPageCaption == $this->RenderText('Honorario'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Contrato'), 'contrato.php', $this->RenderText('Contrato'), $currentPageCaption == $this->RenderText('Contrato'), false, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.tipo_contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Tipo Contrato'), 'tipo_contrato.php', $this->RenderText('Tipo Contrato'), $currentPageCaption == $this->RenderText('Tipo Contrato'), true, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.categoria_lm')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Categoria LM'), 'categoria_lm.php', $this->RenderText('Categoria Ley Marco'), $currentPageCaption == $this->RenderText('Categoria LM'), false, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.convenio_at')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Convenio AT'), 'convenio_at.php', $this->RenderText('Convenio Asistencia Tecnica'), $currentPageCaption == $this->RenderText('Convenio AT'), false, $this->RenderText('Contratos')));
            
            if ( HasAdminPage() && GetApplication()->HasAdminGrantForCurrentUser() ) {
              $result->AddGroup('Admin area');
              $result->AddPage(new PageLink($this->GetLocalizerCaptions()->GetMessageString('AdminPage'), 'phpgen_admin.php', $this->GetLocalizerCaptions()->GetMessageString('AdminPage'), false, false, 'Admin area'));
            }
            return $result;
        }
    
        protected function CreateRssGenerator()
        {
            return null;
        }
    
        protected function CreateGridSearchControl(Grid $grid)
        {
            $grid->UseFilter = true;
            $grid->SearchControl = new SimpleSearch('public_facturassearch', $this->dataset,
                array('id_factura', 'id_salario_ds_salario', 'nu_pto_venta', 'nu_factura', 'fe_factura', 'fe_carga', 'va_factura', 'fl_rechazo', 'ds_comentario', 'id_certificacion_nombre', 'id_convenio_at_no_convenio_at'),
                array($this->RenderText('ID Factura'), $this->RenderText('Honorario'), $this->RenderText('Punto Venta'), $this->RenderText('N�mero Factura'), $this->RenderText('Fecha Factura'), $this->RenderText('Fecha Carga'), $this->RenderText('Monto Factura'), $this->RenderText('Rechazada?'), $this->RenderText('Comentario Factura'), $this->RenderText('Lote Certificaci�n'), $this->RenderText('Convenio AT')),
                array(
                    '=' => $this->GetLocalizerCaptions()->GetMessageString('equals'),
                    '<>' => $this->GetLocalizerCaptions()->GetMessageString('doesNotEquals'),
                    '<' => $this->GetLocalizerCaptions()->GetMessageString('isLessThan'),
                    '<=' => $this->GetLocalizerCaptions()->GetMessageString('isLessThanOrEqualsTo'),
                    '>' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThan'),
                    '>=' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThanOrEqualsTo'),
                    'ILIKE' => $this->GetLocalizerCaptions()->GetMessageString('Like'),
                    'STARTS' => $this->GetLocalizerCaptions()->GetMessageString('StartsWith'),
                    'ENDS' => $this->GetLocalizerCaptions()->GetMessageString('EndsWith'),
                    'CONTAINS' => $this->GetLocalizerCaptions()->GetMessageString('Contains')
                    ), $this->GetLocalizerCaptions(), $this, 'CONTAINS'
                );
        }
    
        protected function CreateGridAdvancedSearchControl(Grid $grid)
        {
            $this->AdvancedSearchControl = new AdvancedSearchControl('public_facturaasearch', $this->dataset, $this->GetLocalizerCaptions(), $this->GetColumnVariableContainer(), $this->CreateLinkBuilder());
            $this->AdvancedSearchControl->setTimerInterval(1000);
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('id_factura', $this->RenderText('ID Factura')));
            
            $selectQuery = 'SELECT
                  id_salario,
                  id_contrato,
                  (SELECT ag.no_agente
                   FROM agente ag, contrato co
                   WHERE co.id_contrato = sa.id_contrato
                     AND ag.id_agente = co.id_agente) || \' - \' ||
                  TO_CHAR(TO_DATE(CAST(sa.id_mes AS TEXT), \'YYYYMM\'), \'MM/YYYY\')  ||
                  \' (\' || CAST(CAST(sa.va_salario AS NUMERIC) AS MONEY) ||\')\' AS ds_salario
            FROM salario sa
            ORDER BY id_mes';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_salario');
            $field = new IntegerField('id_salario');
            $lookupDataset->AddField($field, true);
            $field = new IntegerField('id_contrato');
            $lookupDataset->AddField($field, false);
            $field = new StringField('ds_salario');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_salario', GetOrderTypeAsSQL(otAscending));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateLookupSearchInput('id_salario', $this->RenderText('Honorario'), $lookupDataset, 'id_salario', 'ds_salario', false, 8));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('nu_pto_venta', $this->RenderText('Punto Venta')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('nu_factura', $this->RenderText('N�mero Factura')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateDateTimeSearchInput('fe_factura', $this->RenderText('Fecha Factura'), 'd/m/Y'));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateDateTimeSearchInput('fe_carga', $this->RenderText('Fecha Carga'), 'd/m/Y'));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('va_factura', $this->RenderText('Monto Factura')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateBlobSearchInput('ar_factura', $this->RenderText('Archivo Factura')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('fl_rechazo', $this->RenderText('Rechazada?')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('ds_comentario', $this->RenderText('Comentario Factura')));
            
            $selectQuery = 'SELECT
            id_certificacion AS id,
            (SELECT no_convenio_at FROM convenio_at WHERE id_convenio_at = ce.id_convenio_at ) ||
            \' - Lote \' || id_certificacion ||
            CASE co_estado WHEN \'P\' THEN \' (PreCertificado) \'
            WHEN \'C\' THEN \' (Certificado) \' ELSE \' (Anulado) \' END ||
            TO_CHAR(COALESCE(fe_certificacion, fe_creacion), \'DD/MM/YYYY\') AS nombre
            FROM certificacion ce';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_lote_cert');
            $field = new IntegerField('id');
            $lookupDataset->AddField($field, true);
            $field = new StringField('nombre');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('nombre', GetOrderTypeAsSQL(otAscending));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateLookupSearchInput('id_certificacion', $this->RenderText('Lote Certificaci�n'), $lookupDataset, 'id', 'nombre', false, 8));
            
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."convenio_at"');
            $field = new IntegerField('id_convenio_at', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_convenio_at');
            $lookupDataset->AddField($field, false);
            $field = new StringField('ds_universidad');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_convenio_at', GetOrderTypeAsSQL(otAscending));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateLookupSearchInput('id_convenio_at', $this->RenderText('Convenio AT'), $lookupDataset, 'id_convenio_at', 'no_convenio_at', false, 8));
        }
    
        protected function AddOperationsColumns(Grid $grid)
        {
            $actionsBandName = 'actions';
            $grid->AddBandToBegin($actionsBandName, $this->GetLocalizerCaptions()->GetMessageString('Actions'), true);
            if ($this->GetSecurityInfo()->HasViewGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('View'), OPERATION_VIEW, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
            if ($this->GetSecurityInfo()->HasEditGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Edit'), OPERATION_EDIT, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowEditButtonHandler', $this);
            }
            if ($this->GetSecurityInfo()->HasDeleteGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Delete'), OPERATION_DELETE, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowDeleteButtonHandler', $this);
                $column->SetAdditionalAttribute('data-modal-delete', 'true');
                $column->SetAdditionalAttribute('data-delete-handler-name', $this->GetModalGridDeleteHandler());
            }
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Copy'), OPERATION_COPY, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
        }
    
        protected function AddFieldColumns(Grid $grid)
        {
            //
            // View column for ds_salario field
            //
            $column = new TextViewColumn('id_salario_ds_salario', 'Honorario', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'honorario.php?operation=view&amp;pk0=%id_salario%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $column->SetDescription($this->RenderText('Honorario del agente al que afecta la factura.'));
            $column->SetFixedWidth('500px');
            $grid->AddViewColumn($column);
            
            //
            // View column for fe_factura field
            //
            $column = new DateTimeViewColumn('fe_factura', 'Fecha Factura', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $column->SetDescription($this->RenderText('Fecha de la factura.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for va_factura field
            //
            $column = new TextViewColumn('va_factura', 'Monto Factura', $this->dataset);
            $column->SetOrderable(true);
            $column = new CurrencyFormatValueViewColumnDecorator($column, 2, '.', ',', $this->RenderText('$ '));
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $column->SetDescription($this->RenderText('Monto de la factura.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for ar_factura field
            //
            $column = new DownloadDataColumn('ar_factura', 'Archivo Factura', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $column->SetDescription($this->RenderText('Archivo de imagen de la factura.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for fl_rechazo field
            //
            $column = new TextViewColumn('fl_rechazo', 'Rechazada?', $this->dataset);
            $column->SetOrderable(true);
            $column = new CheckBoxFormatValueViewColumnDecorator($column);
            $column->SetDisplayValues($this->RenderText('<img src="images/checked.png" alt="true">'), $this->RenderText(''));
            $column->SetDescription($this->RenderText('Indicador de rechazo de la factura.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for nombre field
            //
            $column = new TextViewColumn('id_certificacion_nombre', 'Lote Certificaci�n', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDescription($this->RenderText('Lote de certificaci�n de las facturas.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('id_convenio_at_no_convenio_at', 'Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDescription($this->RenderText('Convenio de Asistencia T�cnica asociado a la factura.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
        }
    
        protected function AddSingleRecordViewColumns(Grid $grid)
        {
            //
            // View column for id_factura field
            //
            $column = new TextViewColumn('id_factura', 'ID Factura', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_salario field
            //
            $column = new TextViewColumn('id_salario_ds_salario', 'Honorario', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'honorario.php?operation=view&amp;pk0=%id_salario%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for nu_pto_venta field
            //
            $column = new TextViewColumn('nu_pto_venta', 'Punto Venta', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(4);
            $column->SetFullTextWindowHandlerName('public_facturaGrid_nu_pto_venta_handler_view');
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for nu_factura field
            //
            $column = new TextViewColumn('nu_factura', 'N�mero Factura', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(8);
            $column->SetFullTextWindowHandlerName('public_facturaGrid_nu_factura_handler_view');
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for fe_factura field
            //
            $column = new DateTimeViewColumn('fe_factura', 'Fecha Factura', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for fe_carga field
            //
            $column = new DateTimeViewColumn('fe_carga', 'Fecha Carga', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for va_factura field
            //
            $column = new TextViewColumn('va_factura', 'Monto Factura', $this->dataset);
            $column->SetOrderable(true);
            $column = new CurrencyFormatValueViewColumnDecorator($column, 2, '.', ',', $this->RenderText('$ '));
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ar_factura field
            //
            $column = new DownloadDataColumn('ar_factura', 'Archivo Factura', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for fl_rechazo field
            //
            $column = new TextViewColumn('fl_rechazo', 'Rechazada?', $this->dataset);
            $column->SetOrderable(true);
            $column = new CheckBoxFormatValueViewColumnDecorator($column);
            $column->SetDisplayValues($this->RenderText('<img src="images/checked.png" alt="true">'), $this->RenderText(''));
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_comentario field
            //
            $column = new TextViewColumn('ds_comentario', 'Comentario Factura', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_facturaGrid_ds_comentario_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for nombre field
            //
            $column = new TextViewColumn('id_certificacion_nombre', 'Lote Certificaci�n', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('id_convenio_at_no_convenio_at', 'Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
        }
    
        protected function AddEditColumns(Grid $grid)
        {
            //
            // Edit column for id_salario field
            //
            $editor = new MultiLevelComboBoxEditor('id_salario_edit', $this->CreateLinkBuilder());
            $editor->setInlineStyles('width:500px');
            $editor->setAllowClear(false);
            $editor->setMinimumInputLength(0);
            
            $selectQuery = 'SELECT
                  id_contrato,
                  TRIM(
                  (SELECT COALESCE(\'CUIT: \' || co_cuit || \' (\', \'SIN CUIT (\')
                          || no_agente || \')\'
                   FROM agente
                   WHERE id_agente = co.id_agente) || \' - Contrato \' ||
                  (SELECT co_tipo_contrato
                   FROM tipo_contrato
                   WHERE id_tipo_contrato = co.id_tipo_contrato)) ||
                   TO_CHAR(fe_fin, \'" (fin" DD/MM/YY")"\') AS ds_contrato
            FROM public.contrato co
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $dataset0 = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_contrato');
            $field = new IntegerField('id_contrato');
            $dataset0->AddField($field, true);
            $field = new StringField('ds_contrato');
            $dataset0->AddField($field, false);
            
            GetApplication()->RegisterHTTPHandler($editor->createHttpHandler($dataset0, 'id_contrato', 'ds_contrato', null, ArrayWrapper::createGetWrapper()));
            $level = $editor->AddLevel($dataset0, 'id_contrato', 'ds_contrato', $this->RenderText('CUIT'), null, ArrayWrapper::createGetWrapper());
            
            $selectQuery = 'SELECT
                  id_salario,
                  id_contrato,
                  (SELECT ag.no_agente
                   FROM agente ag, contrato co
                   WHERE co.id_contrato = sa.id_contrato
                     AND ag.id_agente = co.id_agente) || \' - \' ||
                  TO_CHAR(TO_DATE(CAST(sa.id_mes AS TEXT), \'YYYYMM\'), \'MM/YYYY\')  ||
                  \' (\' || CAST(CAST(sa.va_salario AS NUMERIC) AS MONEY) ||\')\' AS ds_salario
            FROM salario sa
            ORDER BY id_mes';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $dataset1 = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_salario');
            $field = new IntegerField('id_salario');
            $dataset1->AddField($field, true);
            $field = new IntegerField('id_contrato');
            $dataset1->AddField($field, false);
            $field = new StringField('ds_salario');
            $dataset1->AddField($field, false);
            $dataset1->setOrderByField('ds_salario', GetOrderTypeAsSQL(otAscending));
            
            GetApplication()->RegisterHTTPHandler($editor->createHttpHandler($dataset1, 'id_salario', 'ds_salario', new ForeignKeyInfo('id_contrato', 'id_contrato'), ArrayWrapper::createGetWrapper()));
            $level = $editor->AddLevel($dataset1, 'id_salario', 'ds_salario', $this->RenderText('Honorario'), new ForeignKeyInfo('id_contrato', 'id_contrato'), ArrayWrapper::createGetWrapper());
            $editColumn = new MultiLevelLookupEditColumn('Honorario', 'id_salario', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for nu_pto_venta field
            //
            $editor = new TextEdit('nu_pto_venta_edit');
            $editor->setCustomAttributes('onkeypress=\'return event.charCode >= 48 && event.charCode <= 57\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetPlaceholder($this->RenderText('0001'));
            $editColumn = new CustomEditColumn('Punto Venta', 'nu_pto_venta', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for nu_factura field
            //
            $editor = new TextEdit('nu_factura_edit');
            $editor->setCustomAttributes('onkeypress=\'return event.charCode >= 48 && event.charCode <= 57\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetMaxLength(8);
            $editor->SetPlaceholder($this->RenderText('00000001'));
            $editColumn = new CustomEditColumn('N�mero Factura', 'nu_factura', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fe_factura field
            //
            $editor = new DateTimeEdit('fe_factura_edit', false, 'd/m/Y', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Fecha Factura', 'fe_factura', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for va_factura field
            //
            $editor = new TextEdit('va_factura_edit');
            $editor->setCustomAttributes('onkeypress=\'return (event.charCode >= 48 && event.charCode <= 57) || event.charCode == 44\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetPrefix($this->RenderText('$'));
            $editColumn = new CustomEditColumn('Monto Factura', 'va_factura', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ar_factura field
            //
            $editor = new ImageUploader('ar_factura_edit');
            $editor->SetShowImage(false);
            $editColumn = new FileUploadingColumn('Archivo Factura', 'ar_factura', $editor, $this->dataset, false, false, 'public_facturaGrid_ar_factura_handler_edit');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fl_rechazo field
            //
            $editor = new CheckBox('fl_rechazo_edit');
            $editColumn = new CustomEditColumn('Rechazada?', 'fl_rechazo', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ds_comentario field
            //
            $editor = new TextAreaEdit('ds_comentario_edit', 50, 8);
            $editColumn = new CustomEditColumn('Comentario Factura', 'ds_comentario', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
        }
    
        protected function AddInsertColumns(Grid $grid)
        {
            //
            // Edit column for id_salario field
            //
            $editor = new MultiLevelComboBoxEditor('id_salario_edit', $this->CreateLinkBuilder());
            $editor->setInlineStyles('width:500px');
            $editor->setAllowClear(false);
            $editor->setMinimumInputLength(0);
            
            $selectQuery = 'SELECT
                  id_contrato,
                  TRIM(
                  (SELECT COALESCE(\'CUIT: \' || co_cuit || \' (\', \'SIN CUIT (\')
                          || no_agente || \')\'
                   FROM agente
                   WHERE id_agente = co.id_agente) || \' - Contrato \' ||
                  (SELECT co_tipo_contrato
                   FROM tipo_contrato
                   WHERE id_tipo_contrato = co.id_tipo_contrato)) ||
                   TO_CHAR(fe_fin, \'" (fin" DD/MM/YY")"\') AS ds_contrato
            FROM public.contrato co
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $dataset0 = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_contrato');
            $field = new IntegerField('id_contrato');
            $dataset0->AddField($field, true);
            $field = new StringField('ds_contrato');
            $dataset0->AddField($field, false);
            
            GetApplication()->RegisterHTTPHandler($editor->createHttpHandler($dataset0, 'id_contrato', 'ds_contrato', null, ArrayWrapper::createGetWrapper()));
            $level = $editor->AddLevel($dataset0, 'id_contrato', 'ds_contrato', $this->RenderText('CUIT'), null, ArrayWrapper::createGetWrapper());
            
            $selectQuery = 'SELECT
                  id_salario,
                  id_contrato,
                  (SELECT ag.no_agente
                   FROM agente ag, contrato co
                   WHERE co.id_contrato = sa.id_contrato
                     AND ag.id_agente = co.id_agente) || \' - \' ||
                  TO_CHAR(TO_DATE(CAST(sa.id_mes AS TEXT), \'YYYYMM\'), \'MM/YYYY\')  ||
                  \' (\' || CAST(CAST(sa.va_salario AS NUMERIC) AS MONEY) ||\')\' AS ds_salario
            FROM salario sa
            ORDER BY id_mes';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $dataset1 = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_salario');
            $field = new IntegerField('id_salario');
            $dataset1->AddField($field, true);
            $field = new IntegerField('id_contrato');
            $dataset1->AddField($field, false);
            $field = new StringField('ds_salario');
            $dataset1->AddField($field, false);
            $dataset1->setOrderByField('ds_salario', GetOrderTypeAsSQL(otAscending));
            
            GetApplication()->RegisterHTTPHandler($editor->createHttpHandler($dataset1, 'id_salario', 'ds_salario', new ForeignKeyInfo('id_contrato', 'id_contrato'), ArrayWrapper::createGetWrapper()));
            $level = $editor->AddLevel($dataset1, 'id_salario', 'ds_salario', $this->RenderText('Honorario'), new ForeignKeyInfo('id_contrato', 'id_contrato'), ArrayWrapper::createGetWrapper());
            $editColumn = new MultiLevelLookupEditColumn('Honorario', 'id_salario', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for nu_pto_venta field
            //
            $editor = new TextEdit('nu_pto_venta_edit');
            $editor->setCustomAttributes('onkeypress=\'return event.charCode >= 48 && event.charCode <= 57\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetPlaceholder($this->RenderText('0001'));
            $editColumn = new CustomEditColumn('Punto Venta', 'nu_pto_venta', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for nu_factura field
            //
            $editor = new TextEdit('nu_factura_edit');
            $editor->setCustomAttributes('onkeypress=\'return event.charCode >= 48 && event.charCode <= 57\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetMaxLength(8);
            $editor->SetPlaceholder($this->RenderText('00000001'));
            $editColumn = new CustomEditColumn('N�mero Factura', 'nu_factura', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fe_factura field
            //
            $editor = new DateTimeEdit('fe_factura_edit', false, 'd/m/Y', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Fecha Factura', 'fe_factura', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for va_factura field
            //
            $editor = new TextEdit('va_factura_edit');
            $editor->setCustomAttributes('onkeypress=\'return (event.charCode >= 48 && event.charCode <= 57) || event.charCode == 44\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetPrefix($this->RenderText('$'));
            $editColumn = new CustomEditColumn('Monto Factura', 'va_factura', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ar_factura field
            //
            $editor = new ImageUploader('ar_factura_edit');
            $editor->SetShowImage(false);
            $editColumn = new FileUploadingColumn('Archivo Factura', 'ar_factura', $editor, $this->dataset, false, false, 'public_facturaGrid_ar_factura_handler_insert');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fl_rechazo field
            //
            $editor = new CheckBox('fl_rechazo_edit');
            $editColumn = new CustomEditColumn('Rechazada?', 'fl_rechazo', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ds_comentario field
            //
            $editor = new TextAreaEdit('ds_comentario_edit', 50, 8);
            $editColumn = new CustomEditColumn('Comentario Factura', 'ds_comentario', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $grid->SetShowAddButton(true);
                $grid->SetShowInlineAddButton(false);
            }
            else
            {
                $grid->SetShowInlineAddButton(false);
                $grid->SetShowAddButton(false);
            }
        }
    
        protected function AddPrintColumns(Grid $grid)
        {
            //
            // View column for id_factura field
            //
            $column = new TextViewColumn('id_factura', 'ID Factura', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_salario field
            //
            $column = new TextViewColumn('id_salario_ds_salario', 'Honorario', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'honorario.php?operation=view&amp;pk0=%id_salario%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddPrintColumn($column);
            
            //
            // View column for nu_pto_venta field
            //
            $column = new TextViewColumn('nu_pto_venta', 'Punto Venta', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(4);
            $column->SetFullTextWindowHandlerName('public_facturaGrid_nu_pto_venta_handler_print');
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddPrintColumn($column);
            
            //
            // View column for nu_factura field
            //
            $column = new TextViewColumn('nu_factura', 'N�mero Factura', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(8);
            $column->SetFullTextWindowHandlerName('public_facturaGrid_nu_factura_handler_print');
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddPrintColumn($column);
            
            //
            // View column for fe_factura field
            //
            $column = new DateTimeViewColumn('fe_factura', 'Fecha Factura', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for fe_carga field
            //
            $column = new DateTimeViewColumn('fe_carga', 'Fecha Carga', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for va_factura field
            //
            $column = new TextViewColumn('va_factura', 'Monto Factura', $this->dataset);
            $column->SetOrderable(true);
            $column = new CurrencyFormatValueViewColumnDecorator($column, 2, '.', ',', $this->RenderText('$ '));
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddPrintColumn($column);
            
            //
            // View column for ar_factura field
            //
            $column = new DownloadDataColumn('ar_factura', 'Archivo Factura', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $grid->AddPrintColumn($column);
            
            //
            // View column for fl_rechazo field
            //
            $column = new TextViewColumn('fl_rechazo', 'Rechazada?', $this->dataset);
            $column->SetOrderable(true);
            $column = new CheckBoxFormatValueViewColumnDecorator($column);
            $column->SetDisplayValues($this->RenderText('<img src="images/checked.png" alt="true">'), $this->RenderText(''));
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_comentario field
            //
            $column = new TextViewColumn('ds_comentario', 'Ds Comentario', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for nombre field
            //
            $column = new TextViewColumn('id_certificacion_nombre', 'Lote Certificaci�n', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('id_convenio_at_no_convenio_at', 'Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
        }
    
        protected function AddExportColumns(Grid $grid)
        {
            //
            // View column for id_factura field
            //
            $column = new TextViewColumn('id_factura', 'ID Factura', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_salario field
            //
            $column = new TextViewColumn('id_salario_ds_salario', 'Honorario', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'honorario.php?operation=view&amp;pk0=%id_salario%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddExportColumn($column);
            
            //
            // View column for nu_pto_venta field
            //
            $column = new TextViewColumn('nu_pto_venta', 'Punto Venta', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(4);
            $column->SetFullTextWindowHandlerName('public_facturaGrid_nu_pto_venta_handler_export');
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddExportColumn($column);
            
            //
            // View column for nu_factura field
            //
            $column = new TextViewColumn('nu_factura', 'N�mero Factura', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(8);
            $column->SetFullTextWindowHandlerName('public_facturaGrid_nu_factura_handler_export');
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddExportColumn($column);
            
            //
            // View column for fe_factura field
            //
            $column = new DateTimeViewColumn('fe_factura', 'Fecha Factura', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for fe_carga field
            //
            $column = new DateTimeViewColumn('fe_carga', 'Fecha Carga', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for va_factura field
            //
            $column = new TextViewColumn('va_factura', 'Monto Factura', $this->dataset);
            $column->SetOrderable(true);
            $column = new CurrencyFormatValueViewColumnDecorator($column, 2, '.', ',', $this->RenderText('$ '));
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $grid->AddExportColumn($column);
            
            //
            // View column for ar_factura field
            //
            $column = new DownloadDataColumn('ar_factura', 'Archivo Factura', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $grid->AddExportColumn($column);
            
            //
            // View column for fl_rechazo field
            //
            $column = new TextViewColumn('fl_rechazo', 'Rechazada?', $this->dataset);
            $column->SetOrderable(true);
            $column = new CheckBoxFormatValueViewColumnDecorator($column);
            $column->SetDisplayValues($this->RenderText('<img src="images/checked.png" alt="true">'), $this->RenderText(''));
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_comentario field
            //
            $column = new TextViewColumn('ds_comentario', 'Ds Comentario', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for nombre field
            //
            $column = new TextViewColumn('id_certificacion_nombre', 'Lote Certificaci�n', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for no_convenio_at field
            //
            $column = new TextViewColumn('id_convenio_at_no_convenio_at', 'Convenio AT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
        }
    
        public function GetPageDirection()
        {
            return null;
        }
    
        protected function ApplyCommonColumnEditProperties(CustomEditColumn $column)
        {
            $column->SetDisplaySetToNullCheckBox(false);
            $column->SetDisplaySetToDefaultCheckBox(false);
    		$column->SetVariableContainer($this->GetColumnVariableContainer());
        }
    
        function GetCustomClientScript()
        {
            return ;
        }
        
        function GetOnPageLoadedClientScript()
        {
            return ;
        }
        public function ShowEditButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasEditGrant($this->GetDataset());
        }
        public function ShowDeleteButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasDeleteGrant($this->GetDataset());
        }
        
        public function GetModalGridDeleteHandler() { return 'public_factura_modal_delete'; }
        protected function GetEnableModalGridDelete() { return true; }
    
        protected function CreateGrid()
        {
            $result = new Grid($this, $this->dataset, 'public_facturaGrid');
            if ($this->GetSecurityInfo()->HasDeleteGrant())
               $result->SetAllowDeleteSelected(true);
            else
               $result->SetAllowDeleteSelected(true);   
            
            ApplyCommonPageSettings($this, $result);
            
            $result->SetUseImagesForActions(true);
            $result->SetUseFixedHeader(false);
            $result->SetShowLineNumbers(false);
            $result->SetShowKeyColumnsImagesInHeader(false);
            
            $result->SetHighlightRowAtHover(true);
            $result->SetWidth('');
            $this->CreateGridSearchControl($result);
            $this->CreateGridAdvancedSearchControl($result);
            $this->AddOperationsColumns($result);
            $this->AddFieldColumns($result);
            $this->AddSingleRecordViewColumns($result);
            $this->AddEditColumns($result);
            $this->AddInsertColumns($result);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
    
            $this->SetShowPageList(true);
            $this->SetHidePageListByDefault(false);
            $this->SetExportToExcelAvailable(true);
            $this->SetExportToWordAvailable(true);
            $this->SetExportToXmlAvailable(true);
            $this->SetExportToCsvAvailable(true);
            $this->SetExportToPdfAvailable(true);
            $this->SetPrinterFriendlyAvailable(true);
            $this->SetSimpleSearchAvailable(true);
            $this->SetAdvancedSearchAvailable(true);
            $this->SetFilterRowAvailable(true);
            $this->SetVisualEffectsEnabled(true);
            $this->SetShowTopPageNavigator(true);
            $this->SetShowBottomPageNavigator(true);
    
            //
            // Http Handlers
            //
            $handler = new DownloadHTTPHandler($this->dataset, 'ar_factura', 'ar_factura_handler', '', 'factura_%nu_pto_venta%-%nu_factura%', false);
            GetApplication()->RegisterHTTPHandler($handler);//
            // View column for nu_pto_venta field
            //
            $column = new TextViewColumn('nu_pto_venta', 'Punto Venta', $this->dataset);
            $column->SetOrderable(true);
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_facturaGrid_nu_pto_venta_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for nu_factura field
            //
            $column = new TextViewColumn('nu_factura', 'N�mero Factura', $this->dataset);
            $column->SetOrderable(true);
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_facturaGrid_nu_factura_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new DownloadHTTPHandler($this->dataset, 'ar_factura', 'ar_factura_handler', '', 'factura_%nu_pto_venta%-%nu_factura%', false);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_comentario field
            //
            $column = new TextViewColumn('ds_comentario', 'Comentario Factura', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_facturaGrid_ds_comentario_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new ImageHTTPHandler($this->dataset, 'ar_factura', 'public_facturaGrid_ar_factura_handler_edit', new NullFilter());
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new ImageHTTPHandler($this->dataset, 'ar_factura', 'public_facturaGrid_ar_factura_handler_insert', new NullFilter());
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for nu_pto_venta field
            //
            $column = new TextViewColumn('nu_pto_venta', 'Punto Venta', $this->dataset);
            $column->SetOrderable(true);
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_facturaGrid_nu_pto_venta_handler_print', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for nu_factura field
            //
            $column = new TextViewColumn('nu_factura', 'N�mero Factura', $this->dataset);
            $column->SetOrderable(true);
            $column->SetEscapeHTMLSpecialChars(true);
            $column->SetWordWrap(false);
            $column = new NumberFormatValueViewColumnDecorator($column, 0, '', '');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'right';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_facturaGrid_nu_factura_handler_print', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new DownloadHTTPHandler($this->dataset, 'ar_factura', 'ar_factura_handler', '', 'factura_%nu_pto_venta%-%nu_factura%', false);
            GetApplication()->RegisterHTTPHandler($handler);
            return $result;
        }
        
        public function OpenAdvancedSearchByDefault()
        {
            return false;
        }
    
        protected function DoGetGridHeader()
        {
            return '';
        }
    }

    SetUpUserAuthorization(GetApplication());

    try
    {
        $Page = new public_facturaPage("factura.php", "public_factura", GetCurrentUserGrantForDataSource("public.factura"), 'UTF-8');
        $Page->SetShortCaption('Factura');
        $Page->SetHeader(GetPagesHeader());
        $Page->SetFooter(GetPagesFooter());
        $Page->SetCaption('Factura');
        $Page->SetRecordPermission(GetCurrentUserRecordPermissionsForDataSource("public.factura"));
        GetApplication()->SetEnableLessRunTimeCompile(GetEnableLessFilesRunTimeCompilation());
        GetApplication()->SetCanUserChangeOwnPassword(
            !function_exists('CanUserChangeOwnPassword') || CanUserChangeOwnPassword());
        GetApplication()->SetMainPage($Page);
        GetApplication()->Run();
    }
    catch(Exception $e)
    {
        ShowErrorPage($e->getMessage());
    }
	
