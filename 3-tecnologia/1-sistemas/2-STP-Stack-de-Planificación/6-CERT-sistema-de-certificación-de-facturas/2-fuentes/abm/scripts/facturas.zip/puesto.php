<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                   ATTENTION!
 * If you see this message in your browser (Internet Explorer, Mozilla Firefox, Google Chrome, etc.)
 * this means that PHP is not properly installed on your web server. Please refer to the PHP manual
 * for more details: http://php.net/manual/install.php 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */


    include_once dirname(__FILE__) . '/' . 'components/utils/check_utils.php';
    CheckPHPVersion();
    CheckTemplatesCacheFolderIsExistsAndWritable();


    include_once dirname(__FILE__) . '/' . 'phpgen_settings.php';
    include_once dirname(__FILE__) . '/' . 'database_engine/pgsql_engine.php';
    include_once dirname(__FILE__) . '/' . 'components/page.php';
    include_once dirname(__FILE__) . '/' . 'authorization.php';

    function GetConnectionOptions()
    {
        $result = GetGlobalConnectionOptions();
        $result['client_encoding'] = 'utf8';
        GetApplication()->GetUserAuthorizationStrategy()->ApplyIdentityToConnectionOptions($result);
        return $result;
    }

    
    // OnGlobalBeforePageExecute event handler
    
    
    // OnBeforePageExecute event handler
    
    
    
    class public_puestoPage extends Page
    {
        protected function DoBeforeCreate()
        {
            $this->dataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."puesto"');
            $field = new IntegerField('id_puesto', null, null, true);
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, true);
            $field = new StringField('no_puesto');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new IntegerField('id_dependencia');
            $this->dataset->AddField($field, false);
            $this->dataset->AddLookupField('id_dependencia', '(SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2)', new IntegerField('id_dependencia'), new StringField('ds_dependencia', 'id_dependencia_ds_dependencia', 'id_dependencia_ds_dependencia_ver_dependencia'), 'id_dependencia_ds_dependencia_ver_dependencia');
        }
    
        protected function DoPrepare() {
    
        }
    
        protected function CreatePageNavigator()
        {
            $result = new CompositePageNavigator($this);
            
            $partitionNavigator = new PageNavigator('pnav', $this, $this->dataset);
            $partitionNavigator->SetRowsPerPage(100);
            $result->AddPageNavigator($partitionNavigator);
            
            return $result;
        }
    
        public function GetPageList()
        {
            $currentPageCaption = $this->GetShortCaption();
            $result = new PageList($this);
            $result->AddGroup($this->RenderText('Facturas'));
            $result->AddGroup($this->RenderText('Agentes'));
            $result->AddGroup($this->RenderText('Contratos'));
            if (GetCurrentUserGrantForDataSource('public.factura')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Factura'), 'factura.php', $this->RenderText('Factura'), $currentPageCaption == $this->RenderText('Factura'), false, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.certificacion')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Lote Certificaci�n'), 'certificacion.php', $this->RenderText('Lote Certificaci�n'), $currentPageCaption == $this->RenderText('Lote Certificaci�n'), true, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.agente')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Agente'), 'agente.php', $this->RenderText('Agente'), $currentPageCaption == $this->RenderText('Agente'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.dependencia')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Dependencia'), 'dependencia.php', $this->RenderText('Dependencia'), $currentPageCaption == $this->RenderText('Dependencia'), true, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.ubicacion_fisica')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ubicacion Fisica'), 'ubicacion_fisica.php', $this->RenderText('Ubicacion Fisica'), $currentPageCaption == $this->RenderText('Ubicacion Fisica'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.puesto')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Puesto'), 'puesto.php', $this->RenderText('Puesto'), $currentPageCaption == $this->RenderText('Puesto'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.salario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Honorario'), 'honorario.php', $this->RenderText('Honorario'), $currentPageCaption == $this->RenderText('Honorario'), false, $this->RenderText('Agentes')));
            if (GetCurrentUserGrantForDataSource('public.contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Contrato'), 'contrato.php', $this->RenderText('Contrato'), $currentPageCaption == $this->RenderText('Contrato'), false, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.tipo_contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Tipo Contrato'), 'tipo_contrato.php', $this->RenderText('Tipo Contrato'), $currentPageCaption == $this->RenderText('Tipo Contrato'), true, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.categoria_lm')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Categoria LM'), 'categoria_lm.php', $this->RenderText('Categoria Ley Marco'), $currentPageCaption == $this->RenderText('Categoria LM'), false, $this->RenderText('Contratos')));
            if (GetCurrentUserGrantForDataSource('public.convenio_at')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Convenio AT'), 'convenio_at.php', $this->RenderText('Convenio Asistencia Tecnica'), $currentPageCaption == $this->RenderText('Convenio AT'), false, $this->RenderText('Contratos')));
            
            if ( HasAdminPage() && GetApplication()->HasAdminGrantForCurrentUser() ) {
              $result->AddGroup('Admin area');
              $result->AddPage(new PageLink($this->GetLocalizerCaptions()->GetMessageString('AdminPage'), 'phpgen_admin.php', $this->GetLocalizerCaptions()->GetMessageString('AdminPage'), false, false, 'Admin area'));
            }
            return $result;
        }
    
        protected function CreateRssGenerator()
        {
            return null;
        }
    
        protected function CreateGridSearchControl(Grid $grid)
        {
            $grid->UseFilter = true;
            $grid->SearchControl = new SimpleSearch('public_puestossearch', $this->dataset,
                array('id_puesto', 'no_puesto', 'id_dependencia_ds_dependencia'),
                array($this->RenderText('ID Puesto'), $this->RenderText('Nombre Puesto'), $this->RenderText('Dependencia')),
                array(
                    '=' => $this->GetLocalizerCaptions()->GetMessageString('equals'),
                    '<>' => $this->GetLocalizerCaptions()->GetMessageString('doesNotEquals'),
                    '<' => $this->GetLocalizerCaptions()->GetMessageString('isLessThan'),
                    '<=' => $this->GetLocalizerCaptions()->GetMessageString('isLessThanOrEqualsTo'),
                    '>' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThan'),
                    '>=' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThanOrEqualsTo'),
                    'ILIKE' => $this->GetLocalizerCaptions()->GetMessageString('Like'),
                    'STARTS' => $this->GetLocalizerCaptions()->GetMessageString('StartsWith'),
                    'ENDS' => $this->GetLocalizerCaptions()->GetMessageString('EndsWith'),
                    'CONTAINS' => $this->GetLocalizerCaptions()->GetMessageString('Contains')
                    ), $this->GetLocalizerCaptions(), $this, 'CONTAINS'
                );
        }
    
        protected function CreateGridAdvancedSearchControl(Grid $grid)
        {
            $this->AdvancedSearchControl = new AdvancedSearchControl('public_puestoasearch', $this->dataset, $this->GetLocalizerCaptions(), $this->GetColumnVariableContainer(), $this->CreateLinkBuilder());
            $this->AdvancedSearchControl->setTimerInterval(1000);
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('id_puesto', $this->RenderText('ID Puesto')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('no_puesto', $this->RenderText('Nombre Puesto')));
            
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateLookupSearchInput('id_dependencia', $this->RenderText('Dependencia'), $lookupDataset, 'id_dependencia', 'ds_dependencia', false, 8));
        }
    
        protected function AddOperationsColumns(Grid $grid)
        {
            $actionsBandName = 'actions';
            $grid->AddBandToBegin($actionsBandName, $this->GetLocalizerCaptions()->GetMessageString('Actions'), true);
            if ($this->GetSecurityInfo()->HasViewGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('View'), OPERATION_VIEW, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
            if ($this->GetSecurityInfo()->HasEditGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Edit'), OPERATION_EDIT, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowEditButtonHandler', $this);
            }
            if ($this->GetSecurityInfo()->HasDeleteGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Delete'), OPERATION_DELETE, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowDeleteButtonHandler', $this);
                $column->SetAdditionalAttribute('data-modal-delete', 'true');
                $column->SetAdditionalAttribute('data-delete-handler-name', $this->GetModalGridDeleteHandler());
            }
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Copy'), OPERATION_COPY, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
        }
    
        protected function AddFieldColumns(Grid $grid)
        {
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('no_puesto', 'Nombre Puesto', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_puestoGrid_no_puesto_handler_list');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $column->SetDescription($this->RenderText('Nombre del puesto del agente.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $column->SetDescription($this->RenderText('Dependencia gubernamental.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
        }
    
        protected function AddSingleRecordViewColumns(Grid $grid)
        {
            //
            // View column for id_puesto field
            //
            $column = new TextViewColumn('id_puesto', 'ID Puesto', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('no_puesto', 'Nombre Puesto', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_puestoGrid_no_puesto_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
        }
    
        protected function AddEditColumns(Grid $grid)
        {
            //
            // Edit column for no_puesto field
            //
            $editor = new TextEdit('no_puesto_edit');
            $editor->SetSize(100);
            $editor->SetMaxLength(100);
            $editColumn = new CustomEditColumn('Nombre Puesto', 'no_puesto', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for id_dependencia field
            //
            $editor = new ComboBox('id_dependencia_edit', $this->GetLocalizerCaptions()->GetMessageString('PleaseSelect'));
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $editColumn = new LookUpEditColumn(
                'Dependencia', 
                'id_dependencia', 
                $editor, 
                $this->dataset, 'id_dependencia', 'ds_dependencia', $lookupDataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
        }
    
        protected function AddInsertColumns(Grid $grid)
        {
            //
            // Edit column for no_puesto field
            //
            $editor = new TextEdit('no_puesto_edit');
            $editor->SetSize(100);
            $editor->SetMaxLength(100);
            $editColumn = new CustomEditColumn('Nombre Puesto', 'no_puesto', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for id_dependencia field
            //
            $editor = new ComboBox('id_dependencia_edit', $this->GetLocalizerCaptions()->GetMessageString('PleaseSelect'));
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $editColumn = new LookUpEditColumn(
                'Dependencia', 
                'id_dependencia', 
                $editor, 
                $this->dataset, 'id_dependencia', 'ds_dependencia', $lookupDataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $grid->SetShowAddButton(true);
                $grid->SetShowInlineAddButton(false);
            }
            else
            {
                $grid->SetShowInlineAddButton(false);
                $grid->SetShowAddButton(false);
            }
        }
    
        protected function AddPrintColumns(Grid $grid)
        {
            //
            // View column for id_puesto field
            //
            $column = new TextViewColumn('id_puesto', 'ID Puesto', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('no_puesto', 'No Puesto', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddPrintColumn($column);
        }
    
        protected function AddExportColumns(Grid $grid)
        {
            //
            // View column for id_puesto field
            //
            $column = new TextViewColumn('id_puesto', 'ID Puesto', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('no_puesto', 'No Puesto', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddExportColumn($column);
        }
    
        public function GetPageDirection()
        {
            return null;
        }
    
        protected function ApplyCommonColumnEditProperties(CustomEditColumn $column)
        {
            $column->SetDisplaySetToNullCheckBox(false);
            $column->SetDisplaySetToDefaultCheckBox(false);
    		$column->SetVariableContainer($this->GetColumnVariableContainer());
        }
    
        function GetCustomClientScript()
        {
            return ;
        }
        
        function GetOnPageLoadedClientScript()
        {
            return ;
        }
        public function ShowEditButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasEditGrant($this->GetDataset());
        }
        public function ShowDeleteButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasDeleteGrant($this->GetDataset());
        }
        
        public function GetModalGridDeleteHandler() { return 'public_puesto_modal_delete'; }
        protected function GetEnableModalGridDelete() { return true; }
    
        protected function CreateGrid()
        {
            $result = new Grid($this, $this->dataset, 'public_puestoGrid');
            if ($this->GetSecurityInfo()->HasDeleteGrant())
               $result->SetAllowDeleteSelected(false);
            else
               $result->SetAllowDeleteSelected(false);   
            
            ApplyCommonPageSettings($this, $result);
            
            $result->SetUseImagesForActions(true);
            $defaultSortedColumns = array();
            $defaultSortedColumns[] = new SortColumn('no_puesto', 'ASC');
            $result->setDefaultOrdering($defaultSortedColumns);
            $result->SetUseFixedHeader(false);
            $result->SetShowLineNumbers(false);
            $result->SetShowKeyColumnsImagesInHeader(false);
            
            $result->SetHighlightRowAtHover(true);
            $result->SetWidth('');
            $this->CreateGridSearchControl($result);
            $this->CreateGridAdvancedSearchControl($result);
            $this->AddOperationsColumns($result);
            $this->AddFieldColumns($result);
            $this->AddSingleRecordViewColumns($result);
            $this->AddEditColumns($result);
            $this->AddInsertColumns($result);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
    
            $this->SetShowPageList(true);
            $this->SetHidePageListByDefault(false);
            $this->SetExportToExcelAvailable(true);
            $this->SetExportToWordAvailable(true);
            $this->SetExportToXmlAvailable(true);
            $this->SetExportToCsvAvailable(true);
            $this->SetExportToPdfAvailable(true);
            $this->SetPrinterFriendlyAvailable(true);
            $this->SetSimpleSearchAvailable(true);
            $this->SetAdvancedSearchAvailable(true);
            $this->SetFilterRowAvailable(true);
            $this->SetVisualEffectsEnabled(true);
            $this->SetShowTopPageNavigator(true);
            $this->SetShowBottomPageNavigator(true);
    
            //
            // Http Handlers
            //
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('no_puesto', 'Nombre Puesto', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_puestoGrid_no_puesto_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);//
            // View column for no_puesto field
            //
            $column = new TextViewColumn('no_puesto', 'Nombre Puesto', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_puestoGrid_no_puesto_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            return $result;
        }
        
        public function OpenAdvancedSearchByDefault()
        {
            return false;
        }
    
        protected function DoGetGridHeader()
        {
            return '';
        }
    }

    SetUpUserAuthorization(GetApplication());

    try
    {
        $Page = new public_puestoPage("puesto.php", "public_puesto", GetCurrentUserGrantForDataSource("public.puesto"), 'UTF-8');
        $Page->SetShortCaption('Puesto');
        $Page->SetHeader(GetPagesHeader());
        $Page->SetFooter(GetPagesFooter());
        $Page->SetCaption('Puesto');
        $Page->SetRecordPermission(GetCurrentUserRecordPermissionsForDataSource("public.puesto"));
        GetApplication()->SetEnableLessRunTimeCompile(GetEnableLessFilesRunTimeCompilation());
        GetApplication()->SetCanUserChangeOwnPassword(
            !function_exists('CanUserChangeOwnPassword') || CanUserChangeOwnPassword());
        GetApplication()->SetMainPage($Page);
        GetApplication()->Run();
    }
    catch(Exception $e)
    {
        ShowErrorPage($e->getMessage());
    }
	
