<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                   ATTENTION!
 * If you see this message in your browser (Internet Explorer, Mozilla Firefox, Google Chrome, etc.)
 * this means that PHP is not properly installed on your web server. Please refer to the PHP manual
 * for more details: http://php.net/manual/install.php 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */


    include_once dirname(__FILE__) . '/' . 'components/utils/check_utils.php';
    CheckPHPVersion();
    CheckTemplatesCacheFolderIsExistsAndWritable();


    include_once dirname(__FILE__) . '/' . 'phpgen_settings.php';
    include_once dirname(__FILE__) . '/' . 'database_engine/pgsql_engine.php';
    include_once dirname(__FILE__) . '/' . 'components/page.php';
    include_once dirname(__FILE__) . '/' . 'authorization.php';

    function GetConnectionOptions()
    {
        $result = GetGlobalConnectionOptions();
        $result['client_encoding'] = 'utf8';
        GetApplication()->GetUserAuthorizationStrategy()->ApplyIdentityToConnectionOptions($result);
        return $result;
    }

    
    // OnGlobalBeforePageExecute event handler
    
    
    // OnBeforePageExecute event handler
    
    
    
    class audit_logged_actionsPage extends Page
    {
        protected function DoBeforeCreate()
        {
            $this->dataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"audit"."logged_actions"');
            $field = new IntegerField('event_id', null, null, true);
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, true);
            $field = new StringField('schema_name');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new StringField('table_name');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new IntegerField('relid');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new StringField('session_user_name');
            $this->dataset->AddField($field, false);
            $field = new DateTimeField('action_tstamp_tx');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new DateTimeField('action_tstamp_stm');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new DateTimeField('action_tstamp_clk');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new IntegerField('transaction_id');
            $this->dataset->AddField($field, false);
            $field = new StringField('application_name');
            $this->dataset->AddField($field, false);
            $field = new StringField('client_addr');
            $this->dataset->AddField($field, false);
            $field = new IntegerField('client_port');
            $this->dataset->AddField($field, false);
            $field = new StringField('client_query');
            $this->dataset->AddField($field, false);
            $field = new StringField('action');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new StringField('row_data');
            $this->dataset->AddField($field, false);
            $field = new StringField('changed_fields');
            $this->dataset->AddField($field, false);
            $field = new BooleanField('statement_only');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
        }
    
        protected function DoPrepare() {
    
        }
    
        protected function CreatePageNavigator()
        {
            $result = new CompositePageNavigator($this);
            
            $partitionNavigator = new PageNavigator('pnav', $this, $this->dataset);
            $partitionNavigator->SetRowsPerPage(100);
            $result->AddPageNavigator($partitionNavigator);
            
            return $result;
        }
    
        public function GetPageList()
        {
            $currentPageCaption = $this->GetShortCaption();
            $result = new PageList($this);
            $result->AddGroup($this->RenderText('Facturas'));
            $result->AddGroup($this->RenderText('Contratos de Agentes'));
            $result->AddGroup($this->RenderText('Administrador'));
            if (GetCurrentUserGrantForDataSource('public.factura')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Factura'), 'factura.php', $this->RenderText('Factura'), $currentPageCaption == $this->RenderText('Factura'), false, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.certificacion')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Lote Certificaci�n'), 'certificacion.php', $this->RenderText('Lote Certificaci�n'), $currentPageCaption == $this->RenderText('Lote Certificaci�n'), true, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.agente')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Agente'), 'agente.php', $this->RenderText('Agente'), $currentPageCaption == $this->RenderText('Agente'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.dependencia')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Dependencia'), 'dependencia.php', $this->RenderText('Dependencia'), $currentPageCaption == $this->RenderText('Dependencia'), true, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.ubicacion_fisica')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ubicacion Fisica'), 'ubicacion_fisica.php', $this->RenderText('Ubicacion Fisica'), $currentPageCaption == $this->RenderText('Ubicacion Fisica'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.puesto')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Puesto'), 'puesto.php', $this->RenderText('Puesto'), $currentPageCaption == $this->RenderText('Puesto'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.convenio_at')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Convenio AT'), 'convenio_at.php', $this->RenderText('Convenio Asistencia Tecnica'), $currentPageCaption == $this->RenderText('Convenio AT'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.tipo_contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Tipo Contrato'), 'tipo_contrato.php', $this->RenderText('Tipo Contrato'), $currentPageCaption == $this->RenderText('Tipo Contrato'), true, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Contrato'), 'contrato.php', $this->RenderText('Contrato'), $currentPageCaption == $this->RenderText('Contrato'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.tipo_honorario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Tipo Honorario'), 'tipo_honorario.php', $this->RenderText('Tipo Honorario'), $currentPageCaption == $this->RenderText('Tipo Honorario'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.honorario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Honorario'), 'honorario.php', $this->RenderText('Honorario'), $currentPageCaption == $this->RenderText('Honorario'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('audit.logged_actions')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Auditor�a'), 'auditoria.php', $this->RenderText('Auditor�a'), $currentPageCaption == $this->RenderText('Auditor�a'), false, $this->RenderText('Administrador')));
            if (GetCurrentUserGrantForDataSource('ver_categ_honorario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ver Categ Honorario'), 'ver_categ_honorario.php', $this->RenderText('Ver Categ Honorario'), $currentPageCaption == $this->RenderText('Ver Categ Honorario'), false, $this->RenderText('Default')));
            if (GetCurrentUserGrantForDataSource('ver_contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ver Contrato'), 'ver_contrato.php', $this->RenderText('Ver Contrato'), $currentPageCaption == $this->RenderText('Ver Contrato'), false, $this->RenderText('Default')));
            
            if ( HasAdminPage() && GetApplication()->HasAdminGrantForCurrentUser() ) {
              $result->AddGroup('Admin area');
              $result->AddPage(new PageLink($this->GetLocalizerCaptions()->GetMessageString('AdminPage'), 'phpgen_admin.php', $this->GetLocalizerCaptions()->GetMessageString('AdminPage'), false, false, 'Admin area'));
            }
            return $result;
        }
    
        protected function CreateRssGenerator()
        {
            return null;
        }
    
        protected function CreateGridSearchControl(Grid $grid)
        {
            $grid->UseFilter = true;
            $grid->SearchControl = new SimpleSearch('audit_logged_actionsssearch', $this->dataset,
                array('event_id', 'schema_name', 'table_name', 'relid', 'session_user_name', 'action_tstamp_tx', 'action_tstamp_stm', 'action_tstamp_clk', 'transaction_id', 'application_name', 'client_addr', 'client_port', 'client_query', 'action', 'row_data', 'changed_fields', 'statement_only'),
                array($this->RenderText('Event ID'), $this->RenderText('Schema Name'), $this->RenderText('Table Name'), $this->RenderText('Relid'), $this->RenderText('Session User Name'), $this->RenderText('Action Tstamp Tx'), $this->RenderText('Action Tstamp Stm'), $this->RenderText('Action Tstamp Clk'), $this->RenderText('Transaction Id'), $this->RenderText('Application Name'), $this->RenderText('Client Addr'), $this->RenderText('Client Port'), $this->RenderText('Client Query'), $this->RenderText('Action'), $this->RenderText('Row Data'), $this->RenderText('Changed Fields'), $this->RenderText('Statement Only')),
                array(
                    '=' => $this->GetLocalizerCaptions()->GetMessageString('equals'),
                    '<>' => $this->GetLocalizerCaptions()->GetMessageString('doesNotEquals'),
                    '<' => $this->GetLocalizerCaptions()->GetMessageString('isLessThan'),
                    '<=' => $this->GetLocalizerCaptions()->GetMessageString('isLessThanOrEqualsTo'),
                    '>' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThan'),
                    '>=' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThanOrEqualsTo'),
                    'ILIKE' => $this->GetLocalizerCaptions()->GetMessageString('Like'),
                    'STARTS' => $this->GetLocalizerCaptions()->GetMessageString('StartsWith'),
                    'ENDS' => $this->GetLocalizerCaptions()->GetMessageString('EndsWith'),
                    'CONTAINS' => $this->GetLocalizerCaptions()->GetMessageString('Contains')
                    ), $this->GetLocalizerCaptions(), $this, 'CONTAINS'
                );
        }
    
        protected function CreateGridAdvancedSearchControl(Grid $grid)
        {
            $this->AdvancedSearchControl = new AdvancedSearchControl('audit_logged_actionsasearch', $this->dataset, $this->GetLocalizerCaptions(), $this->GetColumnVariableContainer(), $this->CreateLinkBuilder());
            $this->AdvancedSearchControl->setTimerInterval(1000);
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('event_id', $this->RenderText('Event ID')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('schema_name', $this->RenderText('Schema Name')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('table_name', $this->RenderText('Table Name')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('relid', $this->RenderText('Relid')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('session_user_name', $this->RenderText('Session User Name')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateDateTimeSearchInput('action_tstamp_tx', $this->RenderText('Action Tstamp Tx'), 'd/m/Y H:i:s'));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateDateTimeSearchInput('action_tstamp_stm', $this->RenderText('Action Tstamp Stm'), 'd/m/Y H:i:s'));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateDateTimeSearchInput('action_tstamp_clk', $this->RenderText('Action Tstamp Clk'), 'd/m/Y H:i:s'));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('transaction_id', $this->RenderText('Transaction Id')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('application_name', $this->RenderText('Application Name')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('client_addr', $this->RenderText('Client Addr')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('client_port', $this->RenderText('Client Port')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('client_query', $this->RenderText('Client Query')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('action', $this->RenderText('Action')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('row_data', $this->RenderText('Row Data')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('changed_fields', $this->RenderText('Changed Fields')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('statement_only', $this->RenderText('Statement Only')));
        }
    
        protected function AddOperationsColumns(Grid $grid)
        {
            $actionsBandName = 'actions';
            $grid->AddBandToBegin($actionsBandName, $this->GetLocalizerCaptions()->GetMessageString('Actions'), true);
            if ($this->GetSecurityInfo()->HasViewGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('View'), OPERATION_VIEW, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
            if ($this->GetSecurityInfo()->HasEditGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Edit'), OPERATION_EDIT, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowEditButtonHandler', $this);
            }
            if ($this->GetSecurityInfo()->HasDeleteGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Delete'), OPERATION_DELETE, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowDeleteButtonHandler', $this);
                $column->SetAdditionalAttribute('data-modal-delete', 'true');
                $column->SetAdditionalAttribute('data-delete-handler-name', $this->GetModalGridDeleteHandler());
            }
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Copy'), OPERATION_COPY, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
        }
    
        protected function AddFieldColumns(Grid $grid)
        {
            //
            // View column for table_name field
            //
            $column = new TextViewColumn('table_name', 'Table Name', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_table_name_handler_list');
            $column->SetDescription($this->RenderText('Non-schema-qualified table name of table event occured in'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for session_user_name field
            //
            $column = new TextViewColumn('session_user_name', 'Session User Name', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_session_user_name_handler_list');
            $column->SetDescription($this->RenderText('Login / session user whose statement caused the audited event'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for action_tstamp_stm field
            //
            $column = new DateTimeViewColumn('action_tstamp_stm', 'Action Tstamp Stm', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $column->SetDescription($this->RenderText('Statement start timestamp for tx in which audited event occurred'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for application_name field
            //
            $column = new TextViewColumn('application_name', 'Application Name', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_application_name_handler_list');
            $column->SetDescription($this->RenderText('Application name set when this audit event occurred. Can be changed in-session by client.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for client_query field
            //
            $column = new TextViewColumn('client_query', 'Client Query', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_client_query_handler_list');
            $column->SetDescription($this->RenderText('Top-level query that caused this auditable event. May be more than one statement.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for action field
            //
            $column = new TextViewColumn('action', 'Action', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_action_handler_list');
            $column->SetDescription($this->RenderText('Action type; I = insert, D = delete, U = update, T = truncate'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
        }
    
        protected function AddSingleRecordViewColumns(Grid $grid)
        {
            //
            // View column for event_id field
            //
            $column = new TextViewColumn('event_id', 'Event ID', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for schema_name field
            //
            $column = new TextViewColumn('schema_name', 'Schema Name', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_schema_name_handler_view');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for table_name field
            //
            $column = new TextViewColumn('table_name', 'Table Name', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_table_name_handler_view');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for relid field
            //
            $column = new TextViewColumn('relid', 'Relid', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for session_user_name field
            //
            $column = new TextViewColumn('session_user_name', 'Session User Name', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_session_user_name_handler_view');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for action_tstamp_tx field
            //
            $column = new DateTimeViewColumn('action_tstamp_tx', 'Action Tstamp Tx', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for action_tstamp_stm field
            //
            $column = new DateTimeViewColumn('action_tstamp_stm', 'Action Tstamp Stm', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for action_tstamp_clk field
            //
            $column = new DateTimeViewColumn('action_tstamp_clk', 'Action Tstamp Clk', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for transaction_id field
            //
            $column = new TextViewColumn('transaction_id', 'Transaction Id', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for application_name field
            //
            $column = new TextViewColumn('application_name', 'Application Name', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_application_name_handler_view');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for client_addr field
            //
            $column = new TextViewColumn('client_addr', 'Client Addr', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for client_port field
            //
            $column = new TextViewColumn('client_port', 'Client Port', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for client_query field
            //
            $column = new TextViewColumn('client_query', 'Client Query', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_client_query_handler_view');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for action field
            //
            $column = new TextViewColumn('action', 'Action', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('audit_logged_actionsGrid_action_handler_view');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for row_data field
            //
            $column = new TextViewColumn('row_data', 'Row Data', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for changed_fields field
            //
            $column = new TextViewColumn('changed_fields', 'Changed Fields', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for statement_only field
            //
            $column = new TextViewColumn('statement_only', 'Statement Only', $this->dataset);
            $column->SetOrderable(true);
            $column = new CheckBoxFormatValueViewColumnDecorator($column);
            $column->SetDisplayValues($this->RenderText('<img src="images/checked.png" alt="true">'), $this->RenderText(''));
            $grid->AddSingleRecordViewColumn($column);
        }
    
        protected function AddEditColumns(Grid $grid)
        {
            //
            // Edit column for schema_name field
            //
            $editor = new TextAreaEdit('schema_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Schema Name', 'schema_name', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for table_name field
            //
            $editor = new TextAreaEdit('table_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Table Name', 'table_name', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for relid field
            //
            $editor = new TextEdit('relid_edit');
            $editColumn = new CustomEditColumn('Relid', 'relid', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for session_user_name field
            //
            $editor = new TextAreaEdit('session_user_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Session User Name', 'session_user_name', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for action_tstamp_tx field
            //
            $editor = new DateTimeEdit('action_tstamp_tx_edit', true, 'Y-m-d H:i:s', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Action Tstamp Tx', 'action_tstamp_tx', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for action_tstamp_stm field
            //
            $editor = new DateTimeEdit('action_tstamp_stm_edit', true, 'Y-m-d H:i:s', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Action Tstamp Stm', 'action_tstamp_stm', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for action_tstamp_clk field
            //
            $editor = new DateTimeEdit('action_tstamp_clk_edit', true, 'Y-m-d H:i:s', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Action Tstamp Clk', 'action_tstamp_clk', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for transaction_id field
            //
            $editor = new TextEdit('transaction_id_edit');
            $editColumn = new CustomEditColumn('Transaction Id', 'transaction_id', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for application_name field
            //
            $editor = new TextAreaEdit('application_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Application Name', 'application_name', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for client_addr field
            //
            $editor = new TextEdit('client_addr_edit');
            $editColumn = new CustomEditColumn('Client Addr', 'client_addr', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for client_port field
            //
            $editor = new TextEdit('client_port_edit');
            $editColumn = new CustomEditColumn('Client Port', 'client_port', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for client_query field
            //
            $editor = new TextAreaEdit('client_query_edit', 50, 8);
            $editColumn = new CustomEditColumn('Client Query', 'client_query', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for action field
            //
            $editor = new TextAreaEdit('action_edit', 50, 8);
            $editColumn = new CustomEditColumn('Action', 'action', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for row_data field
            //
            $editor = new TextEdit('row_data_edit');
            $editColumn = new CustomEditColumn('Row Data', 'row_data', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for changed_fields field
            //
            $editor = new TextEdit('changed_fields_edit');
            $editColumn = new CustomEditColumn('Changed Fields', 'changed_fields', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for statement_only field
            //
            $editor = new CheckBox('statement_only_edit');
            $editColumn = new CustomEditColumn('Statement Only', 'statement_only', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
        }
    
        protected function AddInsertColumns(Grid $grid)
        {
            //
            // Edit column for schema_name field
            //
            $editor = new TextAreaEdit('schema_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Schema Name', 'schema_name', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for table_name field
            //
            $editor = new TextAreaEdit('table_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Table Name', 'table_name', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for relid field
            //
            $editor = new TextEdit('relid_edit');
            $editColumn = new CustomEditColumn('Relid', 'relid', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for session_user_name field
            //
            $editor = new TextAreaEdit('session_user_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Session User Name', 'session_user_name', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for action_tstamp_tx field
            //
            $editor = new DateTimeEdit('action_tstamp_tx_edit', true, 'Y-m-d H:i:s', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Action Tstamp Tx', 'action_tstamp_tx', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for action_tstamp_stm field
            //
            $editor = new DateTimeEdit('action_tstamp_stm_edit', true, 'Y-m-d H:i:s', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Action Tstamp Stm', 'action_tstamp_stm', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for action_tstamp_clk field
            //
            $editor = new DateTimeEdit('action_tstamp_clk_edit', true, 'Y-m-d H:i:s', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Action Tstamp Clk', 'action_tstamp_clk', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for transaction_id field
            //
            $editor = new TextEdit('transaction_id_edit');
            $editColumn = new CustomEditColumn('Transaction Id', 'transaction_id', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for application_name field
            //
            $editor = new TextAreaEdit('application_name_edit', 50, 8);
            $editColumn = new CustomEditColumn('Application Name', 'application_name', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for client_addr field
            //
            $editor = new TextEdit('client_addr_edit');
            $editColumn = new CustomEditColumn('Client Addr', 'client_addr', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for client_port field
            //
            $editor = new TextEdit('client_port_edit');
            $editColumn = new CustomEditColumn('Client Port', 'client_port', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for client_query field
            //
            $editor = new TextAreaEdit('client_query_edit', 50, 8);
            $editColumn = new CustomEditColumn('Client Query', 'client_query', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for action field
            //
            $editor = new TextAreaEdit('action_edit', 50, 8);
            $editColumn = new CustomEditColumn('Action', 'action', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for row_data field
            //
            $editor = new TextEdit('row_data_edit');
            $editColumn = new CustomEditColumn('Row Data', 'row_data', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for changed_fields field
            //
            $editor = new TextEdit('changed_fields_edit');
            $editColumn = new CustomEditColumn('Changed Fields', 'changed_fields', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for statement_only field
            //
            $editor = new CheckBox('statement_only_edit');
            $editColumn = new CustomEditColumn('Statement Only', 'statement_only', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $grid->SetShowAddButton(true);
                $grid->SetShowInlineAddButton(false);
            }
            else
            {
                $grid->SetShowInlineAddButton(false);
                $grid->SetShowAddButton(false);
            }
        }
    
        protected function AddPrintColumns(Grid $grid)
        {
            //
            // View column for event_id field
            //
            $column = new TextViewColumn('event_id', 'Event ID', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for schema_name field
            //
            $column = new TextViewColumn('schema_name', 'Schema Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for table_name field
            //
            $column = new TextViewColumn('table_name', 'Table Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for relid field
            //
            $column = new TextViewColumn('relid', 'Relid', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for session_user_name field
            //
            $column = new TextViewColumn('session_user_name', 'Session User Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for action_tstamp_tx field
            //
            $column = new DateTimeViewColumn('action_tstamp_tx', 'Action Tstamp Tx', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for action_tstamp_stm field
            //
            $column = new DateTimeViewColumn('action_tstamp_stm', 'Action Tstamp Stm', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for action_tstamp_clk field
            //
            $column = new DateTimeViewColumn('action_tstamp_clk', 'Action Tstamp Clk', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for transaction_id field
            //
            $column = new TextViewColumn('transaction_id', 'Transaction Id', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for application_name field
            //
            $column = new TextViewColumn('application_name', 'Application Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for client_addr field
            //
            $column = new TextViewColumn('client_addr', 'Client Addr', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for client_port field
            //
            $column = new TextViewColumn('client_port', 'Client Port', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for client_query field
            //
            $column = new TextViewColumn('client_query', 'Client Query', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for action field
            //
            $column = new TextViewColumn('action', 'Action', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for row_data field
            //
            $column = new TextViewColumn('row_data', 'Row Data', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for changed_fields field
            //
            $column = new TextViewColumn('changed_fields', 'Changed Fields', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for statement_only field
            //
            $column = new TextViewColumn('statement_only', 'Statement Only', $this->dataset);
            $column->SetOrderable(true);
            $column = new CheckBoxFormatValueViewColumnDecorator($column);
            $column->SetDisplayValues($this->RenderText('<img src="images/checked.png" alt="true">'), $this->RenderText(''));
            $grid->AddPrintColumn($column);
        }
    
        protected function AddExportColumns(Grid $grid)
        {
            //
            // View column for event_id field
            //
            $column = new TextViewColumn('event_id', 'Event ID', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for schema_name field
            //
            $column = new TextViewColumn('schema_name', 'Schema Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for table_name field
            //
            $column = new TextViewColumn('table_name', 'Table Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for relid field
            //
            $column = new TextViewColumn('relid', 'Relid', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for session_user_name field
            //
            $column = new TextViewColumn('session_user_name', 'Session User Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for action_tstamp_tx field
            //
            $column = new DateTimeViewColumn('action_tstamp_tx', 'Action Tstamp Tx', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for action_tstamp_stm field
            //
            $column = new DateTimeViewColumn('action_tstamp_stm', 'Action Tstamp Stm', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for action_tstamp_clk field
            //
            $column = new DateTimeViewColumn('action_tstamp_clk', 'Action Tstamp Clk', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y H:i:s');
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for transaction_id field
            //
            $column = new TextViewColumn('transaction_id', 'Transaction Id', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for application_name field
            //
            $column = new TextViewColumn('application_name', 'Application Name', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for client_addr field
            //
            $column = new TextViewColumn('client_addr', 'Client Addr', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for client_port field
            //
            $column = new TextViewColumn('client_port', 'Client Port', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for client_query field
            //
            $column = new TextViewColumn('client_query', 'Client Query', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for action field
            //
            $column = new TextViewColumn('action', 'Action', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for row_data field
            //
            $column = new TextViewColumn('row_data', 'Row Data', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for changed_fields field
            //
            $column = new TextViewColumn('changed_fields', 'Changed Fields', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for statement_only field
            //
            $column = new TextViewColumn('statement_only', 'Statement Only', $this->dataset);
            $column->SetOrderable(true);
            $column = new CheckBoxFormatValueViewColumnDecorator($column);
            $column->SetDisplayValues($this->RenderText('<img src="images/checked.png" alt="true">'), $this->RenderText(''));
            $grid->AddExportColumn($column);
        }
    
        public function GetPageDirection()
        {
            return null;
        }
    
        protected function ApplyCommonColumnEditProperties(CustomEditColumn $column)
        {
            $column->SetDisplaySetToNullCheckBox(false);
            $column->SetDisplaySetToDefaultCheckBox(false);
    		$column->SetVariableContainer($this->GetColumnVariableContainer());
        }
    
        function GetCustomClientScript()
        {
            return ;
        }
        
        function GetOnPageLoadedClientScript()
        {
            return ;
        }
        public function ShowEditButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasEditGrant($this->GetDataset());
        }
        public function ShowDeleteButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasDeleteGrant($this->GetDataset());
        }
        
        public function GetModalGridDeleteHandler() { return 'audit_logged_actions_modal_delete'; }
        protected function GetEnableModalGridDelete() { return true; }
    
        protected function CreateGrid()
        {
            $result = new Grid($this, $this->dataset, 'audit_logged_actionsGrid');
            if ($this->GetSecurityInfo()->HasDeleteGrant())
               $result->SetAllowDeleteSelected(false);
            else
               $result->SetAllowDeleteSelected(false);   
            
            ApplyCommonPageSettings($this, $result);
            
            $result->SetUseImagesForActions(true);
            $defaultSortedColumns = array();
            $defaultSortedColumns[] = new SortColumn('event_id', 'DESC');
            $result->setDefaultOrdering($defaultSortedColumns);
            $result->SetUseFixedHeader(false);
            $result->SetShowLineNumbers(false);
            $result->SetShowKeyColumnsImagesInHeader(false);
            
            $result->SetHighlightRowAtHover(true);
            $result->SetWidth('');
            $this->CreateGridSearchControl($result);
            $this->CreateGridAdvancedSearchControl($result);
            $this->AddOperationsColumns($result);
            $this->AddFieldColumns($result);
            $this->AddSingleRecordViewColumns($result);
            $this->AddEditColumns($result);
            $this->AddInsertColumns($result);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
    
            $this->SetShowPageList(true);
            $this->SetHidePageListByDefault(false);
            $this->SetExportToExcelAvailable(true);
            $this->SetExportToWordAvailable(true);
            $this->SetExportToXmlAvailable(true);
            $this->SetExportToCsvAvailable(true);
            $this->SetExportToPdfAvailable(true);
            $this->SetPrinterFriendlyAvailable(true);
            $this->SetSimpleSearchAvailable(true);
            $this->SetAdvancedSearchAvailable(true);
            $this->SetFilterRowAvailable(true);
            $this->SetVisualEffectsEnabled(true);
            $this->SetShowTopPageNavigator(true);
            $this->SetShowBottomPageNavigator(true);
    
            //
            // Http Handlers
            //
            //
            // View column for table_name field
            //
            $column = new TextViewColumn('table_name', 'Table Name', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_table_name_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for session_user_name field
            //
            $column = new TextViewColumn('session_user_name', 'Session User Name', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_session_user_name_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for application_name field
            //
            $column = new TextViewColumn('application_name', 'Application Name', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_application_name_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for client_query field
            //
            $column = new TextViewColumn('client_query', 'Client Query', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_client_query_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for action field
            //
            $column = new TextViewColumn('action', 'Action', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_action_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);//
            // View column for schema_name field
            //
            $column = new TextViewColumn('schema_name', 'Schema Name', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_schema_name_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for table_name field
            //
            $column = new TextViewColumn('table_name', 'Table Name', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_table_name_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for session_user_name field
            //
            $column = new TextViewColumn('session_user_name', 'Session User Name', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_session_user_name_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for application_name field
            //
            $column = new TextViewColumn('application_name', 'Application Name', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_application_name_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for client_query field
            //
            $column = new TextViewColumn('client_query', 'Client Query', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_client_query_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for action field
            //
            $column = new TextViewColumn('action', 'Action', $this->dataset);
            $column->SetOrderable(true);
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'audit_logged_actionsGrid_action_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            return $result;
        }
        
        public function OpenAdvancedSearchByDefault()
        {
            return false;
        }
    
        protected function DoGetGridHeader()
        {
            return '';
        }
    }

    SetUpUserAuthorization(GetApplication());

    try
    {
        $Page = new audit_logged_actionsPage("auditoria.php", "audit_logged_actions", GetCurrentUserGrantForDataSource("audit.logged_actions"), 'UTF-8');
        $Page->SetShortCaption('Auditor�a');
        $Page->SetHeader(GetPagesHeader());
        $Page->SetFooter(GetPagesFooter());
        $Page->SetCaption('Auditor�a');
        $Page->SetRecordPermission(GetCurrentUserRecordPermissionsForDataSource("audit.logged_actions"));
        GetApplication()->SetEnableLessRunTimeCompile(GetEnableLessFilesRunTimeCompilation());
        GetApplication()->SetCanUserChangeOwnPassword(
            !function_exists('CanUserChangeOwnPassword') || CanUserChangeOwnPassword());
        GetApplication()->SetMainPage($Page);
        GetApplication()->Run();
    }
    catch(Exception $e)
    {
        ShowErrorPage($e->getMessage());
    }
	
