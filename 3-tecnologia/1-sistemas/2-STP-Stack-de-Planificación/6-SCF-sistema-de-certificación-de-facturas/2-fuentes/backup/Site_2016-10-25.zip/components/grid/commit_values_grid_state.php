<?php

include_once dirname(__FILE__) . '/' . 'grid_state.php';

abstract class CommitValuesGridState extends GridState {

}
