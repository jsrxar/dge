<?php

require_once 'components/page.php';
require_once 'components/security/datasource_security_info.php';
require_once 'components/security/security_info.php';
require_once 'components/security/hardcoded_auth.php';
require_once 'components/security/user_grants_manager.php';

include_once 'components/security/user_identity_storage/user_identity_session_storage.php';

$users = array('facturas' => 'facturas');

$usersIds = array('facturas' => -1);

$dataSourceRecordPermissions = array();

$grants = array('guest' => 
        array()
    ,
    'defaultUser' => 
        array('public.factura' => new DataSourceSecurityInfo(false, false, false, false),
        'public.certificacion' => new DataSourceSecurityInfo(false, false, false, false),
        'public.agente' => new DataSourceSecurityInfo(false, false, false, false),
        'public.dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'public.ubicacion_fisica' => new DataSourceSecurityInfo(false, false, false, false),
        'public.puesto' => new DataSourceSecurityInfo(false, false, false, false),
        'public.convenio_at' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.categoria_lm' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_tipo_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato_factura' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'estado_lote' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_lote_cert' => new DataSourceSecurityInfo(false, false, false, false),
        'audit.logged_actions' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_categ_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato' => new DataSourceSecurityInfo(false, false, false, false))
    ,
    'guest' => 
        array('public.factura' => new DataSourceSecurityInfo(false, false, false, false),
        'public.certificacion' => new DataSourceSecurityInfo(false, false, false, false),
        'public.agente' => new DataSourceSecurityInfo(false, false, false, false),
        'public.dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'public.ubicacion_fisica' => new DataSourceSecurityInfo(false, false, false, false),
        'public.puesto' => new DataSourceSecurityInfo(false, false, false, false),
        'public.convenio_at' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.categoria_lm' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_tipo_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato_factura' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'estado_lote' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_lote_cert' => new DataSourceSecurityInfo(false, false, false, false),
        'audit.logged_actions' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_categ_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato' => new DataSourceSecurityInfo(false, false, false, false))
    ,
    'facturas' => 
        array('public.factura' => new DataSourceSecurityInfo(false, false, false, false),
        'public.certificacion' => new DataSourceSecurityInfo(false, false, false, false),
        'public.agente' => new DataSourceSecurityInfo(false, false, false, false),
        'public.dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'public.ubicacion_fisica' => new DataSourceSecurityInfo(false, false, false, false),
        'public.puesto' => new DataSourceSecurityInfo(false, false, false, false),
        'public.convenio_at' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.contrato' => new DataSourceSecurityInfo(false, false, false, false),
        'public.tipo_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'public.categoria_lm' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_tipo_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato_factura' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_dependencia' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'estado_lote' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_lote_cert' => new DataSourceSecurityInfo(false, false, false, false),
        'audit.logged_actions' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_categ_honorario' => new DataSourceSecurityInfo(false, false, false, false),
        'ver_contrato' => new DataSourceSecurityInfo(false, false, false, false))
    );

$appGrants = array('guest' => new DataSourceSecurityInfo(false, false, false, false),
    'defaultUser' => new DataSourceSecurityInfo(true, false, false, false),
    'guest' => new DataSourceSecurityInfo(false, false, false, false),
    'facturas' => new AdminDataSourceSecurityInfo());

$tableCaptions = array('public.factura' => 'Factura',
'public.certificacion' => 'Lote Certificaci�n',
'public.agente' => 'Agente',
'public.dependencia' => 'Dependencia',
'public.ubicacion_fisica' => 'Ubicacion Fisica',
'public.puesto' => 'Puesto',
'public.convenio_at' => 'Convenio AT',
'public.tipo_contrato' => 'Tipo Contrato',
'public.contrato' => 'Contrato',
'public.tipo_honorario' => 'Tipo Honorario',
'public.honorario' => 'Honorario',
'public.categoria_lm' => 'Categoria LM',
'ver_tipo_honorario' => 'Ver Tipo Honorario',
'ver_contrato_factura' => 'Ver Contrato',
'ver_dependencia' => 'Ver Dependencia',
'ver_honorario' => 'Ver Honorario',
'estado_lote' => 'Estado Lote',
'ver_lote_cert' => 'Ver Lote Cert',
'audit.logged_actions' => 'Auditor�a',
'ver_categ_honorario' => 'Ver Categ Honorario',
'ver_contrato' => 'Ver Contrato');

function SetUpUserAuthorization()
{
    global $usersIds;
    global $grants;
    global $appGrants;
    global $dataSourceRecordPermissions;
    $userAuthorizationStrategy = new HardCodedUserAuthorization(new UserIdentitySessionStorage(GetIdentityCheckStrategy()), new HardCodedUserGrantsManager($grants, $appGrants), $usersIds);
    GetApplication()->SetUserAuthorizationStrategy($userAuthorizationStrategy);

GetApplication()->SetDataSourceRecordPermissionRetrieveStrategy(
    new HardCodedDataSourceRecordPermissionRetrieveStrategy($dataSourceRecordPermissions));
}

function GetIdentityCheckStrategy()
{
    global $users;
    return new SimpleIdentityCheckStrategy($users, '');
}

?>