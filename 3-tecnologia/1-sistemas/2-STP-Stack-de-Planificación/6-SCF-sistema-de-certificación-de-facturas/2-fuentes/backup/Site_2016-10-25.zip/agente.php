<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                   ATTENTION!
 * If you see this message in your browser (Internet Explorer, Mozilla Firefox, Google Chrome, etc.)
 * this means that PHP is not properly installed on your web server. Please refer to the PHP manual
 * for more details: http://php.net/manual/install.php 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */


    include_once dirname(__FILE__) . '/' . 'components/utils/check_utils.php';
    CheckPHPVersion();
    CheckTemplatesCacheFolderIsExistsAndWritable();


    include_once dirname(__FILE__) . '/' . 'phpgen_settings.php';
    include_once dirname(__FILE__) . '/' . 'database_engine/pgsql_engine.php';
    include_once dirname(__FILE__) . '/' . 'components/page.php';
    include_once dirname(__FILE__) . '/' . 'authorization.php';

    function GetConnectionOptions()
    {
        $result = GetGlobalConnectionOptions();
        $result['client_encoding'] = 'utf8';
        GetApplication()->GetUserAuthorizationStrategy()->ApplyIdentityToConnectionOptions($result);
        return $result;
    }

    
    // OnGlobalBeforePageExecute event handler
    
    
    // OnBeforePageExecute event handler
    
    
    
    class public_agentePage extends Page
    {
        protected function DoBeforeCreate()
        {
            $this->dataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."agente"');
            $field = new IntegerField('id_agente', null, null, true);
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, true);
            $field = new StringField('no_agente');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new IntegerField('id_puesto');
            $this->dataset->AddField($field, false);
            $field = new IntegerField('id_dependencia');
            $field->SetIsNotNull(true);
            $this->dataset->AddField($field, false);
            $field = new IntegerField('id_ubicacion_fisica');
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_funcion');
            $this->dataset->AddField($field, false);
            $field = new StringField('co_tipo_documento');
            $this->dataset->AddField($field, false);
            $field = new IntegerField('nu_documento');
            $this->dataset->AddField($field, false);
            $field = new BlobField('ar_documento');
            $this->dataset->AddField($field, false);
            $field = new StringField('co_cuit');
            $this->dataset->AddField($field, false);
            $field = new DateField('fe_nacimiento');
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_estudios');
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_direccion');
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_telefono');
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_celular');
            $this->dataset->AddField($field, false);
            $field = new DateField('fe_ingreso');
            $this->dataset->AddField($field, false);
            $field = new BlobField('ar_cv_agente');
            $this->dataset->AddField($field, false);
            $field = new StringField('ds_cv_agente');
            $this->dataset->AddField($field, false);
            $this->dataset->AddLookupField('id_dependencia', '(SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2)', new IntegerField('id_dependencia'), new StringField('ds_dependencia', 'id_dependencia_ds_dependencia', 'id_dependencia_ds_dependencia_ver_dependencia'), 'id_dependencia_ds_dependencia_ver_dependencia');
            $this->dataset->AddLookupField('id_puesto', 'public.puesto', new IntegerField('id_puesto', null, null, true), new StringField('no_puesto', 'id_puesto_no_puesto', 'id_puesto_no_puesto_public_puesto'), 'id_puesto_no_puesto_public_puesto');
            $this->dataset->AddLookupField('id_ubicacion_fisica', 'public.ubicacion_fisica', new IntegerField('id_ubicacion_fisica', null, null, true), new StringField('no_ubicacion_fisica', 'id_ubicacion_fisica_no_ubicacion_fisica', 'id_ubicacion_fisica_no_ubicacion_fisica_public_ubicacion_fisica'), 'id_ubicacion_fisica_no_ubicacion_fisica_public_ubicacion_fisica');
        }
    
        protected function DoPrepare() {
    
        }
    
        protected function CreatePageNavigator()
        {
            $result = new CompositePageNavigator($this);
            
            $partitionNavigator = new PageNavigator('pnav', $this, $this->dataset);
            $partitionNavigator->SetRowsPerPage(100);
            $result->AddPageNavigator($partitionNavigator);
            
            return $result;
        }
    
        public function GetPageList()
        {
            $currentPageCaption = $this->GetShortCaption();
            $result = new PageList($this);
            $result->AddGroup($this->RenderText('Facturas'));
            $result->AddGroup($this->RenderText('Contratos de Agentes'));
            $result->AddGroup($this->RenderText('Administrador'));
            if (GetCurrentUserGrantForDataSource('public.factura')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Factura'), 'factura.php', $this->RenderText('Factura'), $currentPageCaption == $this->RenderText('Factura'), false, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.certificacion')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Lote Certificaci�n'), 'certificacion.php', $this->RenderText('Lote Certificaci�n'), $currentPageCaption == $this->RenderText('Lote Certificaci�n'), true, $this->RenderText('Facturas')));
            if (GetCurrentUserGrantForDataSource('public.agente')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Agente'), 'agente.php', $this->RenderText('Agente'), $currentPageCaption == $this->RenderText('Agente'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.dependencia')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Dependencia'), 'dependencia.php', $this->RenderText('Dependencia'), $currentPageCaption == $this->RenderText('Dependencia'), true, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.ubicacion_fisica')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ubicacion Fisica'), 'ubicacion_fisica.php', $this->RenderText('Ubicacion Fisica'), $currentPageCaption == $this->RenderText('Ubicacion Fisica'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.puesto')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Puesto'), 'puesto.php', $this->RenderText('Puesto'), $currentPageCaption == $this->RenderText('Puesto'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.convenio_at')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Convenio AT'), 'convenio_at.php', $this->RenderText('Convenio Asistencia Tecnica'), $currentPageCaption == $this->RenderText('Convenio AT'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.tipo_contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Tipo Contrato'), 'tipo_contrato.php', $this->RenderText('Tipo Contrato'), $currentPageCaption == $this->RenderText('Tipo Contrato'), true, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Contrato'), 'contrato.php', $this->RenderText('Contrato'), $currentPageCaption == $this->RenderText('Contrato'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.tipo_honorario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Tipo Honorario'), 'tipo_honorario.php', $this->RenderText('Tipo Honorario'), $currentPageCaption == $this->RenderText('Tipo Honorario'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('public.honorario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Honorario'), 'honorario.php', $this->RenderText('Honorario'), $currentPageCaption == $this->RenderText('Honorario'), false, $this->RenderText('Contratos de Agentes')));
            if (GetCurrentUserGrantForDataSource('audit.logged_actions')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Auditor�a'), 'auditoria.php', $this->RenderText('Auditor�a'), $currentPageCaption == $this->RenderText('Auditor�a'), false, $this->RenderText('Administrador')));
            if (GetCurrentUserGrantForDataSource('ver_categ_honorario')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ver Categ Honorario'), 'ver_categ_honorario.php', $this->RenderText('Ver Categ Honorario'), $currentPageCaption == $this->RenderText('Ver Categ Honorario'), false, $this->RenderText('Default')));
            if (GetCurrentUserGrantForDataSource('ver_contrato')->HasViewGrant())
                $result->AddPage(new PageLink($this->RenderText('Ver Contrato'), 'ver_contrato.php', $this->RenderText('Ver Contrato'), $currentPageCaption == $this->RenderText('Ver Contrato'), false, $this->RenderText('Default')));
            
            if ( HasAdminPage() && GetApplication()->HasAdminGrantForCurrentUser() ) {
              $result->AddGroup('Admin area');
              $result->AddPage(new PageLink($this->GetLocalizerCaptions()->GetMessageString('AdminPage'), 'phpgen_admin.php', $this->GetLocalizerCaptions()->GetMessageString('AdminPage'), false, false, 'Admin area'));
            }
            return $result;
        }
    
        protected function CreateRssGenerator()
        {
            return null;
        }
    
        protected function CreateGridSearchControl(Grid $grid)
        {
            $grid->UseFilter = true;
            $grid->SearchControl = new SimpleSearch('public_agentessearch', $this->dataset,
                array('id_agente', 'no_agente', 'id_puesto_no_puesto', 'id_dependencia_ds_dependencia', 'id_ubicacion_fisica_no_ubicacion_fisica', 'ds_funcion', 'co_tipo_documento', 'nu_documento', 'co_cuit', 'fe_nacimiento', 'ds_estudios', 'ds_direccion', 'ds_telefono', 'ds_celular', 'fe_ingreso'),
                array($this->RenderText('ID Agente'), $this->RenderText('Nombre Agente'), $this->RenderText('Puesto'), $this->RenderText('Dependencia'), $this->RenderText('Ubicaci�n Fisica'), $this->RenderText('Funci�n'), $this->RenderText('Tipo Documento'), $this->RenderText('N�mero Documento'), $this->RenderText('CUIT'), $this->RenderText('Fecha Nacimiento'), $this->RenderText('Estudios'), $this->RenderText('Direcci�n'), $this->RenderText('Tel�fono'), $this->RenderText('Tel�fono Celular'), $this->RenderText('Fecha Ingreso')),
                array(
                    '=' => $this->GetLocalizerCaptions()->GetMessageString('equals'),
                    '<>' => $this->GetLocalizerCaptions()->GetMessageString('doesNotEquals'),
                    '<' => $this->GetLocalizerCaptions()->GetMessageString('isLessThan'),
                    '<=' => $this->GetLocalizerCaptions()->GetMessageString('isLessThanOrEqualsTo'),
                    '>' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThan'),
                    '>=' => $this->GetLocalizerCaptions()->GetMessageString('isGreaterThanOrEqualsTo'),
                    'ILIKE' => $this->GetLocalizerCaptions()->GetMessageString('Like'),
                    'STARTS' => $this->GetLocalizerCaptions()->GetMessageString('StartsWith'),
                    'ENDS' => $this->GetLocalizerCaptions()->GetMessageString('EndsWith'),
                    'CONTAINS' => $this->GetLocalizerCaptions()->GetMessageString('Contains')
                    ), $this->GetLocalizerCaptions(), $this, 'CONTAINS'
                );
        }
    
        protected function CreateGridAdvancedSearchControl(Grid $grid)
        {
            $this->AdvancedSearchControl = new AdvancedSearchControl('public_agenteasearch', $this->dataset, $this->GetLocalizerCaptions(), $this->GetColumnVariableContainer(), $this->CreateLinkBuilder());
            $this->AdvancedSearchControl->setTimerInterval(1000);
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('id_agente', $this->RenderText('ID Agente')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('no_agente', $this->RenderText('Nombre Agente')));
            
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."puesto"');
            $field = new IntegerField('id_puesto', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_puesto');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_puesto', GetOrderTypeAsSQL(otAscending));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateLookupSearchInput('id_puesto', $this->RenderText('Puesto'), $lookupDataset, 'id_puesto', 'no_puesto', false, 8));
            
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateLookupSearchInput('id_dependencia', $this->RenderText('Dependencia'), $lookupDataset, 'id_dependencia', 'ds_dependencia', false, 8));
            
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."ubicacion_fisica"');
            $field = new IntegerField('id_ubicacion_fisica', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_ubicacion_fisica');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new StringField('ds_direccion');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_ubicacion_fisica', GetOrderTypeAsSQL(otAscending));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateLookupSearchInput('id_ubicacion_fisica', $this->RenderText('Ubicaci�n Fisica'), $lookupDataset, 'id_ubicacion_fisica', 'no_ubicacion_fisica', false, 8));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('ds_funcion', $this->RenderText('Funci�n')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('co_tipo_documento', $this->RenderText('Tipo Documento')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('nu_documento', $this->RenderText('N�mero Documento')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateBlobSearchInput('ar_documento', $this->RenderText('Archivo Documento')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('co_cuit', $this->RenderText('CUIT')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateDateTimeSearchInput('fe_nacimiento', $this->RenderText('Fecha Nacimiento'), 'd/m/Y'));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('ds_estudios', $this->RenderText('Estudios')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('ds_direccion', $this->RenderText('Direcci�n')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('ds_telefono', $this->RenderText('Tel�fono')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateStringSearchInput('ds_celular', $this->RenderText('Tel�fono Celular')));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateDateTimeSearchInput('fe_ingreso', $this->RenderText('Fecha Ingreso'), 'd/m/Y'));
            $this->AdvancedSearchControl->AddSearchColumn($this->AdvancedSearchControl->CreateBlobSearchInput('ar_cv_agente', $this->RenderText('CV Agente')));
        }
    
        protected function AddOperationsColumns(Grid $grid)
        {
            $actionsBandName = 'actions';
            $grid->AddBandToBegin($actionsBandName, $this->GetLocalizerCaptions()->GetMessageString('Actions'), true);
            if ($this->GetSecurityInfo()->HasViewGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('View'), OPERATION_VIEW, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
            if ($this->GetSecurityInfo()->HasEditGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Edit'), OPERATION_EDIT, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowEditButtonHandler', $this);
            }
            if ($this->GetSecurityInfo()->HasDeleteGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Delete'), OPERATION_DELETE, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
                $column->OnShow->AddListener('ShowDeleteButtonHandler', $this);
                $column->SetAdditionalAttribute('data-modal-delete', 'true');
                $column->SetAdditionalAttribute('data-delete-handler-name', $this->GetModalGridDeleteHandler());
            }
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $column = new RowOperationByLinkColumn($this->GetLocalizerCaptions()->GetMessageString('Copy'), OPERATION_COPY, $this->dataset);
                $grid->AddViewColumn($column, $actionsBandName);
            }
        }
    
        protected function AddFieldColumns(Grid $grid)
        {
            //
            // View column for no_agente field
            //
            $column = new TextViewColumn('no_agente', 'Nombre Agente', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_no_agente_handler_list');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $column->SetDescription($this->RenderText('Nombre del agente que presta servicios.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(50);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_ds_dependencia_handler_list');
            $column->SetWordWrap(false);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $column->SetDescription($this->RenderText('Dependencia gubernamental del agente.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for co_cuit field
            //
            $column = new TextViewColumn('co_cuit', 'CUIT', $this->dataset);
            $column->SetOrderable(true);
            $column->SetDescription($this->RenderText('N�mero de CUIT del agente.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for fe_ingreso field
            //
            $column = new DateTimeViewColumn('fe_ingreso', 'Fecha Ingreso', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $column->SetDescription($this->RenderText('Fecha de ingreso del agente.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
            
            //
            // View column for ar_cv_agente field
            //
            $column = new DownloadDataColumn('ar_cv_agente', 'CV Agente', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $column->SetDescription($this->RenderText('Archivo del CV del agente.'));
            $column->SetFixedWidth(null);
            $grid->AddViewColumn($column);
        }
    
        protected function AddSingleRecordViewColumns(Grid $grid)
        {
            //
            // View column for id_agente field
            //
            $column = new TextViewColumn('id_agente', 'ID Agente', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for no_agente field
            //
            $column = new TextViewColumn('no_agente', 'Nombre Agente', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_no_agente_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('id_puesto_no_puesto', 'Puesto', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(50);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_ds_dependencia_handler_view');
            $column->SetWordWrap(false);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for no_ubicacion_fisica field
            //
            $column = new TextViewColumn('id_ubicacion_fisica_no_ubicacion_fisica', 'Ubicaci�n Fisica', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'ubicacion_fisica.php?operation=view&amp;pk0=%id_ubicacion_fisica%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_funcion field
            //
            $column = new TextViewColumn('ds_funcion', 'Funci�n', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_ds_funcion_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for co_tipo_documento field
            //
            $column = new TextViewColumn('co_tipo_documento', 'Tipo Documento', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for nu_documento field
            //
            $column = new TextViewColumn('nu_documento', 'N�mero Documento', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ar_documento field
            //
            $column = new ImageViewColumn('ar_documento', 'Archivo Documento', $this->dataset, true, 'public_agenteGrid_ar_documento_handler_view');
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for co_cuit field
            //
            $column = new TextViewColumn('co_cuit', 'CUIT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for fe_nacimiento field
            //
            $column = new DateTimeViewColumn('fe_nacimiento', 'Fecha Nacimiento', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_estudios field
            //
            $column = new TextViewColumn('ds_estudios', 'Estudios', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_ds_estudios_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_direccion field
            //
            $column = new TextViewColumn('ds_direccion', 'Direcci�n', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(75);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_ds_direccion_handler_view');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_telefono field
            //
            $column = new TextViewColumn('ds_telefono', 'Tel�fono', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ds_celular field
            //
            $column = new TextViewColumn('ds_celular', 'Tel�fono Celular', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for fe_ingreso field
            //
            $column = new DateTimeViewColumn('fe_ingreso', 'Fecha Ingreso', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddSingleRecordViewColumn($column);
            
            //
            // View column for ar_cv_agente field
            //
            $column = new DownloadDataColumn('ar_cv_agente', 'CV Agente', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $grid->AddSingleRecordViewColumn($column);
        }
    
        protected function AddEditColumns(Grid $grid)
        {
            //
            // Edit column for no_agente field
            //
            $editor = new TextEdit('no_agente_edit');
            $editor->SetSize(100);
            $editor->SetMaxLength(100);
            $editColumn = new CustomEditColumn('Nombre Agente', 'no_agente', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for id_puesto field
            //
            $editor = new AutocomleteComboBox('id_puesto_edit', $this->CreateLinkBuilder());
            $editor->SetSize('250px');
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."puesto"');
            $field = new IntegerField('id_puesto', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_puesto');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_puesto', GetOrderTypeAsSQL(otAscending));
            $editColumn = new DynamicLookupEditColumn('Puesto', 'id_puesto', 'id_puesto_no_puesto', 'edit_id_puesto_no_puesto_search', $editor, $this->dataset, $lookupDataset, 'id_puesto', 'no_puesto', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for id_dependencia field
            //
            $editor = new AutocomleteComboBox('id_dependencia_edit', $this->CreateLinkBuilder());
            $editor->SetSize('250px');
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $editColumn = new DynamicLookupEditColumn('Dependencia', 'id_dependencia', 'id_dependencia_ds_dependencia', 'edit_id_dependencia_ds_dependencia_search', $editor, $this->dataset, $lookupDataset, 'id_dependencia', 'ds_dependencia', '');
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for id_ubicacion_fisica field
            //
            $editor = new AutocomleteComboBox('id_ubicacion_fisica_edit', $this->CreateLinkBuilder());
            $editor->SetSize('250px');
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."ubicacion_fisica"');
            $field = new IntegerField('id_ubicacion_fisica', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_ubicacion_fisica');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new StringField('ds_direccion');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_ubicacion_fisica', GetOrderTypeAsSQL(otAscending));
            $editColumn = new DynamicLookupEditColumn('Ubicaci�n Fisica', 'id_ubicacion_fisica', 'id_ubicacion_fisica_no_ubicacion_fisica', 'edit_id_ubicacion_fisica_no_ubicacion_fisica_search', $editor, $this->dataset, $lookupDataset, 'id_ubicacion_fisica', 'no_ubicacion_fisica', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ds_funcion field
            //
            $editor = new TextEdit('ds_funcion_edit');
            $editColumn = new CustomEditColumn('Funci�n', 'ds_funcion', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for co_tipo_documento field
            //
            $editor = new ComboBox('co_tipo_documento_edit', $this->GetLocalizerCaptions()->GetMessageString('PleaseSelect'));
            $editor->AddValue('DNI', $this->RenderText('D.N.I.'));
            $editor->AddValue('LC', $this->RenderText('Libreta Civica'));
            $editor->AddValue('LE', $this->RenderText('Libreta Enrolamiento'));
            $editor->AddMFUValue($this->RenderText('DNI'));
            $editColumn = new CustomEditColumn('Tipo Documento', 'co_tipo_documento', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for nu_documento field
            //
            $editor = new TextEdit('nu_documento_edit');
            $editor->setCustomAttributes('onkeypress=\'return event.charCode >= 48 && event.charCode <= 57\'');
            $editor->setInlineStyles('text-align:right');
            $editColumn = new CustomEditColumn('N�mero Documento', 'nu_documento', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ar_documento field
            //
            $editor = new ImageUploader('ar_documento_edit');
            $editor->SetShowImage(true);
            $editColumn = new FileUploadingColumn('Archivo Documento', 'ar_documento', $editor, $this->dataset, false, false, 'public_agenteGrid_ar_documento_handler_edit');
            $editColumn->SetAllowSetToNull(true);
            $editColumn->SetImageFilter(new NullFilter());
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for co_cuit field
            //
            $editor = new TextEdit('co_cuit_edit');
            $editor->setCustomAttributes('onkeypress=\'return (event.charCode >= 48 && event.charCode <= 57) || event.charCode == 45\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetSize(20);
            $editor->SetMaxLength(20);
            $editor->SetPlaceholder($this->RenderText('00-00000000-0'));
            $editColumn = new CustomEditColumn('CUIT', 'co_cuit', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fe_nacimiento field
            //
            $editor = new DateTimeEdit('fe_nacimiento_edit', false, 'd/m/Y', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Fecha Nacimiento', 'fe_nacimiento', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ds_estudios field
            //
            $editor = new TextEdit('ds_estudios_edit');
            $editColumn = new CustomEditColumn('Estudios', 'ds_estudios', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ds_direccion field
            //
            $editor = new TextAreaEdit('ds_direccion_edit', 45, 3);
            $editColumn = new CustomEditColumn('Direcci�n', 'ds_direccion', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ds_telefono field
            //
            $editor = new TextEdit('ds_telefono_edit');
            $editor->SetSize(20);
            $editor->SetMaxLength(20);
            $editColumn = new CustomEditColumn('Tel�fono', 'ds_telefono', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ds_celular field
            //
            $editor = new TextEdit('ds_celular_edit');
            $editor->SetSize(20);
            $editor->SetMaxLength(20);
            $editColumn = new CustomEditColumn('Tel�fono Celular', 'ds_celular', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for fe_ingreso field
            //
            $editor = new DateTimeEdit('fe_ingreso_edit', false, 'd/m/Y', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Fecha Ingreso', 'fe_ingreso', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
            
            //
            // Edit column for ar_cv_agente field
            //
            $editor = new ImageUploader('ar_cv_agente_edit');
            $editor->SetShowImage(false);
            $editColumn = new FileUploadingColumn('CV Agente', 'ar_cv_agente', $editor, $this->dataset, false, false, 'public_agenteGrid_ar_cv_agente_handler_edit');
            $editColumn->SetAllowSetToNull(true);
            $editColumn->SetFileTypeFieldName('ds_cv_agente');
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddEditColumn($editColumn);
        }
    
        protected function AddInsertColumns(Grid $grid)
        {
            //
            // Edit column for no_agente field
            //
            $editor = new TextEdit('no_agente_edit');
            $editor->SetSize(100);
            $editor->SetMaxLength(100);
            $editColumn = new CustomEditColumn('Nombre Agente', 'no_agente', $editor, $this->dataset);
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for id_puesto field
            //
            $editor = new AutocomleteComboBox('id_puesto_edit', $this->CreateLinkBuilder());
            $editor->SetSize('250px');
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."puesto"');
            $field = new IntegerField('id_puesto', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_puesto');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_puesto', GetOrderTypeAsSQL(otAscending));
            $editColumn = new DynamicLookupEditColumn('Puesto', 'id_puesto', 'id_puesto_no_puesto', 'insert_id_puesto_no_puesto_search', $editor, $this->dataset, $lookupDataset, 'id_puesto', 'no_puesto', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for id_dependencia field
            //
            $editor = new AutocomleteComboBox('id_dependencia_edit', $this->CreateLinkBuilder());
            $editor->SetSize('250px');
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $editColumn = new DynamicLookupEditColumn('Dependencia', 'id_dependencia', 'id_dependencia_ds_dependencia', 'insert_id_dependencia_ds_dependencia_search', $editor, $this->dataset, $lookupDataset, 'id_dependencia', 'ds_dependencia', '');
            $validator = new RequiredValidator(StringUtils::Format($this->GetLocalizerCaptions()->GetMessageString('RequiredValidationMessage'), $this->RenderText($editColumn->GetCaption())));
            $editor->GetValidatorCollection()->AddValidator($validator);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for id_ubicacion_fisica field
            //
            $editor = new AutocomleteComboBox('id_ubicacion_fisica_edit', $this->CreateLinkBuilder());
            $editor->SetSize('250px');
            $editor->setAllowClear(true);
            $editor->setMinimumInputLength(0);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."ubicacion_fisica"');
            $field = new IntegerField('id_ubicacion_fisica', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_ubicacion_fisica');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new StringField('ds_direccion');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_ubicacion_fisica', GetOrderTypeAsSQL(otAscending));
            $editColumn = new DynamicLookupEditColumn('Ubicaci�n Fisica', 'id_ubicacion_fisica', 'id_ubicacion_fisica_no_ubicacion_fisica', 'insert_id_ubicacion_fisica_no_ubicacion_fisica_search', $editor, $this->dataset, $lookupDataset, 'id_ubicacion_fisica', 'no_ubicacion_fisica', '');
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ds_funcion field
            //
            $editor = new TextEdit('ds_funcion_edit');
            $editColumn = new CustomEditColumn('Funci�n', 'ds_funcion', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for co_tipo_documento field
            //
            $editor = new ComboBox('co_tipo_documento_edit', $this->GetLocalizerCaptions()->GetMessageString('PleaseSelect'));
            $editor->AddValue('DNI', $this->RenderText('D.N.I.'));
            $editor->AddValue('LC', $this->RenderText('Libreta Civica'));
            $editor->AddValue('LE', $this->RenderText('Libreta Enrolamiento'));
            $editor->AddMFUValue($this->RenderText('DNI'));
            $editColumn = new CustomEditColumn('Tipo Documento', 'co_tipo_documento', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for nu_documento field
            //
            $editor = new TextEdit('nu_documento_edit');
            $editor->setCustomAttributes('onkeypress=\'return event.charCode >= 48 && event.charCode <= 57\'');
            $editor->setInlineStyles('text-align:right');
            $editColumn = new CustomEditColumn('N�mero Documento', 'nu_documento', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ar_documento field
            //
            $editor = new ImageUploader('ar_documento_edit');
            $editor->SetShowImage(true);
            $editColumn = new FileUploadingColumn('Archivo Documento', 'ar_documento', $editor, $this->dataset, false, false, 'public_agenteGrid_ar_documento_handler_insert');
            $editColumn->SetAllowSetToNull(true);
            $editColumn->SetImageFilter(new NullFilter());
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for co_cuit field
            //
            $editor = new TextEdit('co_cuit_edit');
            $editor->setCustomAttributes('onkeypress=\'return (event.charCode >= 48 && event.charCode <= 57) || event.charCode == 45\'');
            $editor->setInlineStyles('text-align:right');
            $editor->SetSize(20);
            $editor->SetMaxLength(20);
            $editor->SetPlaceholder($this->RenderText('00-00000000-0'));
            $editColumn = new CustomEditColumn('CUIT', 'co_cuit', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fe_nacimiento field
            //
            $editor = new DateTimeEdit('fe_nacimiento_edit', false, 'd/m/Y', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Fecha Nacimiento', 'fe_nacimiento', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ds_estudios field
            //
            $editor = new TextEdit('ds_estudios_edit');
            $editColumn = new CustomEditColumn('Estudios', 'ds_estudios', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ds_direccion field
            //
            $editor = new TextAreaEdit('ds_direccion_edit', 45, 3);
            $editColumn = new CustomEditColumn('Direcci�n', 'ds_direccion', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ds_telefono field
            //
            $editor = new TextEdit('ds_telefono_edit');
            $editor->SetSize(20);
            $editor->SetMaxLength(20);
            $editColumn = new CustomEditColumn('Tel�fono', 'ds_telefono', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ds_celular field
            //
            $editor = new TextEdit('ds_celular_edit');
            $editor->SetSize(20);
            $editor->SetMaxLength(20);
            $editColumn = new CustomEditColumn('Tel�fono Celular', 'ds_celular', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for fe_ingreso field
            //
            $editor = new DateTimeEdit('fe_ingreso_edit', false, 'd/m/Y', GetFirstDayOfWeek());
            $editColumn = new CustomEditColumn('Fecha Ingreso', 'fe_ingreso', $editor, $this->dataset);
            $editColumn->SetAllowSetToNull(true);
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            
            //
            // Edit column for ar_cv_agente field
            //
            $editor = new ImageUploader('ar_cv_agente_edit');
            $editor->SetShowImage(false);
            $editColumn = new FileUploadingColumn('CV Agente', 'ar_cv_agente', $editor, $this->dataset, false, false, 'public_agenteGrid_ar_cv_agente_handler_insert');
            $editColumn->SetAllowSetToNull(true);
            $editColumn->SetFileTypeFieldName('ds_cv_agente');
            $this->ApplyCommonColumnEditProperties($editColumn);
            $grid->AddInsertColumn($editColumn);
            if ($this->GetSecurityInfo()->HasAddGrant())
            {
                $grid->SetShowAddButton(true);
                $grid->SetShowInlineAddButton(false);
            }
            else
            {
                $grid->SetShowInlineAddButton(false);
                $grid->SetShowAddButton(false);
            }
        }
    
        protected function AddPrintColumns(Grid $grid)
        {
            //
            // View column for id_agente field
            //
            $column = new TextViewColumn('id_agente', 'ID Agente', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for no_agente field
            //
            $column = new TextViewColumn('no_agente', 'No Agente', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('id_puesto_no_puesto', 'Puesto', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(50);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_ds_dependencia_handler_print');
            $column->SetWordWrap(false);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddPrintColumn($column);
            
            //
            // View column for no_ubicacion_fisica field
            //
            $column = new TextViewColumn('id_ubicacion_fisica_no_ubicacion_fisica', 'Ubicaci�n Fisica', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'ubicacion_fisica.php?operation=view&amp;pk0=%id_ubicacion_fisica%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_funcion field
            //
            $column = new TextViewColumn('ds_funcion', 'Ds Funcion', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for co_tipo_documento field
            //
            $column = new TextViewColumn('co_tipo_documento', 'Tipo Documento', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for nu_documento field
            //
            $column = new TextViewColumn('nu_documento', 'N�mero Documento', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ar_documento field
            //
            $column = new ImageViewColumn('ar_documento', 'Archivo Documento', $this->dataset, true, 'public_agenteGrid_ar_documento_handler_print');
            $grid->AddPrintColumn($column);
            
            //
            // View column for co_cuit field
            //
            $column = new TextViewColumn('co_cuit', 'CUIT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for fe_nacimiento field
            //
            $column = new DateTimeViewColumn('fe_nacimiento', 'Fecha Nacimiento', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_estudios field
            //
            $column = new TextViewColumn('ds_estudios', 'Ds Estudios', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_direccion field
            //
            $column = new TextViewColumn('ds_direccion', 'Ds Direccion', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_telefono field
            //
            $column = new TextViewColumn('ds_telefono', 'Tel�fono', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddPrintColumn($column);
            
            //
            // View column for ds_celular field
            //
            $column = new TextViewColumn('ds_celular', 'Tel�fono Celular', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddPrintColumn($column);
            
            //
            // View column for fe_ingreso field
            //
            $column = new DateTimeViewColumn('fe_ingreso', 'Fecha Ingreso', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddPrintColumn($column);
            
            //
            // View column for ar_cv_agente field
            //
            $column = new DownloadDataColumn('ar_cv_agente', 'CV Agente', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $grid->AddPrintColumn($column);
        }
    
        protected function AddExportColumns(Grid $grid)
        {
            //
            // View column for id_agente field
            //
            $column = new TextViewColumn('id_agente', 'ID Agente', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for no_agente field
            //
            $column = new TextViewColumn('no_agente', 'No Agente', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for no_puesto field
            //
            $column = new TextViewColumn('id_puesto_no_puesto', 'Puesto', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column->SetMaxLength(50);
            $column->SetFullTextWindowHandlerName('public_agenteGrid_ds_dependencia_handler_export');
            $column->SetWordWrap(false);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddExportColumn($column);
            
            //
            // View column for no_ubicacion_fisica field
            //
            $column = new TextViewColumn('id_ubicacion_fisica_no_ubicacion_fisica', 'Ubicaci�n Fisica', $this->dataset);
            $column->SetOrderable(true);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'ubicacion_fisica.php?operation=view&amp;pk0=%id_ubicacion_fisica%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_funcion field
            //
            $column = new TextViewColumn('ds_funcion', 'Ds Funcion', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for co_tipo_documento field
            //
            $column = new TextViewColumn('co_tipo_documento', 'Tipo Documento', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for nu_documento field
            //
            $column = new TextViewColumn('nu_documento', 'N�mero Documento', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ar_documento field
            //
            $column = new ImageViewColumn('ar_documento', 'Archivo Documento', $this->dataset, true, 'public_agenteGrid_ar_documento_handler_export');
            $grid->AddExportColumn($column);
            
            //
            // View column for co_cuit field
            //
            $column = new TextViewColumn('co_cuit', 'CUIT', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for fe_nacimiento field
            //
            $column = new DateTimeViewColumn('fe_nacimiento', 'Fecha Nacimiento', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_estudios field
            //
            $column = new TextViewColumn('ds_estudios', 'Ds Estudios', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_direccion field
            //
            $column = new TextViewColumn('ds_direccion', 'Ds Direccion', $this->dataset);
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_telefono field
            //
            $column = new TextViewColumn('ds_telefono', 'Tel�fono', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddExportColumn($column);
            
            //
            // View column for ds_celular field
            //
            $column = new TextViewColumn('ds_celular', 'Tel�fono Celular', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $grid->AddExportColumn($column);
            
            //
            // View column for fe_ingreso field
            //
            $column = new DateTimeViewColumn('fe_ingreso', 'Fecha Ingreso', $this->dataset);
            $column->SetDateTimeFormat('d/m/Y');
            $column->SetOrderable(true);
            $grid->AddExportColumn($column);
            
            //
            // View column for ar_cv_agente field
            //
            $column = new DownloadDataColumn('ar_cv_agente', 'CV Agente', $this->dataset, $this->GetLocalizerCaptions()->GetMessageString('Download'));
            $grid->AddExportColumn($column);
        }
    
        public function GetPageDirection()
        {
            return null;
        }
    
        protected function ApplyCommonColumnEditProperties(CustomEditColumn $column)
        {
            $column->SetDisplaySetToNullCheckBox(false);
            $column->SetDisplaySetToDefaultCheckBox(false);
    		$column->SetVariableContainer($this->GetColumnVariableContainer());
        }
    
        function GetCustomClientScript()
        {
            return ;
        }
        
        function GetOnPageLoadedClientScript()
        {
            return ;
        }
        public function ShowEditButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasEditGrant($this->GetDataset());
        }
        public function ShowDeleteButtonHandler(&$show)
        {
            if ($this->GetRecordPermission() != null)
                $show = $this->GetRecordPermission()->HasDeleteGrant($this->GetDataset());
        }
        
        public function GetModalGridDeleteHandler() { return 'public_agente_modal_delete'; }
        protected function GetEnableModalGridDelete() { return true; }
    
        protected function CreateGrid()
        {
            $result = new Grid($this, $this->dataset, 'public_agenteGrid');
            if ($this->GetSecurityInfo()->HasDeleteGrant())
               $result->SetAllowDeleteSelected(false);
            else
               $result->SetAllowDeleteSelected(false);   
            
            ApplyCommonPageSettings($this, $result);
            
            $result->SetUseImagesForActions(true);
            $result->SetUseFixedHeader(false);
            $result->SetShowLineNumbers(false);
            $result->SetShowKeyColumnsImagesInHeader(false);
            
            $result->SetHighlightRowAtHover(true);
            $result->SetWidth('');
            $this->CreateGridSearchControl($result);
            $this->CreateGridAdvancedSearchControl($result);
            $this->AddOperationsColumns($result);
            $this->AddFieldColumns($result);
            $this->AddSingleRecordViewColumns($result);
            $this->AddEditColumns($result);
            $this->AddInsertColumns($result);
            $this->AddPrintColumns($result);
            $this->AddExportColumns($result);
    
            $this->SetShowPageList(true);
            $this->SetHidePageListByDefault(false);
            $this->SetExportToExcelAvailable(true);
            $this->SetExportToWordAvailable(true);
            $this->SetExportToXmlAvailable(true);
            $this->SetExportToCsvAvailable(true);
            $this->SetExportToPdfAvailable(true);
            $this->SetPrinterFriendlyAvailable(true);
            $this->SetSimpleSearchAvailable(true);
            $this->SetAdvancedSearchAvailable(true);
            $this->SetFilterRowAvailable(true);
            $this->SetVisualEffectsEnabled(true);
            $this->SetShowTopPageNavigator(true);
            $this->SetShowBottomPageNavigator(true);
    
            //
            // Http Handlers
            //
            //
            // View column for no_agente field
            //
            $column = new TextViewColumn('no_agente', 'Nombre Agente', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_no_agente_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column->SetWordWrap(false);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_ds_dependencia_handler_list', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new DownloadHTTPHandler($this->dataset, 'ar_cv_agente', 'ar_cv_agente_handler', '%ds_cv_agente%', 'CV_%co_cuit%.%ds_cv_agente%', true);
            GetApplication()->RegisterHTTPHandler($handler);//
            // View column for no_agente field
            //
            $column = new TextViewColumn('no_agente', 'Nombre Agente', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_no_agente_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column->SetWordWrap(false);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_ds_dependencia_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_funcion field
            //
            $column = new TextViewColumn('ds_funcion', 'Funci�n', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_ds_funcion_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            
            
            
            $handler = new ImageHTTPHandler($this->dataset, 'ar_documento', 'public_agenteGrid_ar_documento_handler_view', new ImageFitByWidthResizeFilter(300));
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_estudios field
            //
            $column = new TextViewColumn('ds_estudios', 'Estudios', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_ds_estudios_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_direccion field
            //
            $column = new TextViewColumn('ds_direccion', 'Direcci�n', $this->dataset);
            $column->SetOrderable(true);
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_ds_direccion_handler_view', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new DownloadHTTPHandler($this->dataset, 'ar_cv_agente', 'ar_cv_agente_handler', '%ds_cv_agente%', 'CV_%co_cuit%.%ds_cv_agente%', true);
            GetApplication()->RegisterHTTPHandler($handler);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."puesto"');
            $field = new IntegerField('id_puesto', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_puesto');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_puesto', GetOrderTypeAsSQL(otAscending));
            $lookupDataset->AddCustomCondition(EnvVariablesUtils::EvaluateVariableTemplate($this->GetColumnVariableContainer(), ''));
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'edit_id_puesto_no_puesto_search', 'id_puesto', 'no_puesto', null);
            GetApplication()->RegisterHTTPHandler($handler);
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $lookupDataset->AddCustomCondition(EnvVariablesUtils::EvaluateVariableTemplate($this->GetColumnVariableContainer(), ''));
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'edit_id_dependencia_ds_dependencia_search', 'id_dependencia', 'ds_dependencia', null);
            GetApplication()->RegisterHTTPHandler($handler);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."ubicacion_fisica"');
            $field = new IntegerField('id_ubicacion_fisica', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_ubicacion_fisica');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new StringField('ds_direccion');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_ubicacion_fisica', GetOrderTypeAsSQL(otAscending));
            $lookupDataset->AddCustomCondition(EnvVariablesUtils::EvaluateVariableTemplate($this->GetColumnVariableContainer(), ''));
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'edit_id_ubicacion_fisica_no_ubicacion_fisica_search', 'id_ubicacion_fisica', 'no_ubicacion_fisica', null);
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new ImageHTTPHandler($this->dataset, 'ar_documento', 'public_agenteGrid_ar_documento_handler_edit', new NullFilter());
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new ImageHTTPHandler($this->dataset, 'ar_cv_agente', 'public_agenteGrid_ar_cv_agente_handler_edit', new NullFilter());
            GetApplication()->RegisterHTTPHandler($handler);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."puesto"');
            $field = new IntegerField('id_puesto', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_puesto');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_puesto', GetOrderTypeAsSQL(otAscending));
            $lookupDataset->AddCustomCondition(EnvVariablesUtils::EvaluateVariableTemplate($this->GetColumnVariableContainer(), ''));
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'insert_id_puesto_no_puesto_search', 'id_puesto', 'no_puesto', null);
            GetApplication()->RegisterHTTPHandler($handler);
            $selectQuery = 'SELECT
            id_dependencia,
            TRIM(COALESCE(no_ministerio, \'-\') ||
            COALESCE(\' | \' || no_secretaria, \'\') ||
            COALESCE(\' | \' || no_subsecretaria, \'\') ||
            COALESCE(\' | \' || no_direccion_area, \'\') ||
            COALESCE(\' | \' || no_area_dependencia, \'\') ||
            COALESCE(\' | \' || no_sector, \'\') ||
            COALESCE(\' | \' || no_subsector, \'\')) AS ds_dependencia
            FROM dependencia
            ORDER BY 2';
            $insertQuery = array();
            $updateQuery = array();
            $deleteQuery = array();
            $lookupDataset = new QueryDataset(
              new PgConnectionFactory(), 
              GetConnectionOptions(),
              $selectQuery, $insertQuery, $updateQuery, $deleteQuery, 'ver_dependencia');
            $field = new IntegerField('id_dependencia');
            $lookupDataset->AddField($field, true);
            $field = new StringField('ds_dependencia');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('ds_dependencia', GetOrderTypeAsSQL(otAscending));
            $lookupDataset->AddCustomCondition(EnvVariablesUtils::EvaluateVariableTemplate($this->GetColumnVariableContainer(), ''));
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'insert_id_dependencia_ds_dependencia_search', 'id_dependencia', 'ds_dependencia', null);
            GetApplication()->RegisterHTTPHandler($handler);
            $lookupDataset = new TableDataset(
                new PgConnectionFactory(),
                GetConnectionOptions(),
                '"public"."ubicacion_fisica"');
            $field = new IntegerField('id_ubicacion_fisica', null, null, true);
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, true);
            $field = new StringField('no_ubicacion_fisica');
            $field->SetIsNotNull(true);
            $lookupDataset->AddField($field, false);
            $field = new StringField('ds_direccion');
            $lookupDataset->AddField($field, false);
            $lookupDataset->setOrderByField('no_ubicacion_fisica', GetOrderTypeAsSQL(otAscending));
            $lookupDataset->AddCustomCondition(EnvVariablesUtils::EvaluateVariableTemplate($this->GetColumnVariableContainer(), ''));
            $handler = new DynamicSearchHandler($lookupDataset, $this, 'insert_id_ubicacion_fisica_no_ubicacion_fisica_search', 'id_ubicacion_fisica', 'no_ubicacion_fisica', null);
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new ImageHTTPHandler($this->dataset, 'ar_documento', 'public_agenteGrid_ar_documento_handler_insert', new NullFilter());
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new ImageHTTPHandler($this->dataset, 'ar_cv_agente', 'public_agenteGrid_ar_cv_agente_handler_insert', new NullFilter());
            GetApplication()->RegisterHTTPHandler($handler);
            //
            // View column for ds_dependencia field
            //
            $column = new TextViewColumn('id_dependencia_ds_dependencia', 'Dependencia', $this->dataset);
            $column->SetOrderable(true);
            $column->SetWordWrap(false);
            $column = new ExtendedHyperLinkColumnDecorator($column, $this->dataset, 'dependencia.php?operation=view&amp;pk0=%id_dependencia%' , '_blank');
            $column = new DivTagViewColumnDecorator($column);
            $column->Align = 'left';
            $handler = new ShowTextBlobHandler($this->dataset, $this, 'public_agenteGrid_ds_dependencia_handler_print', $column);
            GetApplication()->RegisterHTTPHandler($handler);
            
            
            
            $handler = new ImageHTTPHandler($this->dataset, 'ar_documento', 'public_agenteGrid_ar_documento_handler_print', new ImageFitByWidthResizeFilter(300));
            GetApplication()->RegisterHTTPHandler($handler);
            $handler = new DownloadHTTPHandler($this->dataset, 'ar_cv_agente', 'ar_cv_agente_handler', '%ds_cv_agente%', 'CV_%co_cuit%.%ds_cv_agente%', true);
            GetApplication()->RegisterHTTPHandler($handler);
            return $result;
        }
        
        public function OpenAdvancedSearchByDefault()
        {
            return false;
        }
    
        protected function DoGetGridHeader()
        {
            return '';
        }
    }

    SetUpUserAuthorization(GetApplication());

    try
    {
        $Page = new public_agentePage("agente.php", "public_agente", GetCurrentUserGrantForDataSource("public.agente"), 'UTF-8');
        $Page->SetShortCaption('Agente');
        $Page->SetHeader(GetPagesHeader());
        $Page->SetFooter(GetPagesFooter());
        $Page->SetCaption('Agente');
        $Page->SetRecordPermission(GetCurrentUserRecordPermissionsForDataSource("public.agente"));
        GetApplication()->SetEnableLessRunTimeCompile(GetEnableLessFilesRunTimeCompilation());
        GetApplication()->SetCanUserChangeOwnPassword(
            !function_exists('CanUserChangeOwnPassword') || CanUserChangeOwnPassword());
        GetApplication()->SetMainPage($Page);
        GetApplication()->Run();
    }
    catch(Exception $e)
    {
        ShowErrorPage($e->getMessage());
    }
	
