--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.5
-- Dumped by pg_dump version 9.1.5
-- Started on 2016-03-16 10:11:16

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 187 (class 3079 OID 11639)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2028 (class 0 OID 0)
-- Dependencies: 187
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- TOC entry 205 (class 1255 OID 33442)
-- Dependencies: 6 575
-- Name: fn_accion_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_accion_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(
	COALESCE((SELECT ds_referencia FROM sga_tipo_accion WHERE id_tipo_accion = NEW.id_tipo_accion), ' ') ||
	COALESCE(' > ' || (SELECT ds_referencia FROM sga_tipo_bien WHERE id_tipo_bien = NEW.id_tipo_bien), ' ') ||
	COALESCE(' > ' || (SELECT ds_referencia FROM sga_tipo_espacio WHERE id_tipo_espacio = NEW.id_tipo_espacio), ' ') ||
	COALESCE(' > ' || (SELECT no_sector FROM sga_sector WHERE id_sector = NEW.id_sector), ' '));
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_accion_tg() OWNER TO rcdto;

--
-- TOC entry 199 (class 1255 OID 33443)
-- Dependencies: 6 575
-- Name: fn_actividad_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_actividad_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(COALESCE(
	(SELECT ds_referencia FROM sga_actividad WHERE id_actividad = NEW.id_actividad_padre) || ' | ', ' ')
	|| NEW.no_actividad);
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_actividad_tg() OWNER TO rcdto;

--
-- TOC entry 203 (class 1255 OID 33444)
-- Dependencies: 575 6
-- Name: fn_area_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_area_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(COALESCE(
	(SELECT ds_referencia FROM sga_area WHERE id_area = NEW.id_area_padre) || ' | ', ' ')
	|| NEW.no_area);
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_area_tg() OWNER TO rcdto;

--
-- TOC entry 206 (class 1255 OID 33445)
-- Dependencies: 575 6
-- Name: fn_espacio_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_espacio_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(
	COALESCE((SELECT ds_referencia FROM sga_tipo_espacio WHERE id_tipo_espacio = NEW.id_tipo_espacio) || ' > ', ' ') ||
	COALESCE((SELECT no_sector FROM sga_sector WHERE id_sector = NEW.id_sector) || ' > ', ' ') ||
	COALESCE((SELECT no_planta FROM sga_planta WHERE id_planta = NEW.id_planta) || ' > ', ' ') ||
	COALESCE(TRIM(NEW.no_espacio)));
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_espacio_tg() OWNER TO rcdto;

--
-- TOC entry 204 (class 1255 OID 33446)
-- Dependencies: 575 6
-- Name: fn_tarea_plan_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_tarea_plan_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(
	COALESCE((SELECT ds_referencia FROM sga_accion WHERE id_accion = NEW.id_accion), NEW.id_tarea_plan::varchar));
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_tarea_plan_tg() OWNER TO rcdto;

--
-- TOC entry 200 (class 1255 OID 33447)
-- Dependencies: 6 575
-- Name: fn_tipo_accion_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_tipo_accion_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(COALESCE(
	(SELECT ds_referencia FROM sga_tipo_accion WHERE id_tipo_accion = NEW.id_tipo_accion_padre) || ' | ', ' ')
	|| NEW.no_tipo_accion);
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_tipo_accion_tg() OWNER TO rcdto;

--
-- TOC entry 201 (class 1255 OID 33448)
-- Dependencies: 6 575
-- Name: fn_tipo_bien_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_tipo_bien_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(COALESCE(
	(SELECT ds_referencia FROM sga_tipo_bien WHERE id_tipo_bien = NEW.id_tipo_bien_padre) || ' | ', ' ')
	|| NEW.no_tipo_bien);
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_tipo_bien_tg() OWNER TO rcdto;

--
-- TOC entry 202 (class 1255 OID 33449)
-- Dependencies: 575 6
-- Name: fn_tipo_espacio_tg(); Type: FUNCTION; Schema: public; Owner: rcdto
--

CREATE FUNCTION fn_tipo_espacio_tg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.ds_referencia = TRIM(COALESCE(
	(SELECT ds_referencia FROM sga_tipo_espacio WHERE id_tipo_espacio = NEW.id_tipo_espacio_padre) || ' | ', ' ')
	|| NEW.no_tipo_espacio);
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_tipo_espacio_tg() OWNER TO rcdto;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 161 (class 1259 OID 33450)
-- Dependencies: 1935 6
-- Name: sga_accion; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_accion (
    id_accion integer NOT NULL,
    id_tipo_espacio smallint,
    id_tipo_bien integer,
    id_origen integer DEFAULT 2,
    id_metodologia integer,
    id_periodicidad integer,
    fl_a_demanda boolean NOT NULL,
    ds_referencia character varying(400),
    id_tipo_accion integer,
    id_sector smallint
);


ALTER TABLE public.sga_accion OWNER TO rcdto;

--
-- TOC entry 2029 (class 0 OID 0)
-- Dependencies: 161
-- Name: TABLE sga_accion; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_accion IS 'Actividad específica a realizar sobre un tipo de bien y un espacio.';


--
-- TOC entry 2030 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.id_accion; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.id_accion IS 'Identificador único de la acción.';


--
-- TOC entry 2031 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.id_tipo_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.id_tipo_espacio IS 'Identificador único del tipo de espacio.';


--
-- TOC entry 2032 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.id_tipo_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.id_tipo_bien IS 'Identificador único del tipo de bien.';


--
-- TOC entry 2033 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.id_origen; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.id_origen IS 'Identificador único de origen.';


--
-- TOC entry 2034 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.id_metodologia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.id_metodologia IS 'Identificador único de la metodología.';


--
-- TOC entry 2035 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.id_periodicidad; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.id_periodicidad IS 'Identificador único de la periodicidad.';


--
-- TOC entry 2036 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.fl_a_demanda; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.fl_a_demanda IS 'Indicador de si la actividad puede ser realizada a demanda.';


--
-- TOC entry 2037 (class 0 OID 0)
-- Dependencies: 161
-- Name: COLUMN sga_accion.ds_referencia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_accion.ds_referencia IS 'Referencia del registro.';


--
-- TOC entry 162 (class 1259 OID 33454)
-- Dependencies: 6 161
-- Name: sga_accion_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_accion_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_accion_sq OWNER TO rcdto;

--
-- TOC entry 2038 (class 0 OID 0)
-- Dependencies: 162
-- Name: sga_accion_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_accion_sq OWNED BY sga_accion.id_accion;


--
-- TOC entry 2039 (class 0 OID 0)
-- Dependencies: 162
-- Name: sga_accion_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_accion_sq', 6, true);


--
-- TOC entry 163 (class 1259 OID 33464)
-- Dependencies: 1937 6
-- Name: sga_bien; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_bien (
    id_bien integer NOT NULL,
    id_tipo_bien integer NOT NULL,
    id_espacio integer NOT NULL,
    ds_observacion character varying(400),
    nu_cantidad integer DEFAULT 1
);


ALTER TABLE public.sga_bien OWNER TO rcdto;

--
-- TOC entry 2040 (class 0 OID 0)
-- Dependencies: 163
-- Name: TABLE sga_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_bien IS 'Bienes del centro cultural.';


--
-- TOC entry 2041 (class 0 OID 0)
-- Dependencies: 163
-- Name: COLUMN sga_bien.id_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_bien.id_bien IS 'Identificador único del bien.';


--
-- TOC entry 2042 (class 0 OID 0)
-- Dependencies: 163
-- Name: COLUMN sga_bien.id_tipo_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_bien.id_tipo_bien IS 'Identificador único del tipo de bien.';


--
-- TOC entry 2043 (class 0 OID 0)
-- Dependencies: 163
-- Name: COLUMN sga_bien.id_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_bien.id_espacio IS 'Identificador único del espacio.';


--
-- TOC entry 2044 (class 0 OID 0)
-- Dependencies: 163
-- Name: COLUMN sga_bien.ds_observacion; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_bien.ds_observacion IS 'Observaciones del bien.';


--
-- TOC entry 164 (class 1259 OID 33468)
-- Dependencies: 6 163
-- Name: sga_bien_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_bien_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_bien_sq OWNER TO rcdto;

--
-- TOC entry 2045 (class 0 OID 0)
-- Dependencies: 164
-- Name: sga_bien_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_bien_sq OWNED BY sga_bien.id_bien;


--
-- TOC entry 2046 (class 0 OID 0)
-- Dependencies: 164
-- Name: sga_bien_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_bien_sq', 3, true);


--
-- TOC entry 165 (class 1259 OID 33475)
-- Dependencies: 6
-- Name: sga_espacio; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_espacio (
    id_espacio integer NOT NULL,
    id_tipo_espacio smallint NOT NULL,
    id_espacio_contenedor integer,
    co_espacio character varying(50) NOT NULL,
    no_espacio character varying(100) NOT NULL,
    co_plano character varying(50),
    id_planta smallint,
    ds_referencia character varying(400),
    id_sector smallint
);


ALTER TABLE public.sga_espacio OWNER TO rcdto;

--
-- TOC entry 2047 (class 0 OID 0)
-- Dependencies: 165
-- Name: TABLE sga_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_espacio IS 'Espacios físicos dentro del centro cultural.';


--
-- TOC entry 2048 (class 0 OID 0)
-- Dependencies: 165
-- Name: COLUMN sga_espacio.id_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_espacio.id_espacio IS 'Identificador único del espacio.';


--
-- TOC entry 2049 (class 0 OID 0)
-- Dependencies: 165
-- Name: COLUMN sga_espacio.id_tipo_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_espacio.id_tipo_espacio IS 'Identificador único del tipo de espacio.';


--
-- TOC entry 2050 (class 0 OID 0)
-- Dependencies: 165
-- Name: COLUMN sga_espacio.id_espacio_contenedor; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_espacio.id_espacio_contenedor IS 'Identificador único del espacio contenedor (padre).';


--
-- TOC entry 2051 (class 0 OID 0)
-- Dependencies: 165
-- Name: COLUMN sga_espacio.co_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_espacio.co_espacio IS 'Código de espacio.';


--
-- TOC entry 2052 (class 0 OID 0)
-- Dependencies: 165
-- Name: COLUMN sga_espacio.no_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_espacio.no_espacio IS 'Nombre del espacio.';


--
-- TOC entry 2053 (class 0 OID 0)
-- Dependencies: 165
-- Name: COLUMN sga_espacio.co_plano; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_espacio.co_plano IS 'Codificación del espacio en los planos de Espacio Físico.';


--
-- TOC entry 166 (class 1259 OID 33481)
-- Dependencies: 6 165
-- Name: sga_espacio_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_espacio_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_espacio_sq OWNER TO rcdto;

--
-- TOC entry 2054 (class 0 OID 0)
-- Dependencies: 166
-- Name: sga_espacio_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_espacio_sq OWNED BY sga_espacio.id_espacio;


--
-- TOC entry 2055 (class 0 OID 0)
-- Dependencies: 166
-- Name: sga_espacio_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_espacio_sq', 28, true);


--
-- TOC entry 167 (class 1259 OID 33500)
-- Dependencies: 6
-- Name: sga_metodologia; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_metodologia (
    id_metodologia integer NOT NULL,
    no_metodologia character varying(100) NOT NULL,
    ds_metodologia character varying(4000),
    id_origen integer
);


ALTER TABLE public.sga_metodologia OWNER TO rcdto;

--
-- TOC entry 2056 (class 0 OID 0)
-- Dependencies: 167
-- Name: TABLE sga_metodologia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_metodologia IS 'Metodología de realización de la actividad.';


--
-- TOC entry 2057 (class 0 OID 0)
-- Dependencies: 167
-- Name: COLUMN sga_metodologia.id_metodologia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_metodologia.id_metodologia IS 'Identificador único de una metodología.';


--
-- TOC entry 2058 (class 0 OID 0)
-- Dependencies: 167
-- Name: COLUMN sga_metodologia.no_metodologia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_metodologia.no_metodologia IS 'Nombre de la metodología.';


--
-- TOC entry 2059 (class 0 OID 0)
-- Dependencies: 167
-- Name: COLUMN sga_metodologia.ds_metodologia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_metodologia.ds_metodologia IS 'Descripción del metodología.';


--
-- TOC entry 2060 (class 0 OID 0)
-- Dependencies: 167
-- Name: COLUMN sga_metodologia.id_origen; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_metodologia.id_origen IS 'Identificador único de origen.';


--
-- TOC entry 168 (class 1259 OID 33509)
-- Dependencies: 6
-- Name: sga_origen; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_origen (
    id_origen integer NOT NULL,
    no_origen character varying(100) NOT NULL
);


ALTER TABLE public.sga_origen OWNER TO rcdto;

--
-- TOC entry 2061 (class 0 OID 0)
-- Dependencies: 168
-- Name: TABLE sga_origen; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_origen IS 'Origen de la especificación de la actividad/procedimiento.';


--
-- TOC entry 2062 (class 0 OID 0)
-- Dependencies: 168
-- Name: COLUMN sga_origen.id_origen; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_origen.id_origen IS 'Identificador único de origen.';


--
-- TOC entry 2063 (class 0 OID 0)
-- Dependencies: 168
-- Name: COLUMN sga_origen.no_origen; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_origen.no_origen IS 'Nombre del origen de la actividad/procedimiento.';


--
-- TOC entry 169 (class 1259 OID 33515)
-- Dependencies: 168 6
-- Name: sga_origen_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_origen_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_origen_sq OWNER TO rcdto;

--
-- TOC entry 2064 (class 0 OID 0)
-- Dependencies: 169
-- Name: sga_origen_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_origen_sq OWNED BY sga_origen.id_origen;


--
-- TOC entry 2065 (class 0 OID 0)
-- Dependencies: 169
-- Name: sga_origen_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_origen_sq', 4, false);


--
-- TOC entry 170 (class 1259 OID 33517)
-- Dependencies: 1942 6
-- Name: sga_periodicidad; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_periodicidad (
    id_periodicidad integer NOT NULL,
    no_periodicidad character varying(100) NOT NULL,
    va_frecuencia real DEFAULT 1 NOT NULL
);


ALTER TABLE public.sga_periodicidad OWNER TO rcdto;

--
-- TOC entry 2066 (class 0 OID 0)
-- Dependencies: 170
-- Name: TABLE sga_periodicidad; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_periodicidad IS 'Periodicidad de realización de una tarea.';


--
-- TOC entry 2067 (class 0 OID 0)
-- Dependencies: 170
-- Name: COLUMN sga_periodicidad.id_periodicidad; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_periodicidad.id_periodicidad IS 'Identificador único de la periodicidad.';


--
-- TOC entry 2068 (class 0 OID 0)
-- Dependencies: 170
-- Name: COLUMN sga_periodicidad.no_periodicidad; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_periodicidad.no_periodicidad IS 'Nombre de la periodicidad.';


--
-- TOC entry 2069 (class 0 OID 0)
-- Dependencies: 170
-- Name: COLUMN sga_periodicidad.va_frecuencia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_periodicidad.va_frecuencia IS 'Frecuencia (en días) de realización de la actividad.';


--
-- TOC entry 171 (class 1259 OID 33521)
-- Dependencies: 170 6
-- Name: sga_periodicidad_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_periodicidad_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_periodicidad_sq OWNER TO rcdto;

--
-- TOC entry 2070 (class 0 OID 0)
-- Dependencies: 171
-- Name: sga_periodicidad_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_periodicidad_sq OWNED BY sga_periodicidad.id_periodicidad;


--
-- TOC entry 2071 (class 0 OID 0)
-- Dependencies: 171
-- Name: sga_periodicidad_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_periodicidad_sq', 13, true);


--
-- TOC entry 172 (class 1259 OID 33528)
-- Dependencies: 6
-- Name: sga_planta; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_planta (
    id_planta smallint NOT NULL,
    no_planta character varying(100) NOT NULL
);


ALTER TABLE public.sga_planta OWNER TO rcdto;

--
-- TOC entry 2072 (class 0 OID 0)
-- Dependencies: 172
-- Name: TABLE sga_planta; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_planta IS 'Planta en la que se encuentra el espacio.';


--
-- TOC entry 2073 (class 0 OID 0)
-- Dependencies: 172
-- Name: COLUMN sga_planta.id_planta; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_planta.id_planta IS 'Identificador único de la planta.';


--
-- TOC entry 2074 (class 0 OID 0)
-- Dependencies: 172
-- Name: COLUMN sga_planta.no_planta; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_planta.no_planta IS 'Nombre de la planta.';


--
-- TOC entry 173 (class 1259 OID 33531)
-- Dependencies: 6 172
-- Name: sga_planta_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_planta_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_planta_sq OWNER TO rcdto;

--
-- TOC entry 2075 (class 0 OID 0)
-- Dependencies: 173
-- Name: sga_planta_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_planta_sq OWNED BY sga_planta.id_planta;


--
-- TOC entry 2076 (class 0 OID 0)
-- Dependencies: 173
-- Name: sga_planta_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_planta_sq', 100, false);


--
-- TOC entry 174 (class 1259 OID 33533)
-- Dependencies: 6 167
-- Name: sga_procedimiento_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_procedimiento_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_procedimiento_sq OWNER TO rcdto;

--
-- TOC entry 2077 (class 0 OID 0)
-- Dependencies: 174
-- Name: sga_procedimiento_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_procedimiento_sq OWNED BY sga_metodologia.id_metodologia;


--
-- TOC entry 2078 (class 0 OID 0)
-- Dependencies: 174
-- Name: sga_procedimiento_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_procedimiento_sq', 2, true);


--
-- TOC entry 186 (class 1259 OID 36086)
-- Dependencies: 6
-- Name: sga_sector; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_sector (
    id_sector smallint NOT NULL,
    no_sector character varying(50) NOT NULL
);


ALTER TABLE public.sga_sector OWNER TO rcdto;

--
-- TOC entry 2079 (class 0 OID 0)
-- Dependencies: 186
-- Name: TABLE sga_sector; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_sector IS 'Sector del edificio en que se encuentra el área.';


--
-- TOC entry 2080 (class 0 OID 0)
-- Dependencies: 186
-- Name: COLUMN sga_sector.id_sector; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_sector.id_sector IS 'Identificador único del sector.';


--
-- TOC entry 2081 (class 0 OID 0)
-- Dependencies: 186
-- Name: COLUMN sga_sector.no_sector; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_sector.no_sector IS 'Nombre del sector (noble, ibndustrial, etc.).';


--
-- TOC entry 185 (class 1259 OID 36084)
-- Dependencies: 6 186
-- Name: sga_sector_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_sector_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_sector_sq OWNER TO rcdto;

--
-- TOC entry 2082 (class 0 OID 0)
-- Dependencies: 185
-- Name: sga_sector_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_sector_sq OWNED BY sga_sector.id_sector;


--
-- TOC entry 2083 (class 0 OID 0)
-- Dependencies: 185
-- Name: sga_sector_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_sector_sq', 4, true);


--
-- TOC entry 175 (class 1259 OID 33548)
-- Dependencies: 6
-- Name: sga_tarea_plan; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_tarea_plan (
    id_tarea_plan integer NOT NULL,
    id_accion integer NOT NULL,
    id_bien integer,
    id_periodicidad integer,
    ds_detalle character varying(4000),
    ds_referencia character varying(400),
    id_espacio integer,
    fe_inicio timestamp without time zone
);


ALTER TABLE public.sga_tarea_plan OWNER TO rcdto;

--
-- TOC entry 2084 (class 0 OID 0)
-- Dependencies: 175
-- Name: TABLE sga_tarea_plan; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_tarea_plan IS 'Planificación de tareas a realizar sobre el bien.';


--
-- TOC entry 2085 (class 0 OID 0)
-- Dependencies: 175
-- Name: COLUMN sga_tarea_plan.id_tarea_plan; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tarea_plan.id_tarea_plan IS 'Identificador único de la planificación de la tarea.';


--
-- TOC entry 2086 (class 0 OID 0)
-- Dependencies: 175
-- Name: COLUMN sga_tarea_plan.id_accion; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tarea_plan.id_accion IS 'Identificador único de la acción.';


--
-- TOC entry 2087 (class 0 OID 0)
-- Dependencies: 175
-- Name: COLUMN sga_tarea_plan.id_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tarea_plan.id_bien IS 'Identificador único del bien.';


--
-- TOC entry 2088 (class 0 OID 0)
-- Dependencies: 175
-- Name: COLUMN sga_tarea_plan.id_periodicidad; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tarea_plan.id_periodicidad IS 'Identificador único de la periodicidad.';


--
-- TOC entry 2089 (class 0 OID 0)
-- Dependencies: 175
-- Name: COLUMN sga_tarea_plan.ds_detalle; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tarea_plan.ds_detalle IS 'Detalles adicionales necesarios para la realización de la tarea.';


--
-- TOC entry 2090 (class 0 OID 0)
-- Dependencies: 175
-- Name: COLUMN sga_tarea_plan.ds_referencia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tarea_plan.ds_referencia IS 'Referencia del registro.';


--
-- TOC entry 176 (class 1259 OID 33554)
-- Dependencies: 6 175
-- Name: sga_tarea_plan_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_tarea_plan_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_tarea_plan_sq OWNER TO rcdto;

--
-- TOC entry 2091 (class 0 OID 0)
-- Dependencies: 176
-- Name: sga_tarea_plan_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_tarea_plan_sq OWNED BY sga_tarea_plan.id_tarea_plan;


--
-- TOC entry 2092 (class 0 OID 0)
-- Dependencies: 176
-- Name: sga_tarea_plan_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_tarea_plan_sq', 10, true);


--
-- TOC entry 177 (class 1259 OID 33558)
-- Dependencies: 6
-- Name: sga_tipo_accion; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_tipo_accion (
    id_tipo_accion integer NOT NULL,
    no_tipo_accion character varying(100) NOT NULL,
    id_tipo_accion_padre integer,
    ds_referencia character varying(400)
);


ALTER TABLE public.sga_tipo_accion OWNER TO rcdto;

--
-- TOC entry 2093 (class 0 OID 0)
-- Dependencies: 177
-- Name: TABLE sga_tipo_accion; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_tipo_accion IS 'Tipo de acciones a realizar sobre los bienes.';


--
-- TOC entry 2094 (class 0 OID 0)
-- Dependencies: 177
-- Name: COLUMN sga_tipo_accion.id_tipo_accion; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_accion.id_tipo_accion IS 'Identificador único del tipo de acción.';


--
-- TOC entry 2095 (class 0 OID 0)
-- Dependencies: 177
-- Name: COLUMN sga_tipo_accion.no_tipo_accion; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_accion.no_tipo_accion IS 'Nombre del tipo de acción que se puede realizar sobre el bien.';


--
-- TOC entry 2096 (class 0 OID 0)
-- Dependencies: 177
-- Name: COLUMN sga_tipo_accion.id_tipo_accion_padre; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_accion.id_tipo_accion_padre IS 'Identificador único del tipo de acción contenedora.';


--
-- TOC entry 2097 (class 0 OID 0)
-- Dependencies: 177
-- Name: COLUMN sga_tipo_accion.ds_referencia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_accion.ds_referencia IS 'Referencia del registro.';


--
-- TOC entry 178 (class 1259 OID 33564)
-- Dependencies: 177 6
-- Name: sga_tipo_accion_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_tipo_accion_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_tipo_accion_sq OWNER TO rcdto;

--
-- TOC entry 2098 (class 0 OID 0)
-- Dependencies: 178
-- Name: sga_tipo_accion_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_tipo_accion_sq OWNED BY sga_tipo_accion.id_tipo_accion;


--
-- TOC entry 2099 (class 0 OID 0)
-- Dependencies: 178
-- Name: sga_tipo_accion_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_tipo_accion_sq', 4, true);


--
-- TOC entry 179 (class 1259 OID 33566)
-- Dependencies: 6
-- Name: sga_tipo_bien; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_tipo_bien (
    id_tipo_bien integer NOT NULL,
    no_tipo_bien character varying(100) NOT NULL,
    id_tipo_bien_padre integer,
    ds_referencia character varying(400)
);


ALTER TABLE public.sga_tipo_bien OWNER TO rcdto;

--
-- TOC entry 2100 (class 0 OID 0)
-- Dependencies: 179
-- Name: TABLE sga_tipo_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_tipo_bien IS 'Tipo de bien.';


--
-- TOC entry 2101 (class 0 OID 0)
-- Dependencies: 179
-- Name: COLUMN sga_tipo_bien.id_tipo_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_bien.id_tipo_bien IS 'Identificador único del tipo de bien.';


--
-- TOC entry 2102 (class 0 OID 0)
-- Dependencies: 179
-- Name: COLUMN sga_tipo_bien.no_tipo_bien; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_bien.no_tipo_bien IS 'Nombre del tipo de bien.';


--
-- TOC entry 2103 (class 0 OID 0)
-- Dependencies: 179
-- Name: COLUMN sga_tipo_bien.id_tipo_bien_padre; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_bien.id_tipo_bien_padre IS 'Identificador único del tipo de bien padre (supertipo).';


--
-- TOC entry 2104 (class 0 OID 0)
-- Dependencies: 179
-- Name: COLUMN sga_tipo_bien.ds_referencia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_bien.ds_referencia IS 'Referencia del registro.';


--
-- TOC entry 180 (class 1259 OID 33572)
-- Dependencies: 179 6
-- Name: sga_tipo_bien_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_tipo_bien_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_tipo_bien_sq OWNER TO rcdto;

--
-- TOC entry 2105 (class 0 OID 0)
-- Dependencies: 180
-- Name: sga_tipo_bien_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_tipo_bien_sq OWNED BY sga_tipo_bien.id_tipo_bien;


--
-- TOC entry 2106 (class 0 OID 0)
-- Dependencies: 180
-- Name: sga_tipo_bien_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_tipo_bien_sq', 40, true);


--
-- TOC entry 181 (class 1259 OID 33574)
-- Dependencies: 6
-- Name: sga_tipo_espacio; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE sga_tipo_espacio (
    id_tipo_espacio smallint NOT NULL,
    no_tipo_espacio character varying(100) NOT NULL,
    id_tipo_espacio_padre smallint,
    ds_referencia character varying(400)
);


ALTER TABLE public.sga_tipo_espacio OWNER TO rcdto;

--
-- TOC entry 2107 (class 0 OID 0)
-- Dependencies: 181
-- Name: TABLE sga_tipo_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON TABLE sga_tipo_espacio IS 'Tipo de espacio físico dentro del centro cultural.';


--
-- TOC entry 2108 (class 0 OID 0)
-- Dependencies: 181
-- Name: COLUMN sga_tipo_espacio.id_tipo_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_espacio.id_tipo_espacio IS 'Identificador único del tipo de espacio.';


--
-- TOC entry 2109 (class 0 OID 0)
-- Dependencies: 181
-- Name: COLUMN sga_tipo_espacio.no_tipo_espacio; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_espacio.no_tipo_espacio IS 'Nombre del tipo de espacio.';


--
-- TOC entry 2110 (class 0 OID 0)
-- Dependencies: 181
-- Name: COLUMN sga_tipo_espacio.id_tipo_espacio_padre; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_espacio.id_tipo_espacio_padre IS 'Identificador único del tipo de espacio padre (supertipo).';


--
-- TOC entry 2111 (class 0 OID 0)
-- Dependencies: 181
-- Name: COLUMN sga_tipo_espacio.ds_referencia; Type: COMMENT; Schema: public; Owner: rcdto
--

COMMENT ON COLUMN sga_tipo_espacio.ds_referencia IS 'Referencia del registro.';


--
-- TOC entry 182 (class 1259 OID 33580)
-- Dependencies: 6 181
-- Name: sga_tipo_espacio_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE sga_tipo_espacio_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sga_tipo_espacio_sq OWNER TO rcdto;

--
-- TOC entry 2112 (class 0 OID 0)
-- Dependencies: 182
-- Name: sga_tipo_espacio_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE sga_tipo_espacio_sq OWNED BY sga_tipo_espacio.id_tipo_espacio;


--
-- TOC entry 2113 (class 0 OID 0)
-- Dependencies: 182
-- Name: sga_tipo_espacio_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('sga_tipo_espacio_sq', 22, true);


--
-- TOC entry 183 (class 1259 OID 33592)
-- Dependencies: 6
-- Name: stg_periodicidad; Type: TABLE; Schema: public; Owner: rcdto; Tablespace: 
--

CREATE TABLE stg_periodicidad (
    id_carga bigint NOT NULL,
    no_archivo character varying(100),
    fe_carga timestamp without time zone,
    co_estado_proceso character(1),
    tx_accion character varying(50),
    tx_bien character varying(100),
    tx_espacio character varying(100),
    tx_cat_bien character varying(100),
    tx_cat_espacio character varying(100),
    tx_tipo_accion character varying(100),
    tx_metodologia character varying(400),
    tx_frecuencia character varying(50),
    tx_frecuencia_req character varying(50),
    tx_duracion character varying(50),
    tx_qt_recursos character varying(50)
);


ALTER TABLE public.stg_periodicidad OWNER TO rcdto;

--
-- TOC entry 184 (class 1259 OID 33598)
-- Dependencies: 183 6
-- Name: stg_carga_sq; Type: SEQUENCE; Schema: public; Owner: rcdto
--

CREATE SEQUENCE stg_carga_sq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stg_carga_sq OWNER TO rcdto;

--
-- TOC entry 2114 (class 0 OID 0)
-- Dependencies: 184
-- Name: stg_carga_sq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rcdto
--

ALTER SEQUENCE stg_carga_sq OWNED BY stg_periodicidad.id_carga;


--
-- TOC entry 2115 (class 0 OID 0)
-- Dependencies: 184
-- Name: stg_carga_sq; Type: SEQUENCE SET; Schema: public; Owner: rcdto
--

SELECT pg_catalog.setval('stg_carga_sq', 1, false);


--
-- TOC entry 1936 (class 2604 OID 33600)
-- Dependencies: 162 161
-- Name: id_accion; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion ALTER COLUMN id_accion SET DEFAULT nextval('sga_accion_sq'::regclass);


--
-- TOC entry 1938 (class 2604 OID 33602)
-- Dependencies: 164 163
-- Name: id_bien; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_bien ALTER COLUMN id_bien SET DEFAULT nextval('sga_bien_sq'::regclass);


--
-- TOC entry 1939 (class 2604 OID 33604)
-- Dependencies: 166 165
-- Name: id_espacio; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_espacio ALTER COLUMN id_espacio SET DEFAULT nextval('sga_espacio_sq'::regclass);


--
-- TOC entry 1940 (class 2604 OID 33608)
-- Dependencies: 174 167
-- Name: id_metodologia; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_metodologia ALTER COLUMN id_metodologia SET DEFAULT nextval('sga_procedimiento_sq'::regclass);


--
-- TOC entry 1941 (class 2604 OID 33609)
-- Dependencies: 169 168
-- Name: id_origen; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_origen ALTER COLUMN id_origen SET DEFAULT nextval('sga_origen_sq'::regclass);


--
-- TOC entry 1943 (class 2604 OID 33610)
-- Dependencies: 171 170
-- Name: id_periodicidad; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_periodicidad ALTER COLUMN id_periodicidad SET DEFAULT nextval('sga_periodicidad_sq'::regclass);


--
-- TOC entry 1944 (class 2604 OID 33612)
-- Dependencies: 173 172
-- Name: id_planta; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_planta ALTER COLUMN id_planta SET DEFAULT nextval('sga_planta_sq'::regclass);


--
-- TOC entry 1950 (class 2604 OID 36089)
-- Dependencies: 186 185 186
-- Name: id_sector; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_sector ALTER COLUMN id_sector SET DEFAULT nextval('sga_sector_sq'::regclass);


--
-- TOC entry 1945 (class 2604 OID 33614)
-- Dependencies: 176 175
-- Name: id_tarea_plan; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tarea_plan ALTER COLUMN id_tarea_plan SET DEFAULT nextval('sga_tarea_plan_sq'::regclass);


--
-- TOC entry 1946 (class 2604 OID 33615)
-- Dependencies: 178 177
-- Name: id_tipo_accion; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tipo_accion ALTER COLUMN id_tipo_accion SET DEFAULT nextval('sga_tipo_accion_sq'::regclass);


--
-- TOC entry 1947 (class 2604 OID 33616)
-- Dependencies: 180 179
-- Name: id_tipo_bien; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tipo_bien ALTER COLUMN id_tipo_bien SET DEFAULT nextval('sga_tipo_bien_sq'::regclass);


--
-- TOC entry 1948 (class 2604 OID 33617)
-- Dependencies: 182 181
-- Name: id_tipo_espacio; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tipo_espacio ALTER COLUMN id_tipo_espacio SET DEFAULT nextval('sga_tipo_espacio_sq'::regclass);


--
-- TOC entry 1949 (class 2604 OID 33620)
-- Dependencies: 184 183
-- Name: id_carga; Type: DEFAULT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY stg_periodicidad ALTER COLUMN id_carga SET DEFAULT nextval('stg_carga_sq'::regclass);


--
-- TOC entry 2010 (class 0 OID 33450)
-- Dependencies: 161 2023
-- Data for Name: sga_accion; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_accion (id_accion, id_tipo_espacio, id_tipo_bien, id_origen, id_metodologia, id_periodicidad, fl_a_demanda, ds_referencia, id_tipo_accion, id_sector) VALUES (3, 13, NULL, 1, 1, 4, false, 'Limpieza | Básica  > Baño | Público > Transición', 2, 3);
INSERT INTO sga_accion (id_accion, id_tipo_espacio, id_tipo_bien, id_origen, id_metodologia, id_periodicidad, fl_a_demanda, ds_referencia, id_tipo_accion, id_sector) VALUES (6, 13, NULL, 1, 2, 3, false, 'Limpieza | Profunda  > Baño | Público > Transición', 3, 3);
INSERT INTO sga_accion (id_accion, id_tipo_espacio, id_tipo_bien, id_origen, id_metodologia, id_periodicidad, fl_a_demanda, ds_referencia, id_tipo_accion, id_sector) VALUES (5, 19, NULL, 1, 1, 4, false, 'Limpieza | Básica  > Oficina > Industrial', 2, 1);


--
-- TOC entry 2011 (class 0 OID 33464)
-- Dependencies: 163 2023
-- Data for Name: sga_bien; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_bien (id_bien, id_tipo_bien, id_espacio, ds_observacion, nu_cantidad) VALUES (3, 11, 2, NULL, 8);


--
-- TOC entry 2012 (class 0 OID 33475)
-- Dependencies: 165 2023
-- Data for Name: sga_espacio; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (11, 13, NULL, 'PB-T-008', 'T-008', 'T-008', 0, 'Baño | Público > Industrial > PB > T-008', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (10, 13, NULL, 'PB-T-009', 'T-009', 'T-009', 0, 'Baño | Público > Industrial > PB > T-009', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (9, 13, NULL, 'PB-T-010', 'T-010', 'T-010', 0, 'Baño | Público > Industrial > PB > T-010', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (27, 13, NULL, 'P8-T-805', 'T-805', 'T-805', 80, 'Baño | Público > Industrial > 8ºP > T-805', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (20, 13, NULL, 'P8-T-851-B', 'T-851-B', 'T-851-B', 80, 'Baño | Público > Noble > 8ºP > T-851-B', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (24, 13, NULL, 'P8-T-841', 'T-841', 'T-841', 80, 'Baño | Público > Noble > 8ºP > T-841', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (23, 13, NULL, 'P8-T-841', 'T-841', 'T-841', 80, 'Baño | Público > Noble > 8ºP > T-841', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (26, 13, NULL, 'P8-T-841-A', 'T-841-A', 'T-841-A', 80, 'Baño | Público > Noble > 8ºP > T-841-A', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (25, 13, NULL, 'P8-T-841-B', 'T-841-B', 'T-841-B', 80, 'Baño | Público > Noble > 8ºP > T-841-B', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (18, 13, NULL, 'P8-T-851', 'T-851', 'T-851', 80, 'Baño | Público > Noble > 8ºP > T-851', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (19, 13, NULL, 'P8-T-851-A', 'T-851-A', 'T-851-A', 80, 'Baño | Público > Noble > 8ºP > T-851-A', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (1, 13, NULL, 'PB-2(DHM)', 'T-003 (PB-2(DHM))', 'T-003', 0, 'Baño | Público > Transición > PB > T-003 (PB-2(DHM))', 3);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (2, 19, NULL, 'PB-006-A', '006 A-Oficina', '006 A-O', 0, 'Oficina > Industrial > PB > 006 A-Oficina', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (22, 22, NULL, 'P8-T-845', 'T-845', 'T-845', 80, 'Baño | Camarines > Noble > 8ºP > T-845', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (21, 22, NULL, 'P8-T-846', 'T-846', 'T-846', 80, 'Baño | Camarines > Noble > 8ºP > T-846', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (17, 22, NULL, 'P8-T-846-E', 'T-846-E', 'T-846-E', 80, 'Baño | Camarines > Noble > 8ºP > T-846-E', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (16, 21, NULL, 'P5-T-517', 'T-517', 'T-517', 50, 'Baño | Privado > Noble > 5ºP > T-517', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (15, 21, NULL, 'P5-T-518', 'T-518', 'T-518', 50, 'Baño | Privado > Noble > 5ºP > T-518', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (14, 21, NULL, 'P5-T-520', 'T-520', 'T-520', 50, 'Baño | Privado > Noble > 5ºP > T-520', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (12, 21, NULL, 'P5-T-521', 'T-521', 'T-521', 50, 'Baño | Privado > Noble > 5ºP > T-521', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (13, 21, NULL, 'P5-T-522', 'T-522', 'T-522', 50, 'Baño | Privado > Noble > 5ºP > T-522', 2);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (4, 13, NULL, 'PB-T-012', 'T-012', 'T-012', 0, 'Baño | Público > Transición > PB > T-012', 3);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (5, 13, NULL, 'PB-T-013', 'T-013', 'T-013', 0, 'Baño | Público > Transición > PB > T-013', 3);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (28, 13, NULL, 'P8-T-835', 'T-835', 'T-835', 80, 'Baño | Público > Industrial > 8ºP > T-835', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (8, 13, NULL, 'PB-T-005', 'T-005', 'T-005', 0, 'Baño | Público > Industrial > PB > T-005', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (6, 13, NULL, 'PB-T-006', 'T-006', 'T-006', 0, 'Baño | Público > Industrial > PB > T-006', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (7, 13, NULL, 'PB-T-007', 'T-007', 'T-007', 0, 'Baño | Público > Industrial > PB > T-007', 1);
INSERT INTO sga_espacio (id_espacio, id_tipo_espacio, id_espacio_contenedor, co_espacio, no_espacio, co_plano, id_planta, ds_referencia, id_sector) VALUES (3, 13, NULL, 'PB-T-002', 'T-002', 'T-002', 0, 'Baño | Público > Transición > PB > T-002', 3);


--
-- TOC entry 2013 (class 0 OID 33500)
-- Dependencies: 167 2023
-- Data for Name: sga_metodologia; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_metodologia (id_metodologia, no_metodologia, ds_metodologia, id_origen) VALUES (1, 'Limpieza Basica Baños', '<div>
	<strong>Limpieza Basica</strong></div>
<ul>
	<li>
		Reposici&oacute;n de insumos</li>
	<li>
		Limpieza de espejos</li>
	<li>
		Limpieza de pisos</li>
	<li>
		Perfumar pisos</li>
	<li>
		Deshodorante de ambiente</li>
	<li>
		Limpieza de bacha y mesada</li>
</ul>
', 1);
INSERT INTO sga_metodologia (id_metodologia, no_metodologia, ds_metodologia, id_origen) VALUES (2, 'Limpieza Profunda Baños', '<div>
	<div>
		<strong>Limpieza profunda</strong></div>
	<ul>
		<li>
			Limpieza de azulejo</li>
		<li>
			Limpieza de techo</li>
		<li>
			Limpieza de vidrios de ventanas</li>
		<li>
			Retirar tela de ara&ntilde;a</li>
	</ul>
	<div>
		<strong>Limpieza Basica</strong></div>
	<ul>
		<li>
			Reposici&oacute;n de insumos</li>
		<li>
			Limpieza de espejos</li>
		<li>
			Limpieza de pisos</li>
		<li>
			Perfumar pisos</li>
		<li>
			Deshodorante de ambiente</li>
		<li>
			Limpieza de bacha y mesada</li>
	</ul>
</div>
<div>
	&nbsp;</div>
<div>
	&nbsp;</div>
', 1);


--
-- TOC entry 2014 (class 0 OID 33509)
-- Dependencies: 168 2023
-- Data for Name: sga_origen; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_origen (id_origen, no_origen) VALUES (1, 'Pliego');
INSERT INTO sga_origen (id_origen, no_origen) VALUES (2, 'Manual');
INSERT INTO sga_origen (id_origen, no_origen) VALUES (3, 'Especificación');


--
-- TOC entry 2015 (class 0 OID 33517)
-- Dependencies: 170 2023
-- Data for Name: sga_periodicidad; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (1, 'Permanente', 0);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (5, 'Diaria', 1);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (6, 'Semanal', 7);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (7, 'Quincenal', 15);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (8, 'Mensual', 30);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (9, 'Bimestral', 60);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (10, 'Trimestral', 90);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (11, 'Semestral', 180);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (12, 'Anual', 365);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (4, '5 veces dia', 0.200000003);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (13, '2 veces tarde', 0.5);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (2, '2 veces mañana', 0.5);
INSERT INTO sga_periodicidad (id_periodicidad, no_periodicidad, va_frecuencia) VALUES (3, '1 vez noche', 1);


--
-- TOC entry 2016 (class 0 OID 33528)
-- Dependencies: 172 2023
-- Data for Name: sga_planta; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_planta (id_planta, no_planta) VALUES (0, 'PB');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (10, '1ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (20, '2ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (25, '2ºEP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (30, '3ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (40, '4ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (45, '4ºEP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (50, '5ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (60, '6ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (70, '7ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (80, '8ºP');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (-10, '1ºSS');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (-20, '2ºSS');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (-30, '3ºSS');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (-40, '4ºSS');
INSERT INTO sga_planta (id_planta, no_planta) VALUES (90, '9ºP');


--
-- TOC entry 2022 (class 0 OID 36086)
-- Dependencies: 186 2023
-- Data for Name: sga_sector; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_sector (id_sector, no_sector) VALUES (0, 'No Identificado');
INSERT INTO sga_sector (id_sector, no_sector) VALUES (1, 'Industrial');
INSERT INTO sga_sector (id_sector, no_sector) VALUES (2, 'Noble');
INSERT INTO sga_sector (id_sector, no_sector) VALUES (3, 'Transición');
INSERT INTO sga_sector (id_sector, no_sector) VALUES (4, 'Plaza Tango');


--
-- TOC entry 2017 (class 0 OID 33548)
-- Dependencies: 175 2023
-- Data for Name: sga_tarea_plan; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_tarea_plan (id_tarea_plan, id_accion, id_bien, id_periodicidad, ds_detalle, ds_referencia, id_espacio, fe_inicio) VALUES (10, 6, NULL, 3, 'Si el baño esta con las luces apagadas, no realizar la tarea.
', 'Limpieza | Profunda  > Baño | Público > Transición', 1, '2016-03-01 12:19:00');
INSERT INTO sga_tarea_plan (id_tarea_plan, id_accion, id_bien, id_periodicidad, ds_detalle, ds_referencia, id_espacio, fe_inicio) VALUES (9, 3, NULL, 4, NULL, 'Limpieza | Básica  > Baño | Público > Transición', 1, '2016-03-01 00:00:00');


--
-- TOC entry 2018 (class 0 OID 33558)
-- Dependencies: 177 2023
-- Data for Name: sga_tipo_accion; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (1, 'Limpieza', NULL, 'Limpieza');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (6, 'Fumigación', NULL, 'Fumigación');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (10, 'Mantenimiento', NULL, 'Mantenimiento');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (2, 'Básica', 1, 'Limpieza | Básica');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (3, 'Profunda', 1, 'Limpieza | Profunda');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (7, 'Desratización', 6, 'Fumigación | Desratización');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (8, 'Desinsectación', 6, 'Fumigación | Desinsectación');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (9, 'Desinfección', 6, 'Fumigación | Desinfección');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (11, 'Estructural', 10, 'Mantenimiento | Estructural');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (12, 'Correctivo', 10, 'Mantenimiento | Correctivo');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (13, 'Preventivo', 10, 'Mantenimiento | Preventivo');
INSERT INTO sga_tipo_accion (id_tipo_accion, no_tipo_accion, id_tipo_accion_padre, ds_referencia) VALUES (4, 'Demanda', 1, 'Limpieza | Demanda');


--
-- TOC entry 2019 (class 0 OID 33566)
-- Dependencies: 179 2023
-- Data for Name: sga_tipo_bien; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_tipo_bien (id_tipo_bien, no_tipo_bien, id_tipo_bien_padre, ds_referencia) VALUES (11, 'Silla', NULL, 'Silla');


--
-- TOC entry 2020 (class 0 OID 33574)
-- Dependencies: 181 2023
-- Data for Name: sga_tipo_espacio; Type: TABLE DATA; Schema: public; Owner: rcdto
--

INSERT INTO sga_tipo_espacio (id_tipo_espacio, no_tipo_espacio, id_tipo_espacio_padre, ds_referencia) VALUES (7, 'Exterior', NULL, 'Exterior');
INSERT INTO sga_tipo_espacio (id_tipo_espacio, no_tipo_espacio, id_tipo_espacio_padre, ds_referencia) VALUES (19, 'Oficina', NULL, 'Oficina');
INSERT INTO sga_tipo_espacio (id_tipo_espacio, no_tipo_espacio, id_tipo_espacio_padre, ds_referencia) VALUES (12, 'Baño', NULL, 'Baño');
INSERT INTO sga_tipo_espacio (id_tipo_espacio, no_tipo_espacio, id_tipo_espacio_padre, ds_referencia) VALUES (10, 'Acceso', NULL, 'Acceso');
INSERT INTO sga_tipo_espacio (id_tipo_espacio, no_tipo_espacio, id_tipo_espacio_padre, ds_referencia) VALUES (13, 'Público', 12, 'Baño | Público');
INSERT INTO sga_tipo_espacio (id_tipo_espacio, no_tipo_espacio, id_tipo_espacio_padre, ds_referencia) VALUES (22, 'Camarines', 12, 'Baño | Camarines');
INSERT INTO sga_tipo_espacio (id_tipo_espacio, no_tipo_espacio, id_tipo_espacio_padre, ds_referencia) VALUES (21, 'Privado', 12, 'Baño | Privado');


--
-- TOC entry 2021 (class 0 OID 33592)
-- Dependencies: 183 2023
-- Data for Name: stg_periodicidad; Type: TABLE DATA; Schema: public; Owner: rcdto
--



--
-- TOC entry 1952 (class 2606 OID 33622)
-- Dependencies: 161 161 2024
-- Name: sga_accion_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_accion_pk PRIMARY KEY (id_accion);


--
-- TOC entry 1954 (class 2606 OID 33626)
-- Dependencies: 163 163 2024
-- Name: sga_bien_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_bien
    ADD CONSTRAINT sga_bien_pk PRIMARY KEY (id_bien);


--
-- TOC entry 1956 (class 2606 OID 33630)
-- Dependencies: 165 165 2024
-- Name: sga_espacio_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_espacio
    ADD CONSTRAINT sga_espacio_pk PRIMARY KEY (id_espacio);


--
-- TOC entry 1958 (class 2606 OID 33638)
-- Dependencies: 167 167 2024
-- Name: sga_metodologia_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_metodologia
    ADD CONSTRAINT sga_metodologia_pk PRIMARY KEY (id_metodologia);


--
-- TOC entry 1960 (class 2606 OID 33644)
-- Dependencies: 168 168 2024
-- Name: sga_origen_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_origen
    ADD CONSTRAINT sga_origen_pk PRIMARY KEY (id_origen);


--
-- TOC entry 1962 (class 2606 OID 33646)
-- Dependencies: 170 170 2024
-- Name: sga_periodicidad_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_periodicidad
    ADD CONSTRAINT sga_periodicidad_pk PRIMARY KEY (id_periodicidad);


--
-- TOC entry 1964 (class 2606 OID 33650)
-- Dependencies: 172 172 2024
-- Name: sga_planta_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_planta
    ADD CONSTRAINT sga_planta_pk PRIMARY KEY (id_planta);


--
-- TOC entry 1976 (class 2606 OID 36091)
-- Dependencies: 186 186 2024
-- Name: sga_sector_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_sector
    ADD CONSTRAINT sga_sector_pk PRIMARY KEY (id_sector);


--
-- TOC entry 1966 (class 2606 OID 33658)
-- Dependencies: 175 175 2024
-- Name: sga_tarea_plan_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_tarea_plan
    ADD CONSTRAINT sga_tarea_plan_pk PRIMARY KEY (id_tarea_plan);


--
-- TOC entry 1968 (class 2606 OID 33660)
-- Dependencies: 177 177 2024
-- Name: sga_tipo_accion_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_tipo_accion
    ADD CONSTRAINT sga_tipo_accion_pk PRIMARY KEY (id_tipo_accion);


--
-- TOC entry 1970 (class 2606 OID 33662)
-- Dependencies: 179 179 2024
-- Name: sga_tipo_bien_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_tipo_bien
    ADD CONSTRAINT sga_tipo_bien_pk PRIMARY KEY (id_tipo_bien);


--
-- TOC entry 1972 (class 2606 OID 33664)
-- Dependencies: 181 181 2024
-- Name: sga_tipo_espacio_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY sga_tipo_espacio
    ADD CONSTRAINT sga_tipo_espacio_pk PRIMARY KEY (id_tipo_espacio);


--
-- TOC entry 1974 (class 2606 OID 33670)
-- Dependencies: 183 183 2024
-- Name: stg_fichadas_pk; Type: CONSTRAINT; Schema: public; Owner: rcdto; Tablespace: 
--

ALTER TABLE ONLY stg_periodicidad
    ADD CONSTRAINT stg_fichadas_pk PRIMARY KEY (id_carga);


--
-- TOC entry 1998 (class 2620 OID 33680)
-- Dependencies: 161 205 2024
-- Name: tg_accion_i; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_accion_i BEFORE INSERT ON sga_accion FOR EACH ROW EXECUTE PROCEDURE fn_accion_tg();


--
-- TOC entry 1999 (class 2620 OID 33681)
-- Dependencies: 205 161 2024
-- Name: tg_accion_u; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_accion_u BEFORE UPDATE ON sga_accion FOR EACH ROW EXECUTE PROCEDURE fn_accion_tg();


--
-- TOC entry 2000 (class 2620 OID 33684)
-- Dependencies: 206 165 2024
-- Name: tg_espacio_i; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_espacio_i BEFORE INSERT ON sga_espacio FOR EACH ROW EXECUTE PROCEDURE fn_espacio_tg();


--
-- TOC entry 2001 (class 2620 OID 33685)
-- Dependencies: 206 165 2024
-- Name: tg_espacio_u; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_espacio_u BEFORE UPDATE ON sga_espacio FOR EACH ROW EXECUTE PROCEDURE fn_espacio_tg();


--
-- TOC entry 2002 (class 2620 OID 33686)
-- Dependencies: 175 204 2024
-- Name: tg_tarea_plan_i; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tarea_plan_i BEFORE INSERT ON sga_tarea_plan FOR EACH ROW EXECUTE PROCEDURE fn_tarea_plan_tg();


--
-- TOC entry 2003 (class 2620 OID 33687)
-- Dependencies: 204 175 2024
-- Name: tg_tarea_plan_u; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tarea_plan_u BEFORE UPDATE ON sga_tarea_plan FOR EACH ROW EXECUTE PROCEDURE fn_tarea_plan_tg();


--
-- TOC entry 2004 (class 2620 OID 33688)
-- Dependencies: 177 200 2024
-- Name: tg_tipo_accion_i; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tipo_accion_i BEFORE INSERT ON sga_tipo_accion FOR EACH ROW EXECUTE PROCEDURE fn_tipo_accion_tg();


--
-- TOC entry 2005 (class 2620 OID 33689)
-- Dependencies: 177 200 2024
-- Name: tg_tipo_accion_u; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tipo_accion_u BEFORE UPDATE ON sga_tipo_accion FOR EACH ROW EXECUTE PROCEDURE fn_tipo_accion_tg();


--
-- TOC entry 2006 (class 2620 OID 33690)
-- Dependencies: 201 179 2024
-- Name: tg_tipo_bien_i; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tipo_bien_i BEFORE INSERT ON sga_tipo_bien FOR EACH ROW EXECUTE PROCEDURE fn_tipo_bien_tg();


--
-- TOC entry 2007 (class 2620 OID 33691)
-- Dependencies: 201 179 2024
-- Name: tg_tipo_bien_u; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tipo_bien_u BEFORE UPDATE ON sga_tipo_bien FOR EACH ROW EXECUTE PROCEDURE fn_tipo_bien_tg();


--
-- TOC entry 2008 (class 2620 OID 33692)
-- Dependencies: 202 181 2024
-- Name: tg_tipo_espacio_i; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tipo_espacio_i BEFORE INSERT ON sga_tipo_espacio FOR EACH ROW EXECUTE PROCEDURE fn_tipo_espacio_tg();


--
-- TOC entry 2009 (class 2620 OID 33693)
-- Dependencies: 202 181 2024
-- Name: tg_tipo_espacio_u; Type: TRIGGER; Schema: public; Owner: rcdto
--

CREATE TRIGGER tg_tipo_espacio_u BEFORE UPDATE ON sga_tipo_espacio FOR EACH ROW EXECUTE PROCEDURE fn_tipo_espacio_tg();


--
-- TOC entry 1991 (class 2606 OID 33699)
-- Dependencies: 1951 161 175 2024
-- Name: sga_actividad_tarea_plan_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tarea_plan
    ADD CONSTRAINT sga_actividad_tarea_plan_fk FOREIGN KEY (id_accion) REFERENCES sga_accion(id_accion);


--
-- TOC entry 1992 (class 2606 OID 33719)
-- Dependencies: 163 1953 175 2024
-- Name: sga_bien_tarea_plan_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tarea_plan
    ADD CONSTRAINT sga_bien_tarea_plan_fk FOREIGN KEY (id_bien) REFERENCES sga_bien(id_bien);


--
-- TOC entry 1984 (class 2606 OID 33729)
-- Dependencies: 1955 165 163 2024
-- Name: sga_espacio_bien_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_bien
    ADD CONSTRAINT sga_espacio_bien_fk FOREIGN KEY (id_espacio) REFERENCES sga_espacio(id_espacio);


--
-- TOC entry 1986 (class 2606 OID 33734)
-- Dependencies: 165 165 1955 2024
-- Name: sga_espacio_espacio_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_espacio
    ADD CONSTRAINT sga_espacio_espacio_fk FOREIGN KEY (id_espacio_contenedor) REFERENCES sga_espacio(id_espacio);


--
-- TOC entry 1993 (class 2606 OID 33744)
-- Dependencies: 175 165 1955 2024
-- Name: sga_espacio_sga_tarea_plan_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tarea_plan
    ADD CONSTRAINT sga_espacio_sga_tarea_plan_fk FOREIGN KEY (id_espacio) REFERENCES sga_espacio(id_espacio);


--
-- TOC entry 1977 (class 2606 OID 33759)
-- Dependencies: 161 168 1959 2024
-- Name: sga_origen_actividad_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_origen_actividad_fk FOREIGN KEY (id_origen) REFERENCES sga_origen(id_origen);


--
-- TOC entry 1990 (class 2606 OID 33769)
-- Dependencies: 167 168 1959 2024
-- Name: sga_origen_procedimiento_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_metodologia
    ADD CONSTRAINT sga_origen_procedimiento_fk FOREIGN KEY (id_origen) REFERENCES sga_origen(id_origen);


--
-- TOC entry 1978 (class 2606 OID 33774)
-- Dependencies: 170 161 1961 2024
-- Name: sga_periodicidad_sga_actividad_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_periodicidad_sga_actividad_fk FOREIGN KEY (id_periodicidad) REFERENCES sga_periodicidad(id_periodicidad);


--
-- TOC entry 1994 (class 2606 OID 33779)
-- Dependencies: 175 170 1961 2024
-- Name: sga_periodicidad_tarea_plan_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tarea_plan
    ADD CONSTRAINT sga_periodicidad_tarea_plan_fk FOREIGN KEY (id_periodicidad) REFERENCES sga_periodicidad(id_periodicidad);


--
-- TOC entry 1987 (class 2606 OID 33794)
-- Dependencies: 165 172 1963 2024
-- Name: sga_planta_sga_espacio_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_espacio
    ADD CONSTRAINT sga_planta_sga_espacio_fk FOREIGN KEY (id_planta) REFERENCES sga_planta(id_planta);


--
-- TOC entry 1979 (class 2606 OID 33799)
-- Dependencies: 161 167 1957 2024
-- Name: sga_procedimiento_actividad_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_procedimiento_actividad_fk FOREIGN KEY (id_metodologia) REFERENCES sga_metodologia(id_metodologia);


--
-- TOC entry 1983 (class 2606 OID 36093)
-- Dependencies: 186 1975 161 2024
-- Name: sga_sector_sga_accion_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_sector_sga_accion_fk FOREIGN KEY (id_sector) REFERENCES sga_sector(id_sector);


--
-- TOC entry 1989 (class 2606 OID 36098)
-- Dependencies: 165 186 1975 2024
-- Name: sga_sector_sga_espacio_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_espacio
    ADD CONSTRAINT sga_sector_sga_espacio_fk FOREIGN KEY (id_sector) REFERENCES sga_sector(id_sector);


--
-- TOC entry 1980 (class 2606 OID 33814)
-- Dependencies: 177 161 1967 2024
-- Name: sga_tipo_accion_accion_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_tipo_accion_accion_fk FOREIGN KEY (id_tipo_accion) REFERENCES sga_tipo_accion(id_tipo_accion);


--
-- TOC entry 1995 (class 2606 OID 33819)
-- Dependencies: 177 1967 177 2024
-- Name: sga_tipo_accion_tipo_accion_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tipo_accion
    ADD CONSTRAINT sga_tipo_accion_tipo_accion_fk FOREIGN KEY (id_tipo_accion_padre) REFERENCES sga_tipo_accion(id_tipo_accion);


--
-- TOC entry 1985 (class 2606 OID 33824)
-- Dependencies: 179 1969 163 2024
-- Name: sga_tipo_bien_bien_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_bien
    ADD CONSTRAINT sga_tipo_bien_bien_fk FOREIGN KEY (id_tipo_bien) REFERENCES sga_tipo_bien(id_tipo_bien);


--
-- TOC entry 1981 (class 2606 OID 33829)
-- Dependencies: 179 161 1969 2024
-- Name: sga_tipo_bien_sga_accion_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_tipo_bien_sga_accion_fk FOREIGN KEY (id_tipo_bien) REFERENCES sga_tipo_bien(id_tipo_bien);


--
-- TOC entry 1996 (class 2606 OID 33834)
-- Dependencies: 1969 179 179 2024
-- Name: sga_tipo_bien_tipo_bien_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tipo_bien
    ADD CONSTRAINT sga_tipo_bien_tipo_bien_fk FOREIGN KEY (id_tipo_bien_padre) REFERENCES sga_tipo_bien(id_tipo_bien);


--
-- TOC entry 1988 (class 2606 OID 33839)
-- Dependencies: 181 165 1971 2024
-- Name: sga_tipo_espacio_espacio_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_espacio
    ADD CONSTRAINT sga_tipo_espacio_espacio_fk FOREIGN KEY (id_tipo_espacio) REFERENCES sga_tipo_espacio(id_tipo_espacio);


--
-- TOC entry 1982 (class 2606 OID 33844)
-- Dependencies: 161 1971 181 2024
-- Name: sga_tipo_espacio_sga_actividad_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_accion
    ADD CONSTRAINT sga_tipo_espacio_sga_actividad_fk FOREIGN KEY (id_tipo_espacio) REFERENCES sga_tipo_espacio(id_tipo_espacio);


--
-- TOC entry 1997 (class 2606 OID 33849)
-- Dependencies: 181 181 1971 2024
-- Name: sga_tipo_espacio_sga_tipo_espacio_fk; Type: FK CONSTRAINT; Schema: public; Owner: rcdto
--

ALTER TABLE ONLY sga_tipo_espacio
    ADD CONSTRAINT sga_tipo_espacio_sga_tipo_espacio_fk FOREIGN KEY (id_tipo_espacio_padre) REFERENCES sga_tipo_espacio(id_tipo_espacio);


-- Completed on 2016-03-16 10:11:17

--
-- PostgreSQL database dump complete
--

